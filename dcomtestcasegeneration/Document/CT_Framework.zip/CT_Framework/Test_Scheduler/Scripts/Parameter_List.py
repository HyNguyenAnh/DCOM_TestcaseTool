#*************************************************************
#        GLOBAL_PARAMETER_INTIALIZATION
#**************************************************************
Software_Flash_Max_Timeout = 120
config = "VID3-PF (qm)"
TSE_FileName_Path = r'D:\Jenkins\Received.tcf'
Log_Serevr_Path ="None"
Software_Version ="4.7.1"
logpath=r"D:\Jenkins\TestAutomation\CT_Framework\Test_Scheduler\Scripts\Python_wrapper_logs"

#Project Details
Project_Name = r"VID3_JIZHI_SE1A_SD1A (qm)"
Report_Path = r"C:\RQM_Test_Result_Handler\result_file\test_xml"

##SW Flashing params
# RelayPath = r'D:\Jenkins\TestAutomation\Test_Environment\Relay_Control'
UARTFlashToolPath = r'D:\Jenkins\SW_Flash_Files\Binaries\fv_if\tools\FlashtoolTerminal'
FlashContainerPath= r'D:\Jenkins\SW_Flash_Files\Binaries\build\jizhimono_mc0_release\bin'
Binary_Path = r'D:\Jenkins\SW_Flash_Files\Binaries'
#Binary_Server_Path = r'\\abtvdfs2.de.bosch.com\ismdfs\ida\abt\video\Video_Rel\FVG3_REL_CUS_CN\all\G3N_Releases'
Binary_Server_Path = r'D:\nvs9kor\JIZHI_releases'
Flash_COM_Port = r'COM8'
SW_Flashing_Status = r'D:\Jenkins\SW_Flashing_Status.txt'
download_sync_time = r'100'

#Software Flashing Regex
# TCF_Iteration_regex=r'.*NRCS2_.*_FCA_(.*)'

#Software flashing Binaries unzipping path
# Unzip_Binaries_Path=r"D:\Jenkins\TestAutomation\binaries"

#Run Canoe
RBS_PATH = r'D:\Jenkins\SW_Flash_Files\Binaries\cpj_jizhi\tools\Coresi\JIZHI_Restbus_updated\vs_jizhi_SE1A\coresi_jizhi_se1a_pri_pubcan_tester.cfg'
TEST_REPORTS_AFTER_EXECUTION = r'D:\Jenkins\TestCaseServer\Test_Environment\Full_Test_XMLs\JIZHI_Project'
RQM_SCRIPTS_ZIP_PATH = 'D:\\Jenkins\\TestAutomation\\CT_Framework\\Test_Scheduler\\Scripts\\'

#RQM Updater
RQM_XML_PATH = r'D:\Jenkins\RQM_XML_Result_Path.txt'


# CANOE_FOLDER_PATH_WL_CVPAM = 'D:\\Jenkins\\TestAutomation\\01_TestEnvironment\\CANoe\\FCA_WL_NRCS_CVPAM\\CVPAM_WL_R4_1936_CANFD_RBS\\'
# CANOE_FOLDER_PATH_WS_CVPAM = 'D:\\Jenkins\\TestAutomation\\01_TestEnvironment\\CANoe\\FCA_WS_NRCS_CVPAM\\CVPAM_WS_R3_1937_CANFD_RBS\\'


# XCP_CONFIGURATION_WL_CVPAM =  'D:\\Jenkins\\TestAutomation\\01_TestEnvironment\\CANoe\\FCA_WL_NRCS_CVPAM\\CVPAM_WL_R4_1936_CANFD_RBS\\'
# XCP_CONFIGURATION_WS_CVPAM = 'D:\\Jenkins\\TestAutomation\\01_TestEnvironment\\CANoe\\FCA_WS_NRCS_CVPAM\\CVPAM_WS_R3_1937_CANFD_RBS\\'


#If ignoreTestResult is set to False, Exception is raised if the test fails 
ignoreTestResult=True

CANOE_REPORT_FOLDER = r'D:\Jenkins\Test_Report'

# VARIANT_SPECIFIC={
    # "WLCVPAM_High":[CANOE_FOLDER_PATH_WL_CVPAM,'PWL21_E2A_R4_CANFD2_V11','High',XCP_CONFIGURATION_WL_CVPAM,'XCP_Configuration_WL'],
    # "WLCVPAM_Low":[CANOE_FOLDER_PATH_WL_CVPAM,'PWL21_E2A_R4_CANFD2_V11','Low',XCP_CONFIGURATION_WL_CVPAM,'XCP_Configuration_WL'],
    
    # "WLL2PCVPAM_High":[CANOE_FOLDER_PATH_WL_CVPAM,'PWL21_E2A_R4_CANFD2_V11','Low',XCP_CONFIGURATION_WL_CVPAM,'XCP_Configuration_WL'],
    
    # "WSCVPAM_High":[CANOE_FOLDER_PATH_WS_CVPAM,'PWS_E2A_R3_CANFD2_V11','Low',XCP_CONFIGURATION_WS_CVPAM,'XCP_Configuration_WS'],
    
    # }

#Report Upload parameters
Project='VID3-PF'
UPLOAD_FOLDER = r'D:\Jenkins\Final_Test_Reports'
Release_File_Path=r'D:\Jenkins\CTC_Release.txt'

#Handshake Result to main server
MAIN_Server_Report_Path= r'D:\Jenkins\Concise_Reports'
TSE_Name_Path=r'D:\Jenkins\Concise_Reports\TSE_Name.txt'
Test_Result_Path=r'D:\Jenkins\Concise_Reports\Test_Result.txt'
Consice_Report_Path=r'D:\Jenkins\Concise_Reports\Full_Report.txt'
Aborted_build_Path=r'D:\Jenkins\Concise_Reports\Aborted_builds.txt'

#Corvus Paths
#TestPath = r'D:\Jenkins\SW_Flash_Files\VBF_Files'

