
#=============================================================================
#  C O P Y R I G H T
#-----------------------------------------------------------------------------
#  Copyright (c) 2019 by Robert Bosch Engineering and Buisiness Limited. All rights reserved.
#
#  This file is property of Robert Bosch Engineering and Buisiness India Limited. Any unauthorised copy, use or 
#  distribution is an offensive act against international law and may be 
#  prosecuted under federal law. Its content is company confidential.
#=============================================================================
#  D E S C R I P T I O N
#-----------------------------------------------------------------------------
#       Projectname: 
#          Synopsis: Regression Test - Python Application Wraper for ATV 
#  Target system(s): win32
#       Compiler(s): python 2.7.16
#===============================================================================================
#  N O T E S
#-----------------------------------------------------------------------------------------------
#  Notes: 
#================================================================================================
#  I N I T I A L   A U T H O R   I D E N T I T Y
#------------------------------------------------------------------------------------------------
#  Name:Sudarshan (RBEI/ESD-PP52), Sunny Kumar (RBEI/ESD-PP52) and Govindaraju T (RBEI/ESD-PP)
#  Department: RBEI/ESD - PP
#================================================================================================
#  R E V I S I O N   I N F O R M A T I O N
#------------------------------------------------------------------------------------------------
## 
## - Reviewed version: 
## - Type (use 'X' to mark):
##     - [ ] Formal Review
##     - [ ] Walkthrough
##     - [ ] Inspection
## - State including date (DD.MM.YYYY)
##     - [--.--.----] Preparation
##     - [--.--.----] Review audit
##     - [--.--.----] Integration of findings
##     - [--.--.----] Test
##     - [--.--.----] Verification of integration of findings
##     - [--.--.----] Review release
## - Responsible:
## - Review-Document:
#=============================================================================
# -----------------------------------------------------------------------------
# Run from Windows command line :  >> python Copy_Report.py 
#
# ----------------------------------------------------------------------------- 

import os,re,time
import sys
import Log
import shutil
import Parameter_List as param
import pyrocopy as robocopy
import pickle 

#*************************************************************
#        OBJECT_INTIALIZATION
#
#*************************************************************
MyLog = Log.LOG(param.logpath+"\\"+'CT_Python_Wraper_Copy_Report.txt')

#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_5: Copy Report file 
# This function is to copy report from source folder to destination folder
# INPUT PARAMETERS:
#           1) string: Source folder path, Destination folder path, TestCase ID
#
# OUTPUT PARAMETERS:
#           1) Dictionary : Test Case Info
#*********************************************************************************************************
def Copy_Report_Set(source, destination,Python_Wraper_log,build_number):
    
    try: 
        # Use Asolute Path       
        src = os.path.abspath(source)
        dst = os.path.abspath(destination)
        Python_Wraper_log_Path= os.path.abspath(Python_Wraper_log)
        #UART_Log_Path= os.path.abspath(UART_Log_Path)
        
        #nowTime = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime())
        #src = os.path.join(src+ '\\' + TC)
        #dst = os.path.join(dst+ '\\' + TC)
        
        #MyLog.Append ("[Copy_Report][info]:::Source path --> " + src)
        #MyLog.Append ("[Copy_Report][info]:::Destination path --> " + dst )
        
        #Create a folder inside destination server path with project name
        dst = os.path.join(dst, param.Project)
        #Create variant name folder
        #dst = os.path.join(dst, TestCaseInfo['variant'])
        #Create folder with Release name
        try:
            with open(param.Release_File_Path,'r') as rls:
                rls_name=rls.read()
                print(rls_name)
            dst = os.path.join(dst, rls_name)
        except Exception as reason:
            print("Error")
            print(reason)

            
            
        #Create jenkins build number folder
        dst = os.path.join(dst, build_number)
        #Create a hardcoded folder called Reports
        dst = os.path.join(dst, 'Reports')
        #Join Destination path till report folder path
        print("Destination path",dst)
        #Use Robocopy to copy from src to destination
        
        if not os.path.exists(dst):
            os.makedirs(dst)
            
        if os.path.exists(dst) or os.stat(src).st_mtime - os.stat(dst).st_mtime > 1:
            MyLog.Append ("[Copy_Report][STATUS]:::Copy Test Report for Build_number" + build_number + ":::START")
            print("STATUS:::Copy Test Report for Build_number" + build_number + ":::START")
            #Ret = subprocess.call(["robocopy",src, dst,"/S"])
            Result=robocopy.copy(src, dst)
            print(Result)
            #Copy the Python_Wraper_log into the same TC folder
            Result=robocopy.copy(Python_Wraper_log_Path, dst)
            #Copy the UART log path             
            #Result=robocopy.copy(UART_Log_Path, dst)
            Ret=True         
             
            if Ret == True:
                MyLog.Append ("[Copy_Report][STATUS]:::Copy Test Report for Build_number" + build_number + ":::SUCCESSFUL")
                print("STATUS:::Copy Test Report for Build_number" + build_number + ":::SUCCESSFUL")
                print("Source path is::: {0}".format(src))
                print(os.path.exists(src))
            if os.path.exists(src):
                MyLog.Append ("[Copy_Report][STATUS]:::Delete Test Report for Build_number" + build_number + " from SOURCE Folder:::START")
                print("STATUS:::Delete Test Report for Build_number" + build_number + " from SOURCE Folder:::START")
                shutil.rmtree(src,ignore_errors=False)
                MyLog.Append ("[Copy_Report][STATUS]:::Delete Test Report for Build_number" + build_number + " from SOURCE Folder:::SUCCESSFUL")
                print("STATUS:::Delete Test Report for Build_number" + build_number + " from SOURCE Folder:::SUCCESSFUL")
                print("STATUS=============================TEST COMPLETED=====================================================")
        else:
            raise
       
    except Exception as reason:
        MyLog.AppendException("[Copy_Report][STATUS]::: Copy_Report_Set in the function :::EXCEPTION:::ERROR[5]")
        MyLog.AppendException(reason)
        print("STATUS::: Copy_Report_Set in the function ::: EXCEPTION[5] ")
        print(reason) 
        sys.exit(1)
 
#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_1: Read TCF file 
# Function name will read TCF file received from Jenkins 
# INPUT PARAMETERS:
#           1) string: TCF File
#
# OUTPUT PARAMETERS:
#           1) Dictionary : Test Case Info
#*********************************************************************************************************
       
def TCF_FileReader_Set(tcfFile):
    try:
        global TestCaseInfo # +++
        global nowTime
        TestCaseInfo = dict() # +++
        nowTime = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime())
        
        MyLog.Append("[TCF_FileReader][STATUS]:::Reading the TCF file:::START")
        print("STATUS:::Reading the TCF file:::START")
        testCaseInfo_pattern = r'TestCase.*Info.([ A-Za-z0-9_]+)\s*=\s*\"(.+)\"'
        testCaseInfo_re = re.compile(testCaseInfo_pattern)
        try:                    
            file=open(tcfFile,'r')
            lines = file.readlines()
            file.close()   
        except Exception as reason:
            MyLog.AppendException("[TCF_FileReader][STATUS]::: Opening TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
            MyLog.AppendException(reason)
            print("STATUS::: Opening TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
            print(reason) 
            sys.exit(1)
        
        for line in lines :
            match = testCaseInfo_re.match(line)
            if match:
                TestCaseInfo[(match.group(1)).strip()] = (match.group(2)).strip()
                MyLog.Append("[TCF_FileReader][Info]:::{0} = {1}".format(match.group(1),match.group(2))) 
                print("Info:::{0} = {1}".format(match.group(1),match.group(2))) 
                
        #Test_Case_Folder=TestCaseInfo['TestCase']+"_TC_"+"_"+nowTime
        MyLog.Append("[TCF_FileReader][STATUS]:::Reading the TCF file:::SUCCESSFUL")
        print("STATUS:::Reading the TCF file:::SUCCESSFUL")
        
    except Exception as reason:
        MyLog.AppendException("[TCF_FileReader][STATUS]::: Reading TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
        MyLog.AppendException(reason)
        print("STATUS::: Reading TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
        print(reason) 
        sys.exit(1)   
def Move_CANoe_reports_Files_Set(src, dest):
    print("< Moving generated HTML report to the report directory > ")
    #@todo : check for valid destination folder exists
    for files in os.listdir(src):
        if ( files.endswith(".html") or files.endswith(".xml")):
            shutil.move(os.path.join(src, files), os.path.join(dest, files)) 
    print("[Copy_Report][Info]:::Find HTML report in path: ",os.path.abspath(dest)," >\n")
    MyLog.Append ("[Copy_Report][Info]:::Find HTML report in path: ",os.path.abspath(dest))


def Concise_Test_Report(build_number):
    try:
        if not os.path.exists(param.MAIN_Server_Report_Path):
            os.makedirs(param.MAIN_Server_Report_Path)

        #with open(param.Test_Result_Path,'r') as rls:
        #result="Success"
            #print(result)

        with open(param.TSE_Name_Path,'r') as tcf:
            tcf_filename=tcf.read()
            #print(tcf_filename)

        to_report=[]
        to_report.append(build_number)
        to_report.append(tcf_filename)
        #to_report.append(result)

        file = open(param.MAIN_Server_Report_Path+'\\Full_Report.txt', "a+")
        for item in to_report:
            file.write(item)
            file.write(' ')

        file.write('\n')       
        file.close

    except Exception as reason:
        MyLog.Append("[Concise_Test_Report][STATUS]::: Handshake Result to Main Path:::EXCEPTION:::ERROR[5]")
        MyLog.AppendException(reason)
        print("[Concise_Test_Report][STATUS]::: Handshake Result to Main Path:::EXCEPTION:::ERROR[5]")
        print(reason)
        sys.exit(1)

        
        
    
    
if __name__ == "__main__":
    try:
        '''
        try:
            Test_Triger_Return = []
            dbfile = open("Test_Triger_Pickle", 'rb')
            db = pickle.load(dbfile)
            for values in db:
                Test_Triger_Return.append(values)
            print(Test_Triger_Return)
            
        except:
            #if len(Test_Triger_Return):
                Test_Triger_Return.append("Dummy Test Folder")
                print("[Copy_Report][Info]:::Pickle file is Empaty, Use Dummy Test Result folder")
        '''
    
        TCF_FileReader_Set(param.TSE_FileName_Path)
        build_number=sys.argv[1]
       
        Copy_Report_Set(param.CANOE_REPORT_FOLDER, param.UPLOAD_FOLDER, param.logpath, build_number)
        Concise_Test_Report(build_number)
            
    finally:
        if MyLog:
            del MyLog 
        '''
        if dbfile:            
            dbfile = open("Test_Triger_Pickle", 'wb')            
            #dbfile.write("")
            dbfile.close()
        '''
        print("################################################ Report Copy Completed ###############################################")
