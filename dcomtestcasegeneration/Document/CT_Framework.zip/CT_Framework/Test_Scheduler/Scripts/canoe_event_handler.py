import Log
import Parameter_List as param




#*************************************************************
#        OBJECT_INTIALIZATION
#
#*************************************************************
MyLog = Log.LOG(param.logpath+"\\"+'CT_Python_Wraper_Test_Trigger.txt')


MyLog.Append("[CANOE_EVENT_HANDLER][STATUS]::: Inside Canoe Event handler:::START")
print("[CANOE_EVENT_HANDLER][STATUS]::: Inside Canoe Event handler:::START")
#print("=================inside canoe_event_handler================")


class TestConfigurationEventHandler:
    MyLog.Append("[CANOE_EVENT_HANDLER][STATUS]::: Inside TestConfigurationEventHandler:::CLASS")
    print("[CANOE_EVENT_HANDLER][STATUS]::: Inside TestConfigurationEventHandler:::CLASS")
    #print("------------inside canoe_event_handler -----------TestConfigurationEventHandler----------------")
    """
    A handler for events that come from a
    test configuration
    """
    
    def __init__(self):
        MyLog.Append("[CANOE_EVENT_HANDLER][STATUS]::: Inside TestConfigurationEventHandler:::INIT")
        print("[CANOE_EVENT_HANDLER][STATUS]::: Inside TestConfigurationEventHandler:::INIT")
        #print("------------inside canoe_event_handler-------__init__---------")
        self.testConfigStarted = False
        
    def OnStart(self):
        MyLog.Append("[CANOE_EVENT_HANDLER][STATUS]::: Inside TestConfigurationEventHandler:::OnStart")
        print("[CANOE_EVENT_HANDLER][STATUS]::: Inside TestConfigurationEventHandler:::OnStart")
        #print("------------inside canoe_event_handler-------OnStart---------")
        """
        Called when a test configuration is
        started.
        """
        self.testConfigStarted = True
        
class MeasurementEventHandler:
    MyLog.Append("[CANOE_EVENT_HANDLER][STATUS]::: Inside MeasurementEventHandler:::CLASS")
    print("[CANOE_EVENT_HANDLER][STATUS]::: Inside MeasurementEventHandler:::CLASS")
    #print("------------ inside canoe_event_handler---------------- MeasurementEventHandler----------------")
    """
    A handler for events that come from a
    measurement
    """
    
    def __init__(self):
        MyLog.Append("[CANOE_EVENT_HANDLER][STATUS]::: Inside TestConfigurationEventHandler:::INIT")
        print("[CANOE_EVENT_HANDLER][STATUS]::: Inside TestConfigurationEventHandler:::INIT")
        #print("------------inside canoe_event_handler--------------------__init__---------")
        self.measurementStarted = False
        self.measurementStopped = False
        
    def OnStart(self):
        MyLog.Append("[CANOE_EVENT_HANDLER][STATUS]::: Inside TestConfigurationEventHandler:::OnStart")
        print("[CANOE_EVENT_HANDLER][STATUS]::: Inside TestConfigurationEventHandler:::OnStart")
        #print("------------inside canoe_event_handler--------------------OnStart---------")
        """
        Called when a measurement is
        started.
        """
        self.measurementStarted = True
        
    def OnStop(self):
        MyLog.Append("[CANOE_EVENT_HANDLER][STATUS]::: Inside TestConfigurationEventHandler:::OnStop")
        print("[CANOE_EVENT_HANDLER][STATUS]::: Inside TestConfigurationEventHandler:::OnStop")
        #print("------------inside canoe_event_handler--------------------OnStop---------")
        """
        Called when a measurement is
        stopped.
        """
        self.measurementStopped = True
