#!/usr/bin/python
'''
Created on Feb 25, 2019

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import sys, json, time, datetime
from .import set_xml_params

class RqmExSchedule(object):
	"""
	Execution Schedules 
	"""
	def __init__(self, connection):
		self.connection = connection
		self.rqm_item = 'executionsequence'
		
	def create_execution_schedule(self, xml_path, param_dict, title):
		"""
		creates execution schedule on RQM by referring to 
		executionsequence.xml file
		"""
		exschedule_id = self.connection.fetch_web_id_by_title(self.rqm_item,\
														title)
		if exschedule_id is None:
			xml_text = set_xml_params.set_xml_parameters(xml_path, param_dict)
			result = self.connection.post(self.connection.resources_url + '/' +\
										self.rqm_item, xml_text)
	#		print "Slug id: ",result.headers['Content-Location']
			exschedule_id = self.connection.fetch_webid_from_slug(self.rqm_item,\
											result.headers['Content-Location'])
		return exschedule_id
	
	def update_scheduleStart_on_exe_schedule(self, exesched_id):
		"""
		updates scheduleStart time to gm time
		"""
		start_time = datetime.datetime.strftime(datetime.datetime.now() - \
			datetime.timedelta(minutes=29,hours=5), "%Y-%m-%dT%H:%M:%S.000Z")
		print("setting scheduleStart time to: {0}".format(start_time))
		result = self.connection.get(self.connection.resources_url + '/' +\
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" +\
				str(exesched_id), "xml")
		insert_elements = {'scheduleStart' : start_time}
		xml_content = set_xml_params.update_xml_parameters(result, \
														insert_elements)
		result = self.connection.put(self.connection.resources_url +\
		'/' + self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" + exesched_id,
		  xml_content)
	