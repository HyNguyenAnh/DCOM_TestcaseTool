#!/usr/bin/python

#=============================================================================
#  C O P Y R I G H T
#-----------------------------------------------------------------------------
#  Copyright (c) 2019 by Robert Bosch Engineering and Buisiness Limited. All rights reserved.
#
#  This file is property of Robert Bosch Engineering and Buisiness India Limited. Any unauthorised copy, use or 
#  distribution is an offensive act against international law and may be 
#  prosecuted under federal law. Its content is company confidential.
#=============================================================================
#  D E S C R I P T I O N
#-----------------------------------------------------------------------------
#       Projectname: 
#          Synopsis: RQM Test Result Updater
#  Target system(s): win32
#       Compiler(s): python 2.7.16
#=============================================================================
#  N O T E S
#-----------------------------------------------------------------------------
#  Notes: 
#=============================================================================
#  I N I T I A L   A U T H O R   I D E N T I T Y
#-----------------------------------------------------------------------------
#  Name: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR and Govindaraju T (RBEI/ESD-PP5) <govindaraju.t@in.bosch.com> gat2kor
#  Department: RBEI/ESD - PP
#=============================================================================
#  R E V I S I O N   I N F O R M A T I O N
#-----------------------------------------------------------------------------
## 
## - Reviewed version: 
## - Type (use 'X' to mark):
##     - [X] Formal Review
##     - [ ] Walkthrough
##     - [ ] Inspection
## - State including date (DD.MM.YYYY)
##     - [20.05.2019] Intial Version adapted from ECQ to ESD-PP by Udaya Hegde (RBEI/ECQ3)
##     - [08.06.2019] Adapted Project Specific details of ESD-PP by Govindaraju T (RBEI/ESD-PP5)
##     - [03.10.2019] Adapted Test_Environemnt details for test execution record creation by Govindaraju T (RBEI/ESD-PP5)
##     - [--.--.----] Review audit
##     - [--.--.----] Integration of findings
##     - [--.--.----] Test
##     - [--.--.----] Verification of integration of findings
##     - [--.--.----] Review release
## - Responsible:
## - Review-Document:
#=============================================================================
# -----------------------------------------------------------------------------
# Run from Windows command line :  >> 
#python rqm_update.py -r "D:\\Automation\\RQM_Updater\\RQM_Updater_Text_file\\Test_Result\\Out_put.txt" -l "D:\\Automation\\RQM_Updater\\RQM_Updater_Text_file\\Test_Result\\Results_Log"
#cofig : contains the project under the RQM example : ATV_PJ-AS (qm)
# Please make sure you have placed correct rqm_account.cfg under the C:\Users\gta2kor\rqm_account.cfg folder as an example 
#
# ----------------------------------------------------------------------------- to update test results into RQM automatically.
import sys, random, time, os, glob 
sys.path.append(os.path.join("..", "..", "rqmscripts"))
import xml.etree.ElementTree as ET
from .import connect
from . import buildrecord
from . import builddefinition
from . import testsuiteexecutionrecord
from .import testsuite
from .import testplan
from .import executionworkitem
from .import executionresult
from .import executionsequence
from .import testsuitelog
from .import testenvironment
from .import testcase
from .import testscript
from .import testphase
from .import ESD_PP5_xml_parser
import re
import argparse
from collections import defaultdict 	
import shutil

def Main_Testcase(config,Test_Case,parameter):
    # Check commandline parameters
    #configfile_path = "C:\\t\\j\\rqm_update_scripts\\RQM_Updater.xml"
    # Create session
    rc = connect.RQMconnection(config)
    br = buildrecord.RqmBuildRecord(rc)
    bd = builddefinition.RqmBuildDefinition(rc)
    tp = testplan.RqmTestPlan(rc)
    ts = testsuite.RqmTestSuite(rc)
    tser = testsuiteexecutionrecord.RqmTSER(rc)
    tc = testcase.RqmTC(rc)
    tcer = executionworkitem.RqmTCER(rc)
    er = executionresult.RqmER(rc)
    ex_sec = executionsequence.RqmExSchedule(rc)
    tsl = testsuitelog.RqmTestSuiteRes(rc)
    te = testenvironment.RqmTestEnvironment(rc)
    tscr = testscript.RqmTSc(rc)
    tphase = testphase.RqmTestPhase(rc)
    """
    https://rb-alm-13-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/FV3+%28qm%29/testcase/urn:com.ibm.rqm:testcase:123004
    
    https://rb-alm-13-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/FV3+%28qm%29/executionresult/urn:com.ibm.rqm:executionresult:279995
    """
    my_path = os.path.abspath(os.path.dirname(__file__))
    #Test_Result_Upload_RPU=UART_Path_RPU    
    #Test_Result_Upload_APU=UART_Path_APU
    #print "Received Inputs are:::::"
    #tc.fetch_linked_testscript_from_testcase(Test_Case_ID)
    Test_Case_ID = rc.fetch_web_id_by_title("testcase", Test_Case)    
    status=tc.fetch_parameters_of_testcase(Test_Case_ID, parameter)

    #Step7:Close the RQM Sessions    
    rc.close()

    return status,Test_Case_ID





def main(config,Test_Result_File,Test_Iteration_details,Test_Plan_details,Test_Env_Details):
    # Check commandline parameters
    #configfile_path = "C:\\t\\j\\rqm_update_scripts\\RQM_Updater.xml"
    
    configfile_path=os.path.join(os.getcwd()+"\\RQM_Updater.xml")
    Test_comment=[]
#    if len(sys.argv) > 1:
#        iteration_title = sys.argv[1]
#    else:
#        iteration_title = raw_input("Please enter the iteration name [FV0100_v0.57_pirateNewestNi_sc0sec]: ")
#    iteration_title = "V3M_010_v0.2"
    
#    config = "VID3-PF (qm)"
    # Create session
    rc = connect.RQMconnection(config)
    br = buildrecord.RqmBuildRecord(rc)
    bd = builddefinition.RqmBuildDefinition(rc)
    tp = testplan.RqmTestPlan(rc)
    ts = testsuite.RqmTestSuite(rc)
    tser = testsuiteexecutionrecord.RqmTSER(rc)
    tc = testcase.RqmTC(rc)
    tcer = executionworkitem.RqmTCER(rc)
    er = executionresult.RqmER(rc)
    ex_sec = executionsequence.RqmExSchedule(rc)
    tsl = testsuitelog.RqmTestSuiteRes(rc)
    te = testenvironment.RqmTestEnvironment(rc)
    tscr = testscript.RqmTSc(rc)
    tphase = testphase.RqmTestPhase(rc)
    """
    https://rb-alm-13-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/FV3+%28qm%29/testcase/urn:com.ibm.rqm:testcase:123004
    
    https://rb-alm-13-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/FV3+%28qm%29/executionresult/urn:com.ibm.rqm:executionresult:279995
    """
    my_path = os.path.abspath(os.path.dirname(__file__))
    #Test_Result_Upload_RPU=UART_Path_RPU	
    #Test_Result_Upload_APU=UART_Path_APU
    #print "Received Inputs are:::::"
    #print UART_Path_RPU
    #print UART_Path_APU	
    #Step2:Fetch the details of Test_Plan, Test_Iteration etc... from the config file RQM_Project_Details.xml
    #try:
        #config_dict = {}
        #config_dict.update({"Parent_TestPlan" : child.text})
#        if os.path.exists(configfile_path):
#            tree = ET.parse(configfile_path)
#            xml_root = tree.getroot()
#            print "Reading Config file: ", configfile_path
#            for child in xml_root:
#                if child.attrib == {}:
#                    config_dict.update({child.tag : child.text})
#                else:
#                    config_dict.update({child.tag : child.attrib})                   
#        else:
#            print "File does not exist: {0}".format(configfile_path)
    #except Exception, reason:
    #    print "Exception in fetching configuration parameters"
    #    print reason
    #print config_dict

#Step3:Extract the Test_Plan, Test_Iteration and Test_environment ID from the RQM  
    #iteration_title = config_dict["iteration"]
    #iteration_title = Test_Iteration_details
    #mtp_id = rc.fetch_web_id_by_title("testplan", config_dict["Parent_TestPlan"])
    #mtp_id = rc.fetch_web_id_by_title("testplan", Test_Plan_details)
    mtp_id = Test_Plan_details
    if mtp_id is None:
        print("Master Test plan: {0} doesn't exist".format(Test_Plan_details))
        sys.exit(1)
#Fetching the Test_iteration ID    
    iteration_title = Test_Iteration_details
    iteration_id = tphase.filter_iteration_based_on_testplan_and_title(mtp_id,iteration_title) 
    #Fetching the Test_Environment  ID
    #Env_Title=config_dict["Test_Environment"]

    Env_Title=Test_Env_Details                                                                
    #Environment_id="TE1672"
    Environment_id = Test_Env_Details  
    print("Test Environment ID is ::::::")
    print(Environment_id)   
    #Check we are getting the response for  iteration_id and Environment_id
    if iteration_id is None:
        print("Iteration : {0} doesn't exist".format(iteration_title))
        sys.exit(1)
            
    if Environment_id is None:
        print("Iteration : {0} doesn't exist".format(iteration_title))
        sys.exit(1)
        
#Step4: Get the Test results from ADTF log and append the rqmid_steps_result dictionary and he format of Dictionary is  rqmid_steps_result={'196738': {'1': 'pass',"2":"pass"}}
#Currently below steps are hardcoded in future it will replace by Test_result fetched from ADTF file     

    #Step4.1 read the output.txt file
    xml_files = glob.glob(Test_Result_File + "\\*_report.xml")
    for xmlfile in xml_files:
        print("Received XML file is {}".format(xmlfile))
        rqmid_steps_result = ESD_PP5_xml_parser.fetch_rqm_testcase_id_steps_results(xmlfile)                

##    for files in os.listdir(Test_Result_File):
##        if (files.endswith("_report.xml")):
##            xmlfile = files
    
   
                    
    
    print("Extracted RQM test result is ")
    print(rqmid_steps_result)
    for tc_id, rqm_steps_result in rqmid_steps_result.items():
        print("Inside for loop {0}".format(tc_id))
        try:            
            tscrpt_id = tc.fetch_linked_testscript_from_testcase(tc_id)
            title = tc.fetch_parameters_of_testcase(tc_id, "title")
            param_dict ={
        'title': title,
        'creator' : {'resource': rc.baseurl + "/jts/resource/itemName/com.ibm.team.repository.Contributor/" + rc.username},
        'owner' : {'resource':rc.baseurl + "/jts/resource/itemName/com.ibm.team.repository.Contributor/" + rc.username},
        'weight' : '100',
        'projectArea' : {"href": rc.baseurl + "/qm/resource/itemOid/com.ibm.team.process.ProjectArea/{0}".format(rc.projectarea), "alias":rc.projectarea},
        'testcase' : {'href' : rc.baseurl+ rc.resources_url + "/testcase/urn:com.ibm.rqm:testcase:" + tc_id},
        'testscript' : {'href' : rc.baseurl+ rc.resources_url + "/testscript/urn:com.ibm.rqm:testscript:" + tscrpt_id},
        'testplan' : {'href':rc.baseurl+ rc.resources_url + "/testplan/urn:com.ibm.rqm:testplan:" + mtp_id},
        'testphase' : {'href':rc.baseurl+ rc.resources_url + "/testphase/urn:com.ibm.rqm:testphase:" + iteration_id},
            'configuration' : {'href':rc.baseurl+ rc.resources_url + "/configuration/" + Environment_id}
            }
            #xml_path = os.path.join(my_path, "..", "..", "rqmscripts", "xml/executionworkitem.xml")
            xml_path = os.path.join(my_path, "xml/executionworkitem.xml")                        
            tcer_id = tcer.generate_new_testcase_execution_record(xml_path, param_dict, title)
        #    tcer_id = tcer.filter_tcer_based_on_testplan_iteration_and_testcase(mtp_id, tc_id, iter_id)
            if tcer_id is None:
                print("TCER not found for Testcase: {0}".format(tc_id))
            else:
                req_id = er.create_testcase_result_from_utility(tcer_id)
                time.sleep(10)
                cur_tcr_href = tcer.fetch_parameters_of_executionworkitem(tcer_id, "currentexecutionresult")
                cur_tcr = rc.fetch_webid_from_href(cur_tcr_href["href"], "executionresult")
            fail_found = False
            for step_index, result in rqm_steps_result.items():
                print("Result of Step {0} is -> {1}".format(step_index, result))
                print(xmlfile)
                #upload_response = rc.upload("/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/{0}/attachment".format(rc.projectarea),
                #      xmlfile)
                #er.find_description_and_update_stepresults_from_executionresult(cur_tcr, 
                #            rqm_steps_result, upload_response.headers['Location'])
                
                if result == "fail":
                    fail_found = True
                    print("Attaching xml file ")
                    print(xmlfile)
#                    upload_response = rc.upload("/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/{0}/attachment".format(rc.projectarea),
#                          xmlfile)
#                    er.find_description_and_update_stepresults_from_executionresult(cur_tcr, 
#                                rqm_steps_result, upload_response.headers['Location'])
            if fail_found:
                er.set_testcaseresult(cur_tcr,"Failed","com.ibm.rqm.execution.common.state.failed")
            else:
                print ("Inside Pass")
                er.set_testcaseresult(cur_tcr,"Passed","com.ibm.rqm.execution.common.state.passed")
            upload_response = rc.upload("/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/{0}/attachment".format(rc.projectarea),
                      xmlfile)
            er.find_description_and_update_stepresults_from_executionresult(cur_tcr, 
                           rqm_steps_result, upload_response.headers['Location'])
        except:
            print(":::::::::::::: Exception in RQM Update Check in RQM for more details::::::::::::")
	
	

    #Step7:Close the RQM Sessions    
    rc.close()
	
def RQM_Test_Init(Test_results_File,Test_Iteration_details,Test_Plan_details,Test_Env_Details,config):  
    print("Updating results for project: {0}".format(config))
    main(config,Test_results_File,Test_Iteration_details,Test_Plan_details,Test_Env_Details)
    print("Completed : Updating results for project: {0}".format(config))
           


#RQM_Test_Init(Test_Result_file_Path[0],Test_Iteration_details,Test_Plan_details,Test_Env_Details)


    
    #If user calls the python file as stand alone then below function will be executed  
if __name__ == "__main__":
    
		
    ## check selected action and go to correct function
        config = "VID3-PF (qm)"
        print("Updating results for project: {0}".format(config))
        main(config)
        print("Completed : Updating results for project: {0}".format(config))
        #print "End COndition::::Cleaning up the results fule"
        #f = open("D:\IBS_DOMAIN_TEST_REPORTS\Out_put.txt")
        #f2 = open("D:\IBS_DOMAIN_TEST_REPORTS\Out_put.txt_Overall.txt", "a")
        #for line in f.readlines():
        #    f2.write("\n")
        #    f2.write(line)
        #shutil.copy('D:\IBS_DOMAIN_TEST_REPORTS\Out_put.txt', 'D:\IBS_DOMAIN_TEST_REPORTS\Out_put_New.txt')
        #open("D:\IBS_DOMAIN_TEST_REPORTS\Out_put.txt", "w").close()
        
