#!/usr/bin/python
'''
Created on Nov 15, 2018

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import sys, os, time, re
import requests
from .import config
import json
import urllib3
from urllib.parse import urlparse
#import mimetools
import mimetypes
import io
import http
import json
import string
import random

class RQMconnection(object):
    """
    Contains methods for Authentication, Logout and get data
    """                                       
    def __init__(self, domain):
        """
        Logs into RQM server
        """
        # Get URL, account and proxy settings
        ra = config.RQMAccount(domain)
        self.baseurl = ra.baseurl
        self.projectarea = ra.projectarea
        self.projectName = domain
        if os.path.exists(ra.rqmexeutility):
            self.rqmexeutility= ra.rqmexeutility
        else:
            print("{0} Doesn't exist. Exiting".format(ra.rqmexeutility))
            sys.exit(1)
        
        self.create_rtc_defect_report_on_failure = ra.create_rtc_defect_report_on_failure
        self.integration_url = "/qm/service/com.ibm.rqm.integration.service.IIntegrationService"
        self.resources_url = self.integration_url + "/resources/" + self.projectarea
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        self.session = requests.Session()

        # Prepare login request
        url1=self.baseurl+ '/jts/authenticated/identity'
        
        try:
            self.session.post(url1, verify=False)
        except requests.exceptions.RequestException as err:
            print(err)
        self.save_cookies(self.session.cookies, "cookies.txt")

        url2=self.baseurl+'/jts/authenticated/j_security_check'
        data = ra.credentials
        self.username = data['j_username']
        self.passw = data['j_password']
        # Login
        
        try:
            response=self.session.post(url2,
                                cookies=self.load_cookies("cookies.txt"),
                                data=data, verify=False)
            self.save_cookies(self.session.cookies, "cookies.txt")
        except requests.exceptions.RequestException as err:
            print(err)
            sys.exit(1)

        # Get sessionid
        if response.status_code != 200:
            print(("Connect to RQM server failed: {} {}".format(
                                        response.status_code, response.reason)))
            sys.exit(1)
        return

    def save_cookies(self, resp, filename):
        """
        saves cookies to cookies.txt file
        """
        with open(filename, "w") as f:
            json.dump(requests.utils.dict_from_cookiejar(resp), f)

    def load_cookies(self, filename):
        """
        loads stored cookies
        """
        with open(filename, 'r') as f:
            return requests.utils.cookiejar_from_dict(json.load(f))

    def get(self, command, accept = "json"):
        """
        sends http GET command. Used to get info from RQM
        """
        get_headers = {
                'User-Agent': 'XX',
                'X-Jazz-CSRF-Prevent': '00000rnhTpKTC1cBLg0wU714vS9:-1',
                'OSLC-Core_Version': '2.0',
                'Accept': 'application/' + accept,
                'Content-Type': 'application/x-www-form-urlencoded',
                }
        # Prepare request
        url=self.baseurl+command
        print("Command to be send")
        print(url)

        # GET request
        try:
            response = requests.get(url, headers=get_headers,
                        cookies=self.load_cookies("cookies.txt"), verify=False)
        except requests.exceptions.RequestException as e:
            print(e)
            sys.exit(1)

        return response.text

    def post(self, command, xml_path):
        """
        send http POST command to RQM server. Used to create RQM items
        """
        post_headers = {
                'User-Agent': 'XX',
#                'X-Jazz-CSRF-Prevent': '00000rnhTpKTC1cBLg0wU714vS9:-1',
                'OSLC-Core_Version': '2.0',
                'Accept': 'text/xml',
                'Content-Type': "text/xml; encoding=utf-8"
                }
        # Prepare request
        url=self.baseurl+command
        # POST request
        try:
            response = self.session.post(url,
                cookies=self.load_cookies("cookies.txt"),
                headers=post_headers, data=xml_path,
                verify=False)
        except requests.exceptions.RequestException as e:
            print(e)
            sys.exit(1)
        if response.status_code == 201:
            print("Record created")
        else:
            print("Record not created:{}\n{}".format(response.status_code,
                                                     response.text))
        return response

    def put(self, command, xml_path):
        """
        send http PUT command to RQM server. Used to create RQM items
        """
        post_headers = {
                'User-Agent': 'XX',
#                'X-Jazz-CSRF-Prevent': '00000rnhTpKTC1cBLg0wU714vS9:-1',
                'OSLC-Core_Version': '2.0',
                'Accept': 'text/xml',
                'Content-Type': "text/xml; encoding=utf-8"
                }
        # Prepare request
        url=self.baseurl+command
        # POST request
        try:
            response = self.session.put(url, \
                cookies=self.load_cookies("cookies.txt"),\
                headers=post_headers, data=xml_path,\
                verify=False)
        except requests.exceptions.RequestException as e:
            print(e)
            sys.exit(1)
        if response.status_code == 200:
            print("Record updated")
        else:
            print("Record not updated:{}\n{}".format(response.status_code, \
                                                     response.text))
        return response

    def upload(self, command, uploadfile):
        """
        uploads attachment to RQM and returns the response
        """
        if os.path.exists(uploadfile):
            filesize = os.path.getsize(uploadfile)
            if filesize > 5120000:
                print("Can't upload. File bigger than 5 MB")
        else:
            print("Attachment file doesn't exist at : {0}".format(uploadfile))
            sys.exit(1)
        filename = os.path.basename(uploadfile)
        _BOUNDARY_CHARS = string.digits + string.ascii_letters
        def escape_quote(s):
            return s.replace('"', '\\"')
        
        boundary = ''.join(random.choice(_BOUNDARY_CHARS) for i in range(30))
        lines = []
        file_cont = str(open(uploadfile,'rb').read())
        fields = {}
        files = {'file': {'filename': filename, 'content': file_cont}}
        for name, value in list(fields.items()):
            lines.extend((
                '--{0}'.format(boundary),
                'Content-Disposition: form-data; name="{0}"'.format(escape_quote(name)),
                '',
                str(value),
            ))
    
        for name, value in list(files.items()):
            filename = value['filename']
            if 'mimetype' in value:
                mimetype = value['mimetype']
            else:
                mimetype = mimetypes.guess_type(filename)[0] or 'application/octet-stream'
            lines.extend((
                '--{0}'.format(boundary),
                'Content-Disposition: form-data; name="{0}"; filename="{1}"'.format(
                        escape_quote(name), escape_quote(filename)),
                'Content-Type: {0}'.format(mimetype),
                '',
                value['content'],
            ))
    
        lines.extend((
            '--{0}--'.format(boundary),
            '',
        ))
        body = '\r\n'.join(lines)
        headers = {
            'Content-Type': 'multipart/form-data; boundary={0}'.format(boundary),
            'Content-Length': str(len(body))}
        url=self.baseurl+command
        print("Uploading Rest API command")
        print(url)
        try:
            response = self.session.post(url, data=body,
                    headers=headers, verify=False)
        except requests.exceptions.RequestException as e:
            print(e)
            sys.exit(1)
        if response.status_code == 201:
            print("Attachment uploaded")
            print(response.headers['Location'])
        else:
            print("Attachment not uploaded:{0}\n{1}".format(response.status_code, \
                                                  response.text))
        return response
    

    def upload_comment(self, command, Paramaeter):
        """
        uploads attachment to RQM and returns the response
        """

#        filename = os.path.basename(uploadfile)
#        _BOUNDARY_CHARS = string.digits + string.ascii_letters
#        def escape_quote(s):
#            return s.replace('"', '\\"')
        
#        boundary = ''.join(random.choice(_BOUNDARY_CHARS) for i in range(30))
#        lines = []
#        file_cont = str(open(uploadfile,'rb').read())
#        fields = {}
#        files = {'file': {'filename': filename, 'content': file_cont}}
 #       for name, value in fields.items():
 #           lines.extend((
 #               '--{0}'.format(boundary),
 #               'Content-Disposition: form-data; name="{0}"'.format(escape_quote(name)),
 #               '',
 #               str(value),
 #           ))
    
#        for name, value in files.items():
#            filename = value['filename']
#            if 'mimetype' in value:
#                mimetype = value['mimetype']
#            else:
#                mimetype = mimetypes.guess_type(filename)[0] or 'application/octet-stream'
#            lines.extend((
#                '--{0}'.format(boundary),
#                'Content-Disposition: form-data; name="{0}"; filename="{1}"'.format(
#                        escape_quote(name), escape_quote(filename)),
#                'Content-Type: {0}'.format(mimetype),
#                '',
#                value['content'],
#            ))
    
#        lines.extend((
#            '--{0}--'.format(boundary),
#            '',
#        ))
#        body = '\r\n'.join(lines)

#        headers = {
#            'Content-Type': 'multipart/form-data; boundary={0}'.format(boundary),
#            'Content-Length': str(len(body))}
        url=self.baseurl+command
        print("Uploading Rest API command")
        print(url)
        try:
            response = self.session.post(url, data=Paramaeter,verify=False)
        except requests.exceptions.RequestException as e:
            print(e)
            sys.exit(1)
        if response.status_code == 201:
            print("Attachment uploaded")
            print(response.headers['Location'])
        else:
            print("Attachment not uploaded:{0}\n{1}".format(response.status_code, \
                                                  response.text))
        return response

    
    
    
    def close(self):
        """
        Logs out of RQM
        """
        # Prepare request
        JAZZ_LOGOUT_URL = "/qm/service/com.ibm.team.repository.service.internal.ILogoutRestService"
        url=self.baseurl+JAZZ_LOGOUT_URL

        # logout request
        try:
            self.session.post(url, cookies=self.load_cookies("cookies.txt"),
                              verify=False)
        except requests.exceptions.RequestException as e:
            print(e)
            sys.exit(1)
        print("logged out of RQM server")

    def fetch_webid_from_slug(self, rqm_item, slug_id):
        """
        accepts slug id from http response headers and gets corresponding webid
        """
        webid = None
        result = self.get(self.resources_url + '/' +\
                             rqm_item + '/' + slug_id)
        jdata = json.loads(result)
        try:
            webid = jdata[rqm_item]['webId']
            print("Web ID of {0}: {1}".format(rqm_item,webid))
        except Exception as err:
            print(err)
        finally:
            return webid

    def fetch_web_id_by_title(self, rqm_item, title):
        """
        fetches id of web element by its title
        https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.
        service.IIntegrationService/resources/Gen4+QM/$rqm_item
        ?fields=feed/entry/content/$rqm_item[title='Test']
        """
        web_id = None
        command = self.resources_url + '/' + rqm_item +\
         "?fields=feed/entry/content/" + rqm_item +\
         "[title='{0}']".format(title)                    
        result = self.get(command)                
        jdata = json.loads(result)
        
        try:
            try:
                web_href = jdata["feed"]["entry"]["id"]
            except Exception as err:
                web_href = jdata["feed"]["entry"][0]["id"]
            web_hrefend = web_href.split("/")[-1]
            try:
                web_id = self.fetch_webid_from_slug(\
                            rqm_item, web_hrefend)
            except Exception as err:
                web_id = web_hrefend.split(":")[-1]
        except Exception as err:
            print("Exception in fetch_web_id_by_title: {0}".format(err))
            web_id = None
        finally:
            print("Web ID of {0} with title: {1} is : {2}".format(rqm_item,
                                        title, web_id))
            return web_id
        
    def fetch_webid_from_href(self, href, rqm_item):
        """
        accepts href gets corresponding webid
        """
        webid = None
        parsed_uri = urlparse(href)
        server_name = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
        href_strip = href.replace(server_name, "/")
        result = self.get(href_strip)
        jdata = json.loads(result)
        try:
            webid = jdata[rqm_item]['webId']
#            print "Web ID : {0}".format(webid)
        except Exception as err:
            print(err)
        finally:
            return webid
        
    def fetch_identifier_by_title(self, rqm_item, title):
        """
        fetches identifier from title
        """
        identifier_id = None
        command = self.resources_url + '/' + rqm_item +\
         "?fields=feed/entry/content/" + rqm_item +\
         "[title='{0}']".format(title)
        result = self.get(command)        
        jdata = json.loads(result)
        try:
            identifier = jdata[rqm_item]['identifier']
            if identifier is not None:
                match = re.search("urn:com.ibm.rqm:{0}:(\d*)".format(rqm_item),
                                  identifier)
                if match:
                    identifier_id = match.group(1)
                
                
#            print "Web ID : {0}".format(webid)
        except Exception as err:
            print(err)
        finally:
            return identifier_id
        