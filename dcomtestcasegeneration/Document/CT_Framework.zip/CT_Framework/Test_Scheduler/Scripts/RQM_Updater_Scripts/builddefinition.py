#!/usr/bin/python
'''
Created on Feb 26, 2019

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import sys
import json
from .import set_xml_params

class RqmBuildDefinition(object):
	"""
	Build definition
	"""
	def __init__(self, connection):
		self.connection = connection
		self.rqm_item = 'builddefinition'

	def create_build_definition(self, xml_path, param_dict, title):
		"""
		creates build defintion on RQM by referring to builddefintion.xml file
		"""
		builddef_id = self.connection.fetch_web_id_by_title(self.rqm_item,\
															title)
		if builddef_id is None:
			xml_text = set_xml_params.set_xml_parameters(xml_path, param_dict)
			result = self.connection.post(self.connection.resources_url + '/' +\
										self.rqm_item, xml_text)
	#		print "Slug id: ",result.headers['Content-Location']
			builddef_id = self.connection.fetch_webid_from_slug(\
							self.rqm_item, result.headers['Content-Location'])
		return builddef_id
	
	def add_build_record_to_builddef(self, builddef_id, buildrec_id):
		"""
		adds build record to build definition.
		"""
		print("add buldrec: {0} to builddef: {1}".format(builddef_id, buildrec_id))
		result = self.connection.get(self.connection.resources_url + '/' +\
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" +\
				str(builddef_id), "xml")
		insert_elements = {'buildrecord' : ["ns2",
{"href" : 'https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/{0}/buildrecord/urn:com.ibm.rqm:buildrecord:'.format(self.connection.projectarea) +\
 buildrec_id}]}
		xml_content = set_xml_params.insert_xml_parameter(result, \
														insert_elements)
		result = self.connection.put(self.connection.resources_url +\
		'/' + self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" + builddef_id,
		  xml_content)