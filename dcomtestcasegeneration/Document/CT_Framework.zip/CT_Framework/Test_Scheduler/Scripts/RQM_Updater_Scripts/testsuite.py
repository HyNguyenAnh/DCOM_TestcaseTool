#!/usr/bin/python
'''
Created on Nov 15, 2018

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import json, sys, os
import re
from .import set_xml_params

class RqmTestSuite(object):
	"""
	Test suite
	"""
	def __init__(self, connection):
		self.connection = connection
		self.rqm_item = 'testsuite'

	def get_all(self):
		"""
		lists all test suites in given project
		"""
		tser = {}
		result = self.connection.get(self.connection.resources_url + '/' + \
									self.rqm_item)
		jdata = json.loads(result)
		try:
			for eachentry in jdata["feed"]["entry"]:
				match = re.search(self.rqm_item + ":(\d*)", eachentry["id"])
				tser.update({eachentry["title"]["content"] : match.group(1)})
		except Exception as err:
			print(err)
		finally:
			return tser

	def create_testsuite(self, xml_path, param_dict, title):
		"""
		creates test suite on RQM by referring to testsuite.xml file
		"""
		testsuite_id = self.connection.fetch_web_id_by_title(self.rqm_item,\
															title)
		if testsuite_id is None:
			xml_text = set_xml_params.set_xml_parameters(xml_path, param_dict)
			result = self.connection.post(self.connection.resources_url + '/' +\
										self.rqm_item, xml_text)
			testsuite_id = self.connection.fetch_webid_from_slug(self.rqm_item,
											result.headers['Content-Location'])
		return testsuite_id
	
	def list_testcases_from_a_testsuite(self, testsuite_id):
		"""
		List all testcases based on gibven testsuite 
		"""
		print("Listing Test Cases from testsuite: {0}".format(testsuite_id))
		tcid_list = []
		result = self.connection.get(self.connection.resources_url + \
				'/' + self.rqm_item + '/urn:com.ibm.rqm:'+ self.rqm_item +':' + \
				testsuite_id)
		jdata = json.loads(result)
		try:
			for eachentry in jdata[self.rqm_item]["suiteelements"]["suiteelement"]:
				tc_id = re.search("testcase\:(\d*)", eachentry['testcase']['href'])
#				print str(tc_id.group(1))
				tcid_list.append(tc_id.group(1))

		except Exception as err:
			print(err)
		finally:
			print("Listed Testcases are: {0}".format(tcid_list))
			return tcid_list
	
	def update_attachment_to_testsuite(self, ts_id, attachment_link):
		"""
		updates attachment link to testsuite 
		"""
		result = self.connection.get(self.connection.resources_url + '/' +\
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" +\
				ts_id , "xml")
		insert_elements = {'attachment' : ["ns2", {"href" : attachment_link}]}
		xml_content = set_xml_params.insert_xml_parameter(result, 
															insert_elements)
		result = self.connection.put(self.connection.resources_url +\
		'/' + self.rqm_item + "/urn:com.ibm.rqm:"+ self.rqm_item +":" + ts_id ,
			xml_content)
		