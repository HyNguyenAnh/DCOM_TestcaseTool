#!/usr/bin/python
'''
Created on Nov 15, 2018

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import sys, random
from . import connect
from . import testsuiteexecutionrecord
from . import testsuite
from . import testplan
from . import executionworkitem
from . import executionresult
def main():
    # Check commandline parameters
    if len(sys.argv) > 1:
        sw_version = sys.argv[1]
    else:
        sw_version = input("Please enter the build name [CLEO_18_47.62]: ")
    config = "Gen4 POC"
    # Create session
    rc = connect.RQMconnection(config)
    tp = testplan.RqmTestPlan(rc)
    ts = testsuite.RqmTestSuite(rc)
    tser = testsuiteexecutionrecord.RqmTSER(rc)
    tcer = executionworkitem.RqmTCER(rc)
    er = executionresult.RqmER(rc)
#    update_utility = execution_utility.rqm_updater()
#-------------------------createtestplan---------------------------
    print("Creating Test plan")
    xml_path = "xml/testplan.xml"
    param_dict = {
        "title" : "TP" + "-" + sw_version,
        "creator" : {"resource" : "https://rb-alm-20-p.de.bosch.com/jts/resource/itemName/com.ibm.team.repository.Contributor/" + rc.username},
        "projectArea" : {"href":"https://rb-alm-20-p.de.bosch.com/qm/resource/itemOid/com.ibm.team.process.ProjectArea/_Kpc9wCwvEei7rtxGmnORkA", "alias":rc.domain},
                    }
    #Create a test plan for sw
    tp_id = tp.create_testplan(xml_path, param_dict, param_dict["title"])
#-------------------------/createtestplan---------------------------
#-------------------------createtestsuite---------------------------
    print("Creating Test suite")
    xml_path = "xml/qvt_testsuite.xml"
    param_dict = {
        "title" : "QVT-TS" + "-" + sw_version,
        "creator" : {"resource" : "https://rb-alm-20-p.de.bosch.com/jts/resource/itemName/com.ibm.team.repository.Contributor/" + rc.username},
        "authorid" : {"resource" : "https://rb-alm-20-p.de.bosch.com/jts/resource/itemName/com.ibm.team.repository.Contributor/" + rc.username},
        "sequentialExecution" : "false",
        "projectArea" : {"href":"https://rb-alm-20-p.de.bosch.com/qm/resource/itemOid/com.ibm.team.process.ProjectArea/_Kpc9wCwvEei7rtxGmnORkA", "alias":rc.domain},
        "testplan" : {'href':"https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Gen4+QM/testplan/urn:com.ibm.rqm:testplan:" + tp_id},
                    }
    #Create a testsuite for QVT
    ts_id = ts.create_testsuite(xml_path, param_dict, param_dict["title"])
    tp.link_testsuite_with_testplan(tp_id, ts_id)
#-------------------------/createtestsuite---------------------------
#-------------------------createtestsuiteexecutionrecord-----------------------
    print("Creating Test Suite Execution record")
    xml_path = "xml/suiteexecutionrecord.xml"
    param_dict ={
        'title': 'QVT-TSER' + "-" + sw_version,
        'creator' : {'resource':"https://rb-alm-20-p.de.bosch.com/jts/resource/itemName/com.ibm.team.repository.Contributor/" + rc.username},
        #'owner' : {'resource':"https://rb-alm-20-p.de.bosch.com/jts/resource/itemName/com.ibm.team.repository.Contributor/" + rc.username},
        'weight' : '100',
        'testsuite': {'href':"https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Gen4+QM/testsuite/urn:com.ibm.rqm:testsuite:" + ts_id},
        'projectArea' : {"href":"https://rb-alm-20-p.de.bosch.com/qm/resource/itemOid/com.ibm.team.process.ProjectArea/_Kpc9wCwvEei7rtxGmnORkA", "alias":rc.domain},
        'testplan' : {'href':"https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Gen4+QM/testplan/urn:com.ibm.rqm:testplan:" + tp_id},
                }
    #Generate TSER using above test suite
    tser_id = tser.generate_new_test_suite_execution_record(xml_path, param_dict, param_dict["title"])
#-------------------------/createtestsuiteexecutionrecord----------------------
#    #To be taken care in Test
#    testplan_href = rc.baseurl + rc.resources_url + "/testplan/urn:com.ibm.rqm:testplan:" + tp_id
#    tcer_dict = tcer.list_tcer_based_on_testplan(testplan_href)
#    for tcer_id in tcer_dict.keys():
#        print "Selected TCER ID : {0}".format(tcer_id)
#        tc_id = tcer.fetch_testcase_based_on_tcer(tcer_id)
#
#    #---------------------------createexecutionresult------------------------------
#        xml_path = "xml/executionresult.xml"
#        supported = ["com.ibm.rqm.execution.common.state.passed",
#        "com.ibm.rqm.execution.common.state.failed",
#        "com.ibm.rqm.execution.common.state.blocked",
#        "com.ibm.rqm.execution.common.state.part_blocked",
#        "com.ibm.rqm.execution.common.state.incomplete",
#        "com.ibm.rqm.execution.common.state.perm_failed",
#        "com.ibm.rqm.execution.common.state.deferred",
#        "com.ibm.rqm.execution.common.state.inconclusive",
#        "com.ibm.rqm.execution.common.state.error"]
#        param_dict ={
#            'title': tcer_dict[tcer_id],
#            'state' : random.choice(supported),
#            'creator' : {'resource':"https://rb-alm-20-p.de.bosch.com/jts/resource/itemName/com.ibm.team.repository.Contributor/" + rc.username},
#            #'owner' : {'resource':"https://rb-alm-20-p.de.bosch.com/jts/resource/itemName/com.ibm.team.repository.Contributor/" + rc.username},
#            'weight' : '100',
#            'projectArea' : {"href":"https://rb-alm-20-p.de.bosch.com/qm/resource/itemOid/com.ibm.team.process.ProjectArea/_Kpc9wCwvEei7rtxGmnORkA", "alias":rc.domain},
#            'testcase' : {'href' : "https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Gen4+QM/testcase/urn:com.ibm.rqm:testcase:" + tc_id},
#            'executionworkitem' : { 'href' : "https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Gen4+QM/executionworkitem/urn:com.ibm.rqm:executionworkitem:" + tcer_id},
#            'testplan' : {'href':"https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Gen4+QM/testplan/urn:com.ibm.rqm:testplan:" + tp_id},
#                    }
#    #    #Generate Test case Execution result and update actual result using above created items
#        exres_id = er.generate_new_tc_execution_result(xml_path, param_dict)
#    #-------------------------/createexecutionresult-----------------------
    rc.close()
if __name__ == "__main__":
    main()