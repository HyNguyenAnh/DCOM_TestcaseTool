#!/usr/bin/python
'''
Created on Nov 15, 2018

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import sys
import json
from .import set_xml_params

class RqmTestPlan(object):
	"""
	Test Plan
	"""
	def __init__(self, connection):
		self.connection = connection
		self.rqm_item = 'testplan'

	def create_testplan(self, xml_path, param_dict, title):
		"""
		creates test plan on RQM by referring to testplan.xml file
		"""
		testplan_id = self.connection.fetch_web_id_by_title(self.rqm_item,\
														title)
		if testplan_id is None:
			xml_text = set_xml_params.set_xml_parameters(xml_path, param_dict)
			result = self.connection.post(self.connection.resources_url + '/' +\
										self.rqm_item, xml_text)
	#		print "Slug id: ",result.headers['Content-Location']
			testplan_id = self.connection.fetch_webid_from_slug(self.rqm_item,\
											result.headers['Content-Location'])
		return testplan_id

	def add_child_test_plan_to_master(self, mtp_id, ctp_id):
		"""
		adds child test plan to master test plan. Not working with REST API
		due to a known defect in RQM
		"""
		result = self.connection.get(self.connection.resources_url + '/' +\
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" +\
				mtp_id + "?abbreviate=false&calmlinks=true", "xml")
		insert_elements = {'childplan' : ["ns2", {"href" : 'https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/{0}/testplan/urn:com.ibm.rqm:testplan:'.format(self.connection.projectarea) +\
												 ctp_id}]}
		xml_content = set_xml_params.insert_xml_parameter(result, \
														insert_elements)
		result = self.connection.put(self.connection.resources_url +\
		'/' + self.rqm_item + "/urn:com.ibm.rqm:testplan:" + mtp_id +\
		"?abbreviate=false&calmlinks=true",  xml_content)

	def link_testsuite_with_testplan(self, tp_id, ts_id):
		"""
		links test suite with given testpaln. Updating Testplan
		"""
		result = self.connection.get(self.connection.resources_url + '/' +\
		self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" + \
		tp_id + "?abbreviate=false&calmlinks=true", "xml")
		insert_elements = {'testsuite' : ["ns2", {"href" : 'https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/{0}/testsuite/urn:com.ibm.rqm:testsuite:'.format(self.connection.projectarea) +\
												 ts_id}]}
		xml_content = set_xml_params.insert_xml_parameter(result,\
														insert_elements)

		result = self.connection.put(self.connection.resources_url + \
		'/' + self.rqm_item + "/urn:com.ibm.rqm:testplan:" + tp_id + \
		"?abbreviate=false&calmlinks=true",  xml_content)
	
	def check_testplan_locked(self, tp_id):
		"""
		checks if a testplan is locked. returns True - locked, False - unlocked 
		"""
		result = self.connection.get(self.connection.resources_url + '/' +\
		self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" + \
		tp_id)
		jdata = json.loads(result)
		if jdata[self.rqm_item]["locked"] == "false":
			print("Testplan ID: {0}, lock status: {1}".format(tp_id, False))
			return False
		else:
			print("Testplan ID: {0}, lock status: {1}".format(tp_id, True))
			return True
		