#!/usr/bin/python
'''
Created on Nov 15, 2018

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import json, re
from urllib.parse import urlparse
from .import set_xml_params

class RqmTCER(object):
	"""
	Test Case Execution Record
	"""
	def __init__(self, connection):
		self.connection = connection
		self.rqm_item = 'executionworkitem'

	def list_tcer_based_on_testplan(self, testplan_href):
		"""
		https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.
		service.IIntegrationService/resources/Gen4+QM/executionworkitem?
		fields=feed/entry/content/executionworkitem/(*|testplan[@href=%27
		https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.
		service.IIntegrationService/resources/Gen4+QM/testplan/urn:com.
		ibm.rqm:testplan:77%27])
		"""
		print("Listing TCER from test plan")
		tcerdict = {}
		filter_url = "?fields=feed/entry/content/executionworkitem/(*|testplan[@href='" + testplan_href + "'])"
		result = self.connection.get(self.connection.resources_url + \
									'/' + self.rqm_item + filter_url)
		jdata = json.loads(result)
		try:
			for eachentry in jdata["feed"]["entry"]:
				match = re.search(self.rqm_item + ":(\d*)", eachentry["id"])
				tcerdict.update({match.group(1) :
								eachentry["title"]["content"]})
		except Exception as err:
			print(err)
		finally:
			return tcerdict

	def list_testcases_based_on_tcerlist(self, tcerlist):
		"""
		https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.
		service.IIntegrationService/resources/Gen4+QM/testcase?fields=feed/
		entry/content/testcase/(*|testsuite[@href='https://rb-alm-20-p.de.bosch
		.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/
		resources/Gen4+QM/testsuite/urn:com.ibm.rqm:testsuite:153'])
		"""
		tc_tcer_dict = {}
		print("Listing test cases from TCER")
		for tcer_id in tcerlist:
			result = self.connection.get(self.connection.resources_url + \
				'/' + self.rqm_item + '/urn:com.ibm.rqm:executionworkitem:' + \
				tcer_id)
			jdata = json.loads(result)
			tc_id = jdata[self.rqm_item]["testcase"]["href"]
			tc_id = self.fetch_tc_webid_from_href(tc_id)
			tc_tcer_dict.update({ tc_id : tcer_id})
		return tc_tcer_dict

	def fetch_testcase_based_on_tcer(self, tcer_id):
		"""
		https://rb-alm-20-p.de.bosch.com/qm/service/
		com.ibm.rqm.integration.service.IIntegrationService/resources/Gen4+QM/
		testcase?fields=feed/entry/content/testcase/
		(*|testsuite[@href='https://rb-alm-20-p.de.bosch.com/qm/service/
		com.ibm.rqm.integration.service.IIntegrationService/resources/
		Gen4+QM/testsuite/urn:com.ibm.rqm:testsuite:153'])
		"""
		result = self.connection.get(self.connection.resources_url + \
				'/' + self.rqm_item + '/urn:com.ibm.rqm:executionworkitem:' + \
				tcer_id)
		jdata = json.loads(result)
		tc_id_href = jdata[self.rqm_item]["testcase"]["href"]

		tc_id = self.fetch_tc_webid_from_href(tc_id_href)
		print("Test case ID : {0}".format(tc_id))
		return tc_id

	def fetch_tc_webid_from_href(self, tc_href):
		"""
		accepts href gets corresponding webid
		"""
		webid = None
		parsed_uri = urlparse(tc_href)
		server_name = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
		href_strip = tc_href.replace(server_name, "/")
		result = self.connection.get(href_strip)
		jdata = json.loads(result)
		try:
			webid = jdata['testcase']['webId']
#			print "Web ID : {0}".format(webid)
		except Exception as err:
			print(err)
		finally:
			return webid
		
	def filter_tcer_based_on_testplan_testenv_and_testcase(self, tp_id, tc_id, 
														tenv_id):
		"""
		filter and returns test case execution record ID based in given 
		testplan and test case

		https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.
		IIntegrationService/resources/Gen4+QM/executionworkitem?fields=feed/entry/
		content/executionworkitem/(*|testplan[@href="https://rb-alm-20-p.de.bosch.com/
		qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Gen4+QM/
		testplan/urn:com.ibm.rqm:testplan:228"]|testcase[@href="https://rb-alm-20-p.de.bosch.com/
		qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Gen4+QM/
		testcase/urn:com.ibm.rqm:testcase:14009"]|configuration[@href=
		"https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.
		service.IIntegrationService/resources/Gen4+QM/configuration/TE1294"])
		"""
		tcer_id = None
		filter_url = "?fields=feed/entry/content/" + self.rqm_item + "/(*|testplan[@href='" +\
self.connection.baseurl + self.connection.resources_url + "/testplan/urn:com.ibm.rqm:testplan:{0}']|testcase[@href='".format(tp_id) +\
self.connection.baseurl + self.connection.resources_url + "/testcase/urn:com.ibm.rqm:testcase:{0}']|configuration[@href='".format(tc_id) +\
self.connection.baseurl + self.connection.resources_url + "/configuration/{0}'])".format(tenv_id)
		result = self.connection.get(self.connection.resources_url + \
				'/' + self.rqm_item + filter_url)
		try:
			jdata = json.loads(result)
			if len(jdata["feed"]["entry"]) > 1:
				tcer_id = jdata["feed"]["entry"][0]["content"][self.rqm_item]["webId"]			
			else:
				tcer_id = jdata["feed"]["entry"]["content"][self.rqm_item]["webId"]
		except Exception as reason:
			print("Exception in filter_tcer_based_on_testplan_testenv_and_testcase: {0}".format(reason))
			
		else:			
			print("Filtered tcer_id is: {0}".format(tcer_id))
		return tcer_id
	
	def filter_tcer_based_on_testplan_iteration_and_testcase(self, tp_id, 
															tc_id, iter_id):
		"""
		filter and returns test case execution record ID based in given 
		testplan and test case

		https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.
		IIntegrationService/resources/Gen4+QM/executionworkitem?fields=feed/entry/
		content/executionworkitem/(*|testplan[@href="https://rb-alm-20-p.de.bosch.com/
		qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Gen4+QM/
		testplan/urn:com.ibm.rqm:testplan:228"]|testcase[@href="https://rb-alm-20-p.de.bosch.com/
		qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Gen4+QM/
		testcase/urn:com.ibm.rqm:testcase:14009"]|configuration[@href=
		"https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.
		service.IIntegrationService/resources/Gen4+QM/configuration/TE1294"])
		"""
		tcer_id = None
		filter_url = "?fields=feed/entry/content/" + self.rqm_item + "/(*|testplan[@href='" +\
self.connection.baseurl + self.connection.resources_url + "/testplan/urn:com.ibm.rqm:testplan:{0}']|testcase[@href='".format(tp_id) +\
self.connection.baseurl + self.connection.resources_url + "/testcase/urn:com.ibm.rqm:testcase:{0}']|testphase[@href='".format(tc_id) +\
self.connection.baseurl + self.connection.resources_url + "/testphase/urn:com.ibm.rqm:testphase:{0}'])".format(iter_id)
		result = self.connection.get(self.connection.resources_url + \
				'/' + self.rqm_item + filter_url)
		try:
			jdata = json.loads(result)
			tcer_id = jdata["feed"]["entry"]["content"][self.rqm_item]["webId"]
		except Exception as reason:
			print("Exception in filter_tcer_based_on_testplan_iteration_and_testcase: {0}".format(reason))
			
		else:			
			print("Filtered tcer_id is: {0}".format(tcer_id))
		return tcer_id
	
	def fetch_parameters_of_executionworkitem(self, tcer_id, parameter):
		"""
		fetches specified parameters from test suite log given
		"""
		result = self.connection.get(self.connection.resources_url + '/' + \
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item +\
				 ":" + tcer_id )
		jdata = json.loads(result)
		state = jdata[self.rqm_item][parameter]
		print("Current {0} of Execution work item: {1} is {2}".format(parameter, 
															tcer_id, state))
		return state
	
	def generate_new_testcase_execution_record(self, xml_path, param_dict,\
												title):
		"""
		Generate new test case execution record from test suite
		"""
		tcer_id = None
		xml_text = set_xml_params.set_xml_parameters(xml_path, param_dict)
		result = self.connection.post(self.connection.resources_url + '/' +\
					self.rqm_item, xml_text)
		tcer_id = self.connection.fetch_webid_from_slug(self.rqm_item,
										result.headers['Content-Location'])
		print("Test case execution record created: {0}".format(tcer_id))
		return tcer_id