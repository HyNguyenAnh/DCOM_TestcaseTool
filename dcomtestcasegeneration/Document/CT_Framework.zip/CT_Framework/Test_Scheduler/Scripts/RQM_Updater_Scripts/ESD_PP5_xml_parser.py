'''
Created on May 15, 2019

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR and Govindaraju T (RBEI/ESD-PP5) <govindaraju.t@in.bosch.com> gat2kor
'''
from lxml import etree
import glob, re
    
def fetch_rqm_testcase_id_steps_results(xmlfile):
    rqm_tc_id = None
    rqm_testcase_res = {}
    step_index = '-1'
    step_result = ""
    print("analyzing xml file: {0}".format(xmlfile))
    tree = etree.parse(xmlfile)
    xml_root = tree.getroot()                    
    print("Fetching testcase ID, Test steps and step results")
    found1 = False
    found2 = False
    step_index = '-1'
    step_result = "unknown"
    for testgroup in xml_root.iter("testgroup"):
    #for testgroup in xml_root.findall('testgroup'):
        rqm_tc_id = None
        for externalref in testgroup:
            if ("type" in list(externalref.attrib.keys()) and 
                externalref.attrib['type'] == "RQM"):
                print(externalref.text)
                rqm_tc_id = externalref.text
                break
        if rqm_tc_id is not None:
            rqm_testcase_res.update({rqm_tc_id: {}})
            for testcase in testgroup.iter("testcase"):
                for child in testcase:
                    if "verdict" in child.tag:
        #                print child.attrib["result"]
                        step_result = child.attrib["result"]
                        found1 = True
                    if "title" in child.tag:
                        match = re.search("stepindex\s*=\s*(-\d*|\d*)", child.text)
                        if match:
                            if "-" in match.group(1):
                                pass
                            else:
                                step_index = match.group(1)
                                found2 = True
                        else:
                            print("Step index not found!!!"+child.text)
        #                print child.text
                    if found1 and found2:
                        rqm_testcase_res[rqm_tc_id].update({step_index : step_result})
                        found1 = False
                        found2 = False
                        step_index = '-1'
                        step_result = "unknown"
        else:
            print("ERROR: RQM testcase ID not found for a testgroup!!!")
        
    print(rqm_testcase_res)    
    return rqm_testcase_res
if __name__ == "__main__":
    file_path = r"D:\Jenkins\Test_Report\System_Testing_Automation.tse_2020-10-08-18-50-04"
    xml_files = glob.glob(file_path + "\\*_report.xml")
    for xmlfile in xml_files:       
        fetch_rqm_testcase_id_steps_results(xmlfile)                
