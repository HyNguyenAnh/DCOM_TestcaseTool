#!/usr/bin/python
'''
Created on April 15, 2019

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import json

class RqmTSc(object):
	"""
	Test Case
	"""
	def __init__(self, connection):
		self.connection = connection
		self.rqm_item = 'testscript'

	def fetch_steps_from_testscript(self, tscript_id):
		"""
		fetch all steps from testscript
		"""
		result = self.connection.get(self.connection.resources_url + '/' + \
		 self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" + tscript_id)
		jdata = json.loads(result)
		steps = jdata[self.rqm_item]["steps"]["step"]
		for step in steps:
			print(step["title"] + "\n") 
		print(steps)

	