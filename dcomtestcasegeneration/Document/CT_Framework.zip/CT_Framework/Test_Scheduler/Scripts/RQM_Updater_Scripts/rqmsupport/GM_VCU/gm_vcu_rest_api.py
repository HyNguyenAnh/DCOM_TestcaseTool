#!/usr/bin/python
'''
Created on Mar 11, 2019

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import sys, random, time, os , json
sys.path.append(os.path.join("..", "..", "rqmscripts"))
from collections import Counter
import xml.etree.ElementTree as ET
import connect
import buildrecord
import builddefinition
import testsuiteexecutionrecord
import testsuite
import testplan
import executionworkitem
import executionresult
import executionsequence
import testsuitelog
import testenvironment
from .vtsdemorunner import VtsFirmwareBootHeaderVerification, VtsFirmwareDtboVerification

def read_json(filepath):
    """
    Reads Json data from the file passed
    """
    try:
        with open(filepath, 'r') as jsonfile:
            dictdata = json.load(jsonfile)
            jsonfile.close()
    except BaseException as err:
        print(err)
    for key, value in dictdata.items():
        if isinstance(value, str):
            value = value.encode('utf-8')
            dictdata[key] = value
    return dictdata

def main():
    # Check commandline parameters
#    configfile_path = "gmvcu_config.xml"
    configfile_path = "gmpoc_config.xml"
    if len(sys.argv) > 1:
        sw_version = sys.argv[1]
    else:
        sw_version = input("Please enter the build name [CLEO_18_47.62]: ")
#    config = "GM-VCU"
#    build_def = "8"
    config = "Gen4 POC"
    # Create session
    rc = connect.RQMconnection(config)
    br = buildrecord.RqmBuildRecord(rc)
    bd = builddefinition.RqmBuildDefinition(rc)
    tp = testplan.RqmTestPlan(rc)
    ts = testsuite.RqmTestSuite(rc)
    tser = testsuiteexecutionrecord.RqmTSER(rc)
    tcer = executionworkitem.RqmTCER(rc)
    er = executionresult.RqmER(rc)
    ex_sec = executionsequence.RqmExSchedule(rc)
    tsl = testsuitelog.RqmTestSuiteRes(rc)
    te = testenvironment.RqmTestEnvironment(rc)

    try:
        config_dict = {}
        if os.path.exists(configfile_path):
            tree = ET.parse(configfile_path)
            xml_root = tree.getroot()
            print("Reading Config file: ", configfile_path)
            for child in xml_root:
                if child.attrib == {}:
                    config_dict.update({child.tag : child.text})
                else:
                    config_dict.update({child.tag : child.attrib})                   
        else:
            print("File does not exist: {0}".format(configfile_path))
    except Exception as reason:
        print("Exception in fetching config parameters")
        print(reason)
#    print config_dict

    
    mtp_id = rc.fetch_web_id_by_title("testplan", config_dict["Parent_TestPlan"])
    if mtp_id is None:
        print("Master Test plan: {0} doesn't exist".format(config_dict["Parent_TestPlan"]))
        sys.exit(1)
        
    mtp_lock = tp.check_testplan_locked(str(mtp_id))
    if mtp_lock:
        print("Master Test plan is locked. Exit")
        sys.exit(1)
        
    ctp_id = rc.fetch_web_id_by_title("testplan", config_dict["Child_TestPlan"])
    if ctp_id is None:
        print("Child Test plan: {0} doesn't exist".format(config_dict["Child_TestPlan"]))
        sys.exit(1)

    ctp_lock = tp.check_testplan_locked(str(ctp_id))
    if ctp_lock:
        print("Child Test plan is locked. Exit")
        sys.exit(1)

    ts_id = rc.fetch_web_id_by_title("testsuite", config_dict["HI01"]["testsuite"])
    if ts_id is None:
        print("TestSuite : {0} doesn't exist".format(
                                            config_dict["HI01"]["testsuite"]))
        sys.exit(1)
   
    tser_id = rc.fetch_web_id_by_title("suiteexecutionrecord", config_dict["HI01"]["tser"])
    if tser_id is None:
        print("TestSuite Execution record : {0} doesn't exist".format(
                                            config_dict["HI01"]["tser"]))
        sys.exit(1)
        
    if config_dict["HI01"]["hardware"] in config_dict["HI01"]["tser"]:
        print("TSER exists for : {0}".format(config_dict["HI01"]["hardware"]))
    else:
        print("TSER doesn't exist for : {0}".format(config_dict["HI01"]["hardware"]))
        sys.exit(1)        
#    config_link = tser.fecth_parameters_of_tser(tser_id, "configuration")
#    te_title = te.fecth_parameters_of_testenvironment(config_link, "title")
#    if config_dict["HI01"]["hardware"] in te_title:
#        pass
#    else:
#        print "Test environment doesn't exist for : {0}".format(config_dict["HI01"]["hardware"])
#        sys.exit(1)
        
    tslog_id = tser.fetch_current_testsuitelog_of_tser(tser_id)
    tsl_state = None
    if tslog_id is None:
        print("Testsuitelog to be created by test")
    else:
        tsl_state = tsl.fetch_parameters_of_testsuitelog(tslog_id, "state")
    
    if tsl_state is None:
        pass
    elif tsl_state == "com.ibm.rqm.execution.common.state.inprogress":
        tsl_build = tsl.fetch_parameters_of_testsuitelog(tslog_id, "buildrecord")
        print("Test suite: {0} is being executed with build:{1}".format(ts_id, 
                                                                tsl_build))
        sys.exit(1) 
        
    """
    call script to flash GM-VCU software
    update True if flash successful, False if Flashing failed
    """
    flash_success = True 
    if flash_success:
        buildrec_id = rc.fetch_web_id_by_title("buildrecord", sw_version)
        br.update_status_of_build_record(buildrec_id, 
                                "com.ibm.rqm.buildintegration.buildstatus.ok")
    else:
        br.update_status_of_build_record(buildrec_id, 
                            "com.ibm.rqm.buildintegration.buildstatus.error")
        exit(1)
    testcase_list = ts.list_testcases_from_a_testsuite(ts_id)
    print("Read -> testcase id to Script mapping")
    filepath = "rqm_tcid_funct_mapping.json"
    mapping_dict = read_json(filepath)
    print("Start executing tests for GM-VCU based on list")
    my_path = os.path.abspath(os.path.dirname(__file__))
    xml_path = os.path.join(my_path, "xml/executionresult.xml")
    exres_list = []
    exeresstate_list = []
        #    #Generate Test case Execution result and update actual result using above created items
    for eachtc in testcase_list:
        print("\nExecute testcase -> {0}".format(eachtc))
        functname = mapping_dict[eachtc] + "()"
        print("Calling function-> ", functname)
        rqmresult = eval(functname)#calling testcase function
        print("RQM test case {0} result is : ".format(eachtc),rqmresult)
        supported = ["com.ibm.rqm.execution.common.state.passed",
        "com.ibm.rqm.execution.common.state.failed",
        "com.ibm.rqm.execution.common.state.blocked",
        "com.ibm.rqm.execution.common.state.part_blocked",
        "com.ibm.rqm.execution.common.state.incomplete",
        "com.ibm.rqm.execution.common.state.perm_failed",
        "com.ibm.rqm.execution.common.state.deferred",
        "com.ibm.rqm.execution.common.state.inconclusive",
        "com.ibm.rqm.execution.common.state.error"]
        if rqmresult not in supported:
            print("Invalid test case result: {0}".format(rqmresult))
            exit(1)
        exeresstate_list.append(rqmresult)
        tcer_id = tcer.filter_tcer_based_on_testplan_and_testcase(ctp_id, eachtc)
        if tcer_id is None:
            print("No TCER Id found for Testcase: {0}".format(eachtc))
            exit(1)
        param_dict ={
'title': mapping_dict[eachtc],
'state' : rqmresult,
'creator' : {'resource': rc.baseurl + "/jts/resource/itemName/com.ibm.team.repository.Contributor/" + rc.username},
'owner' : {'resource':rc.baseurl + "/jts/resource/itemName/com.ibm.team.repository.Contributor/" + rc.username},
'weight' : '100',
'projectArea' : {"href": rc.baseurl + "/qm/resource/itemOid/com.ibm.team.process.ProjectArea/{0}".format(rc.projectarea), "alias":rc.projectarea},
'testcase' : {'href' : rc.baseurl+ rc.resources_url + "/testcase/urn:com.ibm.rqm:testcase:" + eachtc},
'executionworkitem' : { 'href' : rc.baseurl+ rc.resources_url + "/executionworkitem/urn:com.ibm.rqm:executionworkitem:" + tcer_id},
'testplan' : {'href':rc.baseurl+ rc.resources_url + "/testplan/urn:com.ibm.rqm:testplan:" + ctp_id},
'buildrecord' : {'href':rc.baseurl+ rc.resources_url + "/buildrecord/urn:com.ibm.rqm:buildrecord:" + buildrec_id}
                        }
        exres_id = er.generate_new_tc_execution_result(xml_path, param_dict)
        exres_list.append(exres_id)
        response = rc.upload("/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/Gen4+QM/attachment", 
              r"C:\D_Drive\Android\VTS\android-vts\logs\2019.04.02_10.45.52\inv_7672895837615820272\device_logcat_test_6628638995318164874.txt.gz")
        er.update_attachment_to_executionresult(exres_id, 
                            response.headers['Location'], 
                            response.headers['Content-Location'])
    
    print("Create test summary")
    testsummary = tsl.create_testsuite_result(tser_id, buildrec_id)  
    tsl.update_tcresult_to_testsuitelog(exres_list, testsummary)
    
    testsummary_res = max(k for k,v in list(Counter(exeresstate_list).items()) if v>1)
    tsl.set_testsuiteresult(testsummary, testsummary_res)
    rc.close()
    
if __name__ == "__main__":
    main()
#    filepath = "rqm_tcid_funct_mapping.json"
#    mapping_dict = read_json(filepath)