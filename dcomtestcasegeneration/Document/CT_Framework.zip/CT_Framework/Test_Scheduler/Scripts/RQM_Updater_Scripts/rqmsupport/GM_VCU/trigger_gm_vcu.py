#!/usr/bin/python
'''
Created on Feb 27, 2019

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import sys, random, time, os 
sys.path.append(os.path.join("..", "..", "rqmscripts"))
import xml.etree.ElementTree as ET
import connect
import buildrecord
import builddefinition
import testsuiteexecutionrecord
import testsuite
import testplan
import executionworkitem
import executionresult
import executionsequence
import testsuitelog
import testenvironment
def main():
    # Check commandline parameters
#    configfile_path = "gmvcu_config.xml"
    configfile_path = "gmpoc_config.xml"
    if len(sys.argv) > 1:
        sw_version = sys.argv[1]
    else:
        sw_version = input("Please enter the build name [CLEO_18_47.62]: ")
#    config = "GM-VCU"
#    build_def = "8"
    config = "Gen4 POC"
    build_def = "3"
    # Create session
    rc = connect.RQMconnection(config)
    br = buildrecord.RqmBuildRecord(rc)
    bd = builddefinition.RqmBuildDefinition(rc)
    tp = testplan.RqmTestPlan(rc)
    ts = testsuite.RqmTestSuite(rc)
    tser = testsuiteexecutionrecord.RqmTSER(rc)
    tcer = executionworkitem.RqmTCER(rc)
    er = executionresult.RqmER(rc)
    ex_sec = executionsequence.RqmExSchedule(rc)
    tsl = testsuitelog.RqmTestSuiteRes(rc)
    te = testenvironment.RqmTestEnvironment(rc)

    try:
        config_dict = {}
        if os.path.exists(configfile_path):
            tree = ET.parse(configfile_path)
            xml_root = tree.getroot()
            print("Reading Config file: ", configfile_path)
            for child in xml_root:
                if child.attrib == {}:
                    config_dict.update({child.tag : child.text})
                else:
                    config_dict.update({child.tag : child.attrib})                   
        else:
            print("File does not exist: {0}".format(configfile_path))
    except Exception as reason:
        print("Exception in fetching config parameters")
        print(reason)
#    print config_dict
    
#    mtp_id = rc.fetch_web_id_by_title("testplan", config_dict["Parent_TestPlan"])
#    if mtp_id is None:
#        print "Master Test plan: {0} doesn't exist".format(config_dict["Parent_TestPlan"])
#        sys.exit(1)
#        
#    mtp_lock = tp.check_testplan_locked(str(mtp_id))
#    if mtp_lock:
#        print "Master Test plan is locked. Exit"
#        sys.exit(1)
#        
#    ctp_id = rc.fetch_web_id_by_title("testplan", config_dict["Child_TestPlan"])
#    if ctp_id is None:
#        print "Child Test plan: {0} doesn't exist".format(config_dict["Child_TestPlan"])
#        sys.exit(1)
#
#    ctp_lock = tp.check_testplan_locked(str(ctp_id))
#    if ctp_lock:
#        print "Child Test plan is locked. Exit"
#        sys.exit(1)
#
#    ts_id = rc.fetch_web_id_by_title("testsuite", config_dict["HI01"]["testsuite"])
#    if ts_id is None:
#        print "TestSuite : {0} doesn't exist".format(
#                                            config_dict["HI01"]["testsuite"])
#        sys.exit(1)
#   
#    tser_id = rc.fetch_web_id_by_title("suiteexecutionrecord", config_dict["HI01"]["tser"])
#    if tser_id is None:
#        print "TestSuite Execution record : {0} doesn't exist".format(
#                                            config_dict["HI01"]["tser"])
#        sys.exit(1)
#        
#    if config_dict["HI01"]["hardware"] in config_dict["HI01"]["tser"]:
#        print "TSER exists for : {0}".format(config_dict["HI01"]["hardware"])
#    else:
#        print "TSER doesn't exist for : {0}".format(config_dict["HI01"]["hardware"])
#        sys.exit(1)        
##    config_link = tser.fecth_parameters_of_tser(tser_id, "configuration")
##    te_title = te.fecth_parameters_of_testenvironment(config_link, "title")
##    if config_dict["HI01"]["hardware"] in te_title:
##        pass
##    else:
##        print "Test environment doesn't exist for : {0}".format(config_dict["HI01"]["hardware"])
##        sys.exit(1)
##        
##    tslog_id = tser.fetch_current_testsuitelog_of_tser(tser_id)
##    tsl_state = None
##    if tslog_id is None:
##        print "Testsuitelog to be created by test"
##    else:
##        tsl_state = tsl.fetch_parameters_of_testsuitelog(tslog_id, "state")
##    
##    if tsl_state is None:
##        pass
##    elif tsl_state == "com.ibm.rqm.execution.common.state.inprogress":
##        tsl_build = tsl.fetch_parameters_of_testsuitelog(tslog_id, "buildrecord")
##        print "Test suite: {0} is being executed with build:{1}".format(ts_id, 
##                                                                tsl_build)
##        sys.exit(1) 
        
    xml_path = "xml/buildrecord.xml"
    title = sw_version
    param_dict = {
'projectArea' : {"href":"https://rb-alm-20-p.de.bosch.com/qm/resource/itemOid/com.ibm.team.process.ProjectArea/{0}".format(rc.projectarea), 
                   "alias":rc.projectarea},
'title': title,
'state' : 'com.ibm.rqm.buildintegration.buildstate.inprogress',
'status' : "com.ibm.rqm.buildintegration.buildstatus.inprogress"
                  }
        #com.ibm.rqm.buildintegration.buildstatus.ok
        #com.ibm.rqm.buildintegration.buildstate.complete
    br_id = br.create_build_record(xml_path, param_dict, title)
    time.sleep(5)
    bd.add_build_record_to_builddef(build_def, br_id)
    time.sleep(5)
    br.update_state_of_build_record(br_id)
    time.sleep(5)
    br.update_status_of_build_record(br_id)
#    ex_sec.update_scheduleStart_on_exe_schedule("3")
        
    rc.close()
if __name__ == "__main__":
    main()