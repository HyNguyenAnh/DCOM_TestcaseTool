#!/usr/bin/python
'''
Created on Apr 15, 2019

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import sys, random, time, os, glob 
sys.path.append(os.path.join("..", "..", "rqmscripts"))
import xml.etree.ElementTree as ET
import connect
import buildrecord
import builddefinition
import testsuiteexecutionrecord
import testsuite
import testplan
import executionworkitem
import executionresult
import executionsequence
import testsuitelog
import testenvironment
import testcase
import testscript
import testphase
from . import ESD_PP5_xml_parser

def main(config):
    # Check commandline parameters
    configfile_path = "ESD_PP5.xml"
#    if len(sys.argv) > 1:
#        iteration_title = sys.argv[1]
#    else:
#        iteration_title = raw_input("Please enter the iteration name [FV0100_v0.57_pirateNewestNi_sc0sec]: ")
#    iteration_title = "V3M_010_v0.2"
    
#    config = "VID3-PF (qm)"
    # Create session
    rc = connect.RQMconnection(config)
    br = buildrecord.RqmBuildRecord(rc)
    bd = builddefinition.RqmBuildDefinition(rc)
    tp = testplan.RqmTestPlan(rc)
    ts = testsuite.RqmTestSuite(rc)
    tser = testsuiteexecutionrecord.RqmTSER(rc)
    tc = testcase.RqmTC(rc)
    tcer = executionworkitem.RqmTCER(rc)
    er = executionresult.RqmER(rc)
    ex_sec = executionsequence.RqmExSchedule(rc)
    tsl = testsuitelog.RqmTestSuiteRes(rc)
    te = testenvironment.RqmTestEnvironment(rc)
    tscr = testscript.RqmTSc(rc)
    tphase = testphase.RqmTestPhase(rc)
    """
    https://rb-alm-13-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/FV3+%28qm%29/testcase/urn:com.ibm.rqm:testcase:123004
    
    https://rb-alm-13-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/FV3+%28qm%29/executionresult/urn:com.ibm.rqm:executionresult:279995
    """
    my_path = os.path.abspath(os.path.dirname(__file__))
    
    try:
        config_dict = {}
        if os.path.exists(configfile_path):
            tree = ET.parse(configfile_path)
            xml_root = tree.getroot()
            print("Reading Config file: ", configfile_path)
            for child in xml_root:
                if child.attrib == {}:
                    config_dict.update({child.tag : child.text})
                else:
                    config_dict.update({child.tag : child.attrib})                   
        else:
            print("File does not exist: {0}".format(configfile_path))
    except Exception as reason:
        print("Exception in fetching configuration parameters")
        print(reason)
    print(config_dict)
    iteration_title = config_dict["iteration"]
    mtp_id = rc.fetch_web_id_by_title("testplan", config_dict["Parent_TestPlan"])
    if mtp_id is None:
        print("Master Test plan: {0} doesn't exist".format(config_dict["Parent_TestPlan"]))
        sys.exit(1)
    iteration_id = tphase.filter_iteration_based_on_testplan_and_title(mtp_id, 
                                                                iteration_title)
    if iteration_id is None:
        print("Iteration : {0} doesn't exist".format(iteration_title))
        sys.exit(1)
        
    xml_files = glob.glob(config_dict["xml_reports"] + "\\*_report.xml")
    for xmlfile in xml_files:
        rqmid_steps_result = ESD_PP5_xml_parser.fetch_rqm_testcase_id_steps_results(xmlfile)
        for tc_id, rqm_steps_result in rqmid_steps_result.items():
        
    #        tc_id = "11902"
            tscrpt_id = tc.fetch_linked_testscript_from_testcase(tc_id)
            title = tc.fetch_parameters_of_testcase(tc_id, "title")
            param_dict ={
        'title': title,
        'creator' : {'resource': rc.baseurl + "/jts/resource/itemName/com.ibm.team.repository.Contributor/" + rc.username},
        'owner' : {'resource':rc.baseurl + "/jts/resource/itemName/com.ibm.team.repository.Contributor/" + rc.username},
        'weight' : '100',
        'projectArea' : {"href": rc.baseurl + "/qm/resource/itemOid/com.ibm.team.process.ProjectArea/{0}".format(rc.projectarea), "alias":rc.projectarea},
        'testcase' : {'href' : rc.baseurl+ rc.resources_url + "/testcase/urn:com.ibm.rqm:testcase:" + tc_id},
        'testscript' : {'href' : rc.baseurl+ rc.resources_url + "/testscript/urn:com.ibm.rqm:testscript:" + tscrpt_id},
        'testplan' : {'href':rc.baseurl+ rc.resources_url + "/testplan/urn:com.ibm.rqm:testplan:" + mtp_id},
        'testphase' : {'href':rc.baseurl+ rc.resources_url + "/testphase/urn:com.ibm.rqm:testphase:" + iteration_id}
            }
            xml_path = os.path.join(my_path, "..", "..", "rqmscripts", "xml/executionworkitem.xml")                        
            tcer_id = tcer.generate_new_testcase_execution_record(xml_path, param_dict, title)
        #    tcer_id = tcer.filter_tcer_based_on_testplan_iteration_and_testcase(mtp_id, tc_id, iter_id)
            if tcer_id is None:
                print("TCER not found for Testcase: {0}".format(tc_id))
            else:
                req_id = er.create_testcase_result_from_utility(tcer_id)
                time.sleep(10)
                cur_tcr_href = tcer.fetch_parameters_of_executionworkitem(tcer_id, "currentexecutionresult")
                cur_tcr = rc.fetch_webid_from_href(cur_tcr_href["href"], "executionresult")
            fail_found = False
            for step_index, result in rqm_steps_result.items():
                print("Result of Step {0} is -> {1}".format(step_index, result))
                if result == "fail":
                    fail_found = True
            upload_response = rc.upload("/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/{0}/attachment".format(rc.projectarea),
                      xmlfile)
            er.find_description_and_update_stepresults_from_executionresult(cur_tcr, 
                            rqm_steps_result, upload_response.headers['Location'])
            if fail_found:
                er.set_testcaseresult(cur_tcr, 
                                    "com.ibm.rqm.execution.common.state.failed")
            else:
                er.set_testcaseresult(cur_tcr)            
        
    rc.close()
if __name__ == "__main__":
    config = "VID3-PF (qm)"
    print("Updating results for project: {0}".format(config))
    main(config)
    print("Completed : Updating results for project: {0}".format(config))
    
    config = "FVC3-JLR (qm)"
    print("Updating results for project: {0}".format(config))
    main(config)
    print("Completed : Updating results for project: {0}".format(config))