'''
Created on Mar 20, 2019

@author: HEU1KOR
'''
import subprocess
import os, re

def evaluate_result(output):
    result = "com.ibm.rqm.execution.common.state.blocked"
    match = re.search("Invocation finished in \d*m\s*\d*s. PASSED: (\d*), FAILED: (\d*), MODULES: \d* of (\d*)", output, re.MULTILINE)
    if match:
        passed = int(match.group(1))
        failed = int(match.group(2))
        totalmodule = int(match.group(3))
        if totalmodule == 0:
            result = "com.ibm.rqm.execution.common.state.blocked"
        elif failed > 0:
            result = "com.ibm.rqm.execution.common.state.failed"
        elif passed == 0 and failed == 0:
            result = "com.ibm.rqm.execution.common.state.incomplete"    
        else:
            result = "com.ibm.rqm.execution.common.state.passed"
    return result

def VtsFirmwareBootHeaderVerification():
    print("executing VtsFirmwareBootHeaderVerification")
    prev_dir = os.getcwd()
    os.chdir(r"C:\D_Drive\Android\VTS\android-vts\tools")
    command = "vts-tradefed_win.bat run vts -m VtsFirmwareBootHeaderVerification --skip-preconditions --primary-abi-only"
#    sp = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE,
#                    stderr=subprocess.PIPE, universal_newlines=True)
#    out, err = sp.communicate()
    out = subprocess.check_output(command.split())
    print(out)
    os.chdir(prev_dir)
    return evaluate_result(out)

def VtsFirmwareDtboVerification():
    print("executing VtsFirmwareDtboVerification")
    prev_dir = os.getcwd()
    os.chdir(r"C:\D_Drive\Android\VTS\android-vts\tools")
    command = "vts-tradefed_win.bat run vts -m VtsFirmwareDtboVerification --skip-preconditions --primary-abi-only"
#    sp = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE,
#                    stderr=subprocess.PIPE, universal_newlines=True)
#    out, err = sp.communicate()
    out = subprocess.check_output(command.split())
    print(out)
    os.chdir(prev_dir)
    return evaluate_result(out)

#print eval("VtsFirmwareDtboVerification()")


        
