#!/usr/bin/python
'''
Created on Nov 15, 2018

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import json, sys, os
import re
from .import set_xml_params
from urllib.parse import urlparse

class RqmTestEnvironment(object):
	"""
	Test environment: configuration
	"""
	def __init__(self, connection):
		self.connection = connection
		self.rqm_item = 'configuration'
	
	def fecth_parameters_of_testenvironment(self, config_link, parameter):
		"""
		fetches specified parameters from test environment given
		"""
		parsed_uri = urlparse(config_link)
		server_name = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
		href_strip = config_link.replace(server_name, "/")
		result = self.connection.get(href_strip)
		jdata = json.loads(result)
		state = jdata[self.rqm_item][parameter]
		return state