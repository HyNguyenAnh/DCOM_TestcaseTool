#!/usr/bin/python
'''
Created on Nov 15, 2018

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import json, re
from .import set_xml_params

class RqmTSER(object):
	"""
	Test Suite Execution Record
	"""
	def __init__(self, connection):
		self.connection = connection
		self.rqm_item = 'suiteexecutionrecord'

	def get_all(self):
		"""
		list all test suite execution records in a given test suite
		"""
		tser = {}
		result = self.connection.get(self.connection.resources_url + '/' + \
									self.rqm_item)
		jdata = json.loads(result)
		try:
			for eachentry in jdata["feed"]["entry"]:
				match = re.search("suiteexecutionrecord:(\d*)", eachentry["id"])
				tser.update({eachentry["title"]["content"] : match.group(1)})
		except Exception as err:
			print(err)
		finally:
			return tser

	def generate_new_test_suite_execution_record(self, xml_path, param_dict,\
												title):
		"""
		Generate new test suite execution record from test suite
		"""
		tser_id = self.connection.fetch_web_id_by_title(self.rqm_item, title)
		if tser_id is None:
			xml_text = set_xml_params.set_xml_parameters(xml_path, param_dict)
			result = self.connection.post(self.connection.resources_url + '/' +\
						self.rqm_item, xml_text)
			tser_id = self.connection.fetch_webid_from_slug(self.rqm_item,
											result.headers['Content-Location'])
		return tser_id
	
	def fetch_current_testsuitelog_of_tser(self, tser_id):
		"""
		fetches current test suite log for specified TSER. returns id of log
		"""
		cur_tslog = None
		try:
			result = self.connection.get(self.connection.resources_url + '/' + \
					self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item +\
					 ":" + tser_id )
			jdata = json.loads(result)
			cur_tslog = jdata[self.rqm_item]["currenttestsuitelog"]["href"]
			return self.connection.fetch_webid_from_href(cur_tslog, "testsuitelog")
		except Exception as reason:
			print("Parameter -> currenttestsuitelog not available")
			return cur_tslog
	
	def fecth_parameters_of_tser(self, tser_id, parameter):
		"""
		fetches specified parameters from tser given
		"""
		result = self.connection.get(self.connection.resources_url + '/' + \
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item +\
				 ":" + tser_id )
		jdata = json.loads(result)
		state = jdata[self.rqm_item][parameter]
		#print("Current {0} of tser {1}: is {2}".format(parameter, tslog_id, state))
		return state