#!/usr/bin/python
'''
Created on Nov 15, 2018

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import sys
import json
from .import set_xml_params

class RqmBuildRecord(object):
	"""
	Build record
	"""
	def __init__(self, connection):
		self.connection = connection
		self.rqm_item = 'buildrecord'

	def create_build_record(self, xml_path, param_dict, title):
		"""
		creates build record on RQM by referring to buildrecord.xml file
		"""
		buildrec_id = self.connection.fetch_web_id_by_title(self.rqm_item,\
															title)
		if buildrec_id is None:
			xml_text = set_xml_params.set_xml_parameters(xml_path, param_dict)
			result = self.connection.post(self.connection.resources_url + '/' +\
										self.rqm_item, xml_text)
	#		print "Slug id: ",result.headers['Content-Location']
			buildrec_id = self.connection.fetch_webid_from_slug(\
							self.rqm_item, result.headers['Content-Location'])
		return buildrec_id
	
	def update_status_of_build_record(self, br_id, 
					status = "com.ibm.rqm.buildintegration.buildstatus.ok"):
		print("Update status of buldrec: {0} to : {1}".format(br_id, status))
		result = self.connection.get(self.connection.resources_url + '/' +\
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" +\
				str(br_id), "xml")
		update_elements = {'status' : status}
		xml_content = set_xml_params.update_xml_parameters(result, \
														update_elements)
		result = self.connection.put(self.connection.resources_url +\
		'/' + self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" + br_id,
		  xml_content)
	
	def update_state_of_build_record(self, br_id, 
					state = "com.ibm.rqm.buildintegration.buildstate.complete"):
		print("Update state of buldrec: {0} to : {1}".format(br_id, state))
		result = self.connection.get(self.connection.resources_url + '/' +\
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" +\
				str(br_id), "xml")
		update_elements = {'state' : state}
		xml_content = set_xml_params.update_xml_parameters(result, \
														update_elements)
		result = self.connection.put(self.connection.resources_url +\
		'/' + self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" + br_id,
		  xml_content)