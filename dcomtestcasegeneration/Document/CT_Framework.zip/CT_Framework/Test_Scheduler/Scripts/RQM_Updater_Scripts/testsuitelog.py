#!/usr/bin/python
'''
Created on Feb 28, 2019

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import json, sys, os, time
import re
from .import set_xml_params
import subprocess

class RqmTestSuiteRes(object):
	"""
	Test suite result
	"""
	def __init__(self, connection):
		self.connection = connection
		self.rqm_item = 'testsuitelog'

	def create_testsuite_result(self, tser_id, buildrec_id):
		"""
		creates test suite result on RQM by using 
		RQM-Extras-ExecutionTool-6.0.5
		state will be set to "In progress" by default
		""" 
		testsuiteres_id = None
		command = """java -jar {0} -tserId={1} -projectName="{2}" -publicURI={3}/qm -user={4} -password={5} -suiteBuildRecord={6}""".format(
			self.connection.rqmexeutility, tser_id, 
			str(self.connection.projectName), self.connection.baseurl, 
			self.connection.username, self.connection.passw, buildrec_id)

		sp = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE,
						stderr=subprocess.PIPE, universal_newlines=True)
		out, err = sp.communicate()
		try:
			if out is not None:
				match = re.search("<testsuiteResultId>(\d*)</testsuiteResultId>", 
								str(out), re.MULTILINE)
				if match:
					testsuiteres_id = match.group(1)
		except Exception as reason:
			print("Exception in create_testsuite_result: {0}".format(reason))
		print("Created Test Suite result is : {0}".format(testsuiteres_id))		
		return testsuiteres_id
	
	def update_tcresult_to_testsuitelog(self, tcr_list, tsr_id):
		"""
		updates testcase results to test suite result 
		"""
		for each_tcr in tcr_list:
			result = self.connection.get(self.connection.resources_url + '/' +\
					self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" +\
					tsr_id , "xml")
			insert_elements = {'executionresult' : \
["ns2", {"href" : 'https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/{0}/executionresult/urn:com.ibm.rqm:executionresult:'.format(self.connection.projectarea) +\
each_tcr}]}
			xml_content = set_xml_params.insert_xml_parameter(result, 
															insert_elements)
			result = self.connection.put(self.connection.resources_url +\
		'/' + self.rqm_item + "/urn:com.ibm.rqm:"+ self.rqm_item +":" + tsr_id ,
			xml_content)
#		result = self.connection.get(self.connection.resources_url + '/' +\
#					self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" +\
#					tsr_id , "xml")
#		insert_elements = {'endtime' : ["ns18", str(time.strftime("%Y-%m-%dT%H:%M:%S.000Z", gmtime()))]}
#		xml_content = set_xml_params.insert_xml_parameter(result, 
#															insert_elements)
#		result = self.connection.get(self.connection.resources_url + '/' +\
#					self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" +\
#					tsr_id , "xml")
		
	def set_testsuiteresult(self, tsr_id, 
						state = "com.ibm.rqm.execution.common.state.passed"):
		"""
		sets state of test suite result. 		
		Supported values:
		com.ibm.rqm.execution.common.state.passed
		com.ibm.rqm.execution.common.state.failed
		com.ibm.rqm.execution.common.state.blocked
		com.ibm.rqm.execution.common.state.part_blocked
		com.ibm.rqm.execution.common.state.incomplete
		com.ibm.rqm.execution.common.state.perm_failed
		com.ibm.rqm.execution.common.state.deferred
		com.ibm.rqm.execution.common.state.inconclusive
		com.ibm.rqm.execution.common.state.error
		"""
		print("Setting result of TSR: {0} to -> {1}".format(tsr_id, state))
		result = self.connection.get(self.connection.resources_url + '/' +\
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" +\
				tsr_id , "xml")
		update_elements = {'state' :  state}
		xml_content = set_xml_params.update_xml_parameters(result, 
															update_elements)
		result = self.connection.put(self.connection.resources_url +\
		'/' + self.rqm_item + "/urn:com.ibm.rqm:"+ self.rqm_item +":" + tsr_id ,
			xml_content)
		
	def fetch_parameters_of_testsuitelog(self, tslog_id, parameter):
		"""
		fetches specified parameters from test suite log given
		"""
		result = self.connection.get(self.connection.resources_url + '/' + \
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item +\
				 ":" + tslog_id )
		jdata = json.loads(result)
		state = jdata[self.rqm_item][parameter]
		print("Current {0} of testsuitelog: {1} is {2}".format(parameter, 
															tslog_id, state))
		return state