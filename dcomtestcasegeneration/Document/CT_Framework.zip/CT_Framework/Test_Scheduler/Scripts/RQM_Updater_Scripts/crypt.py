'''
Created on Nov 28, 2018

@author: HEU1KOR
'''
import base64
def encode(key, clear):
    enc = []
    for i in range(len(clear)):
        key_c = key[i % len(key)]
        enc_c = chr((ord(clear[i]) + ord(key_c)) % 256)
        enc.append(enc_c)
    return base64.urlsafe_b64encode("".join(enc))

def decode(key, enc):
    dec = []    
    enc = base64.urlsafe_b64decode(enc)    
    for i in range(len(enc)):
        
        key_c = key[i % len(key)]        
        dec_c = chr((256 + enc[i] - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)
if __name__ == "__main__":
    encodedmsg = encode('BOSCH', 'Ranjini1234#')
    print(encodedmsg)
    print(decode('BOSCH', encodedmsg))