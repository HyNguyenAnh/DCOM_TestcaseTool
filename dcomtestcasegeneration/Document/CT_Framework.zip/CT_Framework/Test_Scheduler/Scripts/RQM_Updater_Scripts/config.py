#!/usr/bin/python
'''
Created on Nov 15, 2018

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import os
import configparser
from .import  crypt

class RQMAccount(object):
	def __init__(self, domain):
		config = configparser.SafeConfigParser(allow_no_value=True)
		if os.name is "nt":
			configfile = os.path.expanduser("~")+"\\rqm_account.cfg"
		elif os.name is "posix":
			configfile = os.path.expanduser("~")+"/rqm_account.cfg"
#		my_path = os.path.abspath(os.path.dirname(__file__))
#		config.readfp(open(os.path.join(my_path,'config_file/rqm_account.cfg')))
		config.readfp(open(configfile))
		self.baseurl=config.get(domain, 'baseurl')
		self.projectarea=config.get(domain,'ProjectArea')
		self.rqmexeutility=config.get(domain,'rqmexeutility')
		self.create_rtc_defect_report_on_failure=config.get(domain,
'create_rtc_defect_report_on_failure')
		self.credentials = {
			'j_username': config.get(domain, 'username'),
			'j_password': crypt.decode("BOSCH",(config.get(domain, 'password'))),
		}



