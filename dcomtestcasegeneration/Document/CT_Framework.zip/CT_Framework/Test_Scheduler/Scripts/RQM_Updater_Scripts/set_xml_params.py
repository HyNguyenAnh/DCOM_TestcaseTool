'''
Created on Nov 16, 2018

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import os
from lxml import etree

def set_xml_parameters(xml_path, param_dict):
    """
    update xml before RQM record creation
    """
    try:
        if os.path.exists(xml_path):
#            tree = ET.parse(xml_path)
            tree = etree.parse(xml_path)
            xml_root = tree.getroot()
            print("Updating Config file: ", xml_path)
            for key, value in param_dict.items():
                for child in xml_root:
                    if key in child.tag:
                        for grandchild in child:
                            for grkey, grvalue in value.items():
                                if grkey in grandchild.tag:
                                    if grandchild.attrib == {}:
                                        grandchild.text = value
                                    else:
                                        for subkey in list(grandchild.attrib.keys()):
                                            for updatekey, updatevalue in grvalue.items():
                                                if updatekey in subkey:
                                                    grandchild.attrib[subkey] = updatevalue
                                                elif updatekey == "text" and grandchild.text is not None:
                                                    grandchild.text = updatevalue
                            break
                        else:
                            if child.attrib == {}:
                                child.text = value
                            else:
                                for subkey in list(child.attrib.keys()):
                                    for updatekey, updatevalue in value.items():
                                        if updatekey in subkey:
                                            child.attrib[subkey] = updatevalue
                                        elif updatekey == "text" and child.text is not None:
                                            child.text = updatevalue
                        break
#            tree.write(xml_path, encoding = "UTF-8",xml_declaration = True)
        else:
            print("File does not exist: {0}".format(xml_path))
    except Exception as reason:
        print("Exception in setting config parameters")
        print(reason)
    finally:
        return etree.tostring(xml_root, encoding = "UTF-8", xml_declaration = True)

def remove_xml_parameters(xml_text, remove_lis):
    xml_text = bytes(bytearray(xml_text, encoding='utf-8'))
    xml_root = etree.XML(xml_text)
    print(xml_text)
    children = xml_root.getchildren()
    for elem in remove_lis:
        for child in children:
            if elem in child.tag:
                xml_root.remove(child)
                break
    print(etree.tostring(xml_root, encoding = "UTF-8", xml_declaration = True))

def insert_xml_parameter(xml_text, insert_elements):
#            tree = ET.parse(xml_path)
    pos_count = 0
    xml_text = bytes(bytearray(xml_text, encoding='utf-8'))
    xml_root = etree.XML(xml_text)
#    xml_root = tree.getroot()
    for key, value in insert_elements.items():
        nsmap_suf = value[0]
        child_elem = etree.Element("{"+xml_root.nsmap[nsmap_suf]+"}"+\
		key, insert_elements[key][1])
        xml_root.insert(pos_count, child_elem)
        pos_count += 1
    return etree.tostring(xml_root, encoding = "UTF-8", xml_declaration = True)

def update_xml_parameters(xml_text, param_dict):
    """
    update xml before RQM record creation
    """
    try:
        xml_text = bytes(bytearray(xml_text, encoding='utf-8'))
        xml_root = etree.XML(xml_text)
        for key, value in param_dict.items():
            for child in xml_root:
                if key in child.tag:
                    for grandchild in child:
                        for grkey, grvalue in value.items():
                            if grkey in grandchild.tag:
                                if grandchild.attrib == {}:
                                    grandchild.text = value
                                else:
                                    for subkey in list(grandchild.attrib.keys()):
                                        for updatekey, updatevalue in grvalue.items():
                                            if updatekey in subkey:
                                                grandchild.attrib[subkey] = updatevalue
                                            elif updatekey == "text" and grandchild.text is not None:
                                                grandchild.text = updatevalue
                        break
                    else:
                        if child.attrib == {}:
                            child.text = value
                        else:
                            for subkey in list(child.attrib.keys()):
                                for updatekey, updatevalue in value.items():
                                    if updatekey in subkey:
                                        child.attrib[subkey] = updatevalue
                                    elif updatekey == "text" and child.text is not None:
                                        child.text = updatevalue
                    break
#            tree.write(xml_path, encoding = "UTF-8",xml_declaration = True)
    except Exception as reason:
        print("Exception in setting config parameters")
        print(reason)
    finally:
        return etree.tostring(xml_root, encoding = "UTF-8", xml_declaration = True)
#    tree.write(xml_path, encoding = "UTF-8",xml_declaration = True)

def update_stepresults(xml_text, stepresults_dict, baseurl, username, upload_link):
    """
    update Test Case step results on xml before RQM record creation
    """
    supported = {
        "pass" : "com.ibm.rqm.execution.common.state.passed",
        "fail" : "com.ibm.rqm.execution.common.state.failed",
        "block" : "com.ibm.rqm.execution.common.state.blocked",
        "part_block" : "com.ibm.rqm.execution.common.state.part_blocked",
        "incomplete" : "com.ibm.rqm.execution.common.state.incomplete",
        "perm_fail" : "com.ibm.rqm.execution.common.state.perm_failed",
        "defer" : "com.ibm.rqm.execution.common.state.deferred",
        "inconclusive" : "com.ibm.rqm.execution.common.state.inconclusive",
        "error" : "com.ibm.rqm.execution.common.state.error"
    }
#    tree = etree.parse("sample.xml")
#    xml_root = tree.getroot()
    rqmstep_index = -1
    try:
        xml_text = bytes(bytearray(xml_text, encoding='utf-8'))
        xml_root = etree.XML(xml_text)
        for child in xml_root.iter("{http://jazz.net/xmlns/alm/qm/v0.1/executionresult/v0.1}stepResult"):
            index_match = False
            rqmstep_index = child.attrib["stepIndex"]
            
            all_nodes = child.getchildren()
#            for reportstep_index, step_res in stepresults_dict.iteritems(): 
#                for nodes in all_nodes:
#                    if nodes.tag.endswith("description"):
#                        for div in nodes:
#                            for subdiv in div:
#                                children = subdiv.getchildren()
#                                if len(children) == 0:
#                                    print "no description!!!"
#                                    rqmstep_dscrpt = "no description"
#                                elif len(children) == 1:
#                                    print children[0].text
#                                    rqmstep_dscrpt = children[0].text
#                                else:
#                                    final_child = children[0]
#                                    all_tag = final_child.getchildren()
#                                    print all_tag
            for reportstep_index, step_res in stepresults_dict.items():                    
                if reportstep_index == rqmstep_index:#compare descriptions
                    index_match = True
                if index_match:
                    nsmap_suf = "ns16"
                    if (upload_link is not None) and (rqmstep_index == "1"):
                        stepAttachment = etree.Element("{"+child.nsmap[nsmap_suf]+"}" +\
                                               "stepAttachment")
                        stepAttachment.attrib["href"] = upload_link
                        child.insert(0, stepAttachment)
                    #updating tester info and step result
                    child_elem = etree.Element("{"+child.nsmap[nsmap_suf]+"}" +\
                                               "testedby")
                    subchild = etree.SubElement(child_elem,
                                "{"+child.nsmap[nsmap_suf]+"}" + "tester", 
{"{"+child.nsmap["ns7"]+"}"+"resource" : baseurl + \
"/jts/resource/itemName/com.ibm.team.repository.Contributor/" + username})
                    subchild.text = username                    
                    child.insert(0, child_elem)
                    child.attrib["result"] = supported[step_res]
                    for nodes in all_nodes:
                        if nodes.tag.endswith("result"):
                            nodes.text = supported[step_res]
                            break
                    break
    except Exception as reason:
        print("Exception in update_stepresults")
        print(reason)
    finally:
#        print etree.tostring(xml_root, encoding = "UTF-8", xml_declaration = True)
        return etree.tostring(xml_root, encoding = "UTF-8", xml_declaration = True)
#    tree.write(xml_path, encoding = "UTF-8",xml_declaration = True)


if __name__ == "__main__":
    update_stepresults("", {"Open UDP Port" : "pass"}, "https://rb-alm-13-p.de.bosch.com", "EMD1KOR")