#!/usr/bin/python
'''
Created on Nov 15, 2018

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import json

class RqmTC(object):
	"""
	Test Case
	"""
	def __init__(self, connection):
		self.connection = connection
		self.rqm_item = 'testcase'

	def fetch_precondition_action_exp_result_from_testcase(self, tc_id):
		"""
		fetch precondition, action, expected result frm testcase
		"""
		summary = {"precondition" : "",
					"action" : "",
					"exp_result" : ""}
		result = self.connection.get(self.connection.resources_url + '/' + \
				self.rqm_item + "/urn:com.ibm.rqm:testcase:" + tc_id)
		jdata = json.loads(result)
		try:
			summary["precondition"] = jdata[self.rqm_item]['com.ibm.rqm.planning.editor.section.testCasePreCondition']["div"]
			summary["action"] = jdata[self.rqm_item]['description']
			summary["exp_result"] = jdata[self.rqm_item]['com.ibm.rqm.planning.editor.section.testCaseExpectedResults']["div"]
		except Exception as err:
			print(err)
		finally:
			print("summary of TC: {0}".format(summary))
			return summary
	
	def fetch_linked_testscript_from_testcase(self, tc_id):
		"""
		fetches test script which is linked to testcase
		"""
		tscript_id = None
		result = self.connection.get(self.connection.resources_url + '/' + \
		self.rqm_item + "/urn:com.ibm.rqm:testcase:" + tc_id)			
		jdata = json.loads(result)
		try:
						
			tscript_href = jdata[self.rqm_item]['testscript']['href']
			print("here"+tscript_href)
			tscript_id = self.connection.fetch_webid_from_href(tscript_href, 
															"testscript")
		except Exception as err:
			print(err)
		finally:
			print("Testcase: {0} has link to testscript: {1}".format(tc_id, 
																	tscript_id))
			return tscript_id
		
	def fetch_parameters_of_testcase(self, tc_id, parameter):
		"""
		fetches specified parameters from test case given
		"""
		result = self.connection.get(self.connection.resources_url + '/' + \
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item +\
				 ":" + tc_id )		
		#print result
		jdata = json.loads(result)
		state = jdata[self.rqm_item][parameter]
		print("Current {0} of testcase: {1} is {2}".format(parameter, 
															tc_id, state))
		return state
		