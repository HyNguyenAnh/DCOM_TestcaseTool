#!/usr/bin/python
'''
Created on April 17, 2019

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import sys, re
import json
from .import set_xml_params
from .import connect

class RqmTestPhase(object):
	"""
	Iteration
	"""
	def __init__(self, connection):
		self.connection = connection
		self.rqm_item = 'testphase'

	def create_testphase(self, xml_path, param_dict, tp_id, title):
		"""
		creates build record on RQM by referring to buildrecord.xml file
		"""
		tphase_id = self.connection.fetch_web_id_by_title(self.rqm_item,\
															title)
		if tphase_id is None:
			xml_text = set_xml_params.set_xml_parameters(xml_path, param_dict)
			result = self.connection.post(self.connection.resources_url + '/' +\
										self.rqm_item, xml_text)
	#		print "Slug id: ",result.headers['Content-Location']
			tphase_id = self.connection.fetch_webid_from_slug(\
							self.rqm_item, result.headers['Content-Location'])
		return tphase_id

	def filter_iteration_based_on_testplan_and_title(self, tp_id, title):
		"""
		filter and returns test phase(iteration) ID based on given 
		testplan and title
		"""
		iteration_id = None
		found = False
		command = self.connection.resources_url + '/' + self.rqm_item +\
		 "?fields=feed/entry/content/" + self.rqm_item +\
		 "[title='{0}']/".format(title) + "testplan"
		print(command) 
		result = self.connection.get(command)
		jdata = json.loads(result)
		print(jdata)
		try:
			identifier_lis = jdata["feed"]['entry']
			print("Identifier list:::::::::")
			print(identifier_lis)
			for identifier in identifier_lis:
				if tp_id in identifier["content"]["testphase"]["testplan"]["href"]:
					found = True
					iter_link = identifier["id"]
					print(identifier["id"])
					break
			if found:
				match = re.search("urn:com.ibm.rqm:{0}:(\d*)".format(
													self.rqm_item), iter_link)
				if match:
					iteration_id = match.group(1)
					print("Iteration ID of title: {0} is : {1}".format(title, 
																iteration_id))
			else:
				print("Iteration ID not found")				
		except Exception as err:
			print(err)
		finally:
			return iteration_id
		
	def filter_iteration_based_on_testplan_and_Test_Environment(self, tp_id, Environment_title):
		"""
		filter and returns test Environment ID based on given 
		title (it looks like TE818 for "Development PC" in Athena Project)
		"""
		Environment_id = None
		self.rqm_item="configuration"
		found = False
		command = self.connection.resources_url + '/' + self.rqm_item +\
		 "?fields=feed/entry/content/" + self.rqm_item +\
		 "[title='{0}']/".format(Environment_title)
		result = self.connection.get(command)
		jdata = json.loads(result)
		print(jdata)
		try:
			identifier_lis = jdata["feed"]['entry']
			print(identifier_lis)
			for identifier in identifier_lis:
				if Environment_title in identifier["title"]["content"]:
					found = True
					iter_link = identifier["id"]
					print(identifier["id"])
					break
			if found:
				match = re.search(".*{0}/(.*)".format(
													self.rqm_item), iter_link)
				if match:
					Environment_id = match.group(1)
					print("Test_Environment ID of title: {0} is : {1}".format(Environment_title, 
																Environment_id))
			else:
				print("Iteration ID not found")				
		except Exception as err:
			print(err)
		finally:
			return Environment_id		
#		
if __name__ == "__main__":
	config = "ATV_PJ-AS (qm)"
	rc = connect.RQMconnection(config)
	tphase = RqmTestPhase(rc)
	#tphase.filter_iteration_based_on_testplan_and_title("5301", "ATV_1.0 (bugfix)")
	tphase.filter_iteration_based_on_testplan_and_Test_Environment("5301", "Development PC")