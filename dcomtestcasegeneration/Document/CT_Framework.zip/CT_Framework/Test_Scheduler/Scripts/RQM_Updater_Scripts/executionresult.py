#!/usr/bin/python
'''
Created on Nov 15, 2018

@author: Udaya Hegde (RBEI/ECQ3) <Udaya.Hegde@in.bosch.com> HEU1KOR
'''
import sys, json, re
from .import set_xml_params
from .import testcase
from .import executionworkitem
from lxml import etree
import subprocess

class RqmER(object):
	"""
	Test Case Result
	"""
	def __init__(self, connection):
		self.connection = connection
		self.rqm_item = 'executionresult'
		self.tc_obj = testcase.RqmTC(self.connection)
		self.tcer_obj = executionworkitem.RqmTCER(self.connection)

	def generate_new_tc_execution_result(self, xml_path, param_dict):
		"""
		supported values for result:
		com.ibm.rqm.execution.common.state.passed
		com.ibm.rqm.execution.common.state.failed
		com.ibm.rqm.execution.common.state.blocked
		com.ibm.rqm.execution.common.state.part_blocked
		com.ibm.rqm.execution.common.state.incomplete
		com.ibm.rqm.execution.common.state.perm_failed
		com.ibm.rqm.execution.common.state.deferred
		com.ibm.rqm.execution.common.state.inconclusive
		com.ibm.rqm.execution.common.state.error
		"""
		xml_text = set_xml_params.set_xml_parameters(xml_path, param_dict)
		result = self.connection.post(self.connection.resources_url + '/' + self.rqm_item, \
									xml_text)
#		print "Slug id: ",result.headers['Content-Location']
		exeres_id = self.connection.fetch_webid_from_slug(self.rqm_item,
											result.headers['Content-Location'])

		if (param_dict['state'] == "com.ibm.rqm.execution.common.state.failed" and
			self.connection.create_rtc_defect_report_on_failure == "True"):
			print("create defect report: {0}".format(
				self.connection.create_rtc_defect_report_on_failure))
			print("Create a defect report on RTC")
			tc_id = self.tcer_obj.fetch_tc_webid_from_href(param_dict['testcase']['href'])
			tc_summary = self.tc_obj.fetch_precondition_action_exp_result_from_testcase(tc_id)

			from rtcscripts import connect
			from rtcscripts import workItem
			config = "Gen4 POC"
			rc = connect.RTCconnection(config)
			rtc_wi = workItem.RTCworkitem(rc)
			workitem_dict = {"defectOccurence" : {"resource" : "https://rb-alm-20-p.de.bosch.com/ccm/oslc/enumerations/_AiQkUIsBEea2heoQFmx3ng/enumDefectOccurance/enumDefectOccurance.literal.l2"},
			"defectSeverity1" : {"resource" : "https://rb-alm-20-p.de.bosch.com/ccm/oslc/enumerations/_AiQkUIsBEea2heoQFmx3ng/defectSeverity4/defectSeverity4.literal.l4"},
#			"foundIn" : {"resource" : "https://rb-alm-20-p.de.bosch.com/ccm/resource/itemOid/com.ibm.team.workitem.Deliverable/_hzUv4NuVEei-yeEPRJuzGw"},
			"teamArea" : {"resource" : "https://rb-alm-20-p.de.bosch.com/ccm/oslc/teamareas/_iS8YqP9uEeeCKdROkCvLhQ"},
			"creator" : {"resource" : "https://rb-alm-20-p.de.bosch.com/jts/users/" + rc.username},
			"ownedBy" : {"resource" : "https://rb-alm-20-p.de.bosch.com/jts/users/" + rc.username},
			"priority" : {"resource" : "https://rb-alm-20-p.de.bosch.com/ccm/oslc/enumerations/_AiQkUIsBEea2heoQFmx3ng/priority/priority.literal.l11"},
			"title" : "Failing: " + param_dict['title'],
			"subject" : "dummy",
			"bugDescription" : "==Precondition== " + tc_summary["precondition"] +\
			 	"\n" +  "==Operation==" + tc_summary["action"] + "\n" + \
			  	"==Expectation==" +  tc_summary["exp_result"] ,
			}
			linkto_wi = rtc_wi.create_new_workitem_xml(workitem_dict)
			self.link_RTCdefects(exeres_id, [linkto_wi])
		return exeres_id

	def fetch_linked_RTCdefects(self, exe_resid):
		"""
		fetches href for linked defects
		"""
		linked_defects = []
		result = self.connection.get(self.connection.resources_url + '/' + \
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item +\
				 ":" + exe_resid + "?calmlinks=true" )
		jdata = json.loads(result)
		try:
			for eachentry in jdata[self.rqm_item]["defect"]:
				linked_defects.append(eachentry["href"])
		except Exception as err:
			print(err)
		finally:
			print("Linked Defects are: {0}".format(linked_defects))
			return linked_defects

	def link_RTCdefects(self, exe_resid, defects_to_link):
		"""
		<ns2:defect href="https://rb-alm-20-p.de.bosch.com/ccm/resource/
		itemName/com.ibm.team.workitem.WorkItem/386354" rel="affectedBy"
		summary="386354: Not able to play any type (format)
		of audios or videos from the USB" />
		"""
		xml_content = self.connection.get(self.connection.resources_url + \
			'/' + self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" + \
			exe_resid + "?abbreviate=false&calmlinks=true", "xml")
#		remove_lis = ["webId", "creationDate", "updated"]
#		set_xml_params.remove_xml_parameters(result, remove_lis)
		print("Link defects to Execution result: {0}".format(exe_resid))
		for defect_id in defects_to_link:
			insert_elements = {'defect' : ["ns2",\
			{"href" : defect_id, #'https://rb-alm-20-p.de.bosch.com/ccm/resource/itemName/com.ibm.team.workitem.WorkItem/' + defect_id,
			"rel":"affectedBy" }]}
			xml_content = set_xml_params.insert_xml_parameter(xml_content,
															insert_elements)

			self.connection.put(self.connection.resources_url +\
			'/' + self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" + \
										exe_resid,  xml_content)
	
	def update_attachment_to_executionresult(self, exeres_id, attachment_link, 
											filename):
		"""
		updates attachment link to execution result 
		"""
		print("Linking attachment result to: {0}".format(exeres_id))
		result = self.connection.get(self.connection.resources_url + '/' +\
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" +\
				exeres_id , "xml")
		
#		"https://rb-alm-20-p.de.bosch.com/qm/service/com.ibm.rqm.planning.service.internal.rest.IAttachmentRestService/_dr0JcVReEemQnJJE5bMAew"
		insert_text = r"""<details xmlns="http://jazz.net/xmlns/alm/qm/v0.1/executionresult/v0.1"><div xmlns="http://www.w3.org/1999/xhtml"><a href="{0}" target="_blank">{1}</a></div></details>""".format(attachment_link, filename)
		result = result[ :result.rfind("</ns2:" + self.rqm_item)] + insert_text + "</ns2:" + self.rqm_item + ">"
		
		xml_text = bytes(bytearray(result, encoding='utf-8'))
		xml_root = etree.XML(xml_text)
		final = etree.tostring(xml_root, encoding = "UTF-8", xml_declaration = True)

		result = self.connection.put(self.connection.resources_url +\
		'/' + self.rqm_item + "/urn:com.ibm.rqm:"+ self.rqm_item +":" + exeres_id ,
			final)
	
	def create_testcase_result_from_utility(self, tcer_id):
		"""
		creates test case result on RQM by using 
		RQM-Extras-ExecutionTool-6.0.5
		state will be set to "In progress" by default
		""" 
		request_id = None
		command = """java -jar {0} -tcerId={1} -projectName="{2}" -publicURI={3}/qm -user={4} -password={5}""".format(
			self.connection.rqmexeutility, tcer_id, 
			str(self.connection.projectName), self.connection.baseurl, 
			self.connection.username, self.connection.passw)

		sp = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE,
						stderr=subprocess.PIPE, universal_newlines=True)
		out, err = sp.communicate()
		try:
			if out is not None:
				match = re.search("<requestId>(\d*)</requestId>", 
								str(out), re.MULTILINE)
				if match:
					request_id = match.group(1)
		except Exception as reason:
			print("Exception in create_test_case_result_from_utility: {0}".format(reason))
		print("Created Test request is : {0}".format(request_id))		
		return request_id
	
	def find_description_and_update_stepresults_from_executionresult(self, 
									exeres_id, result_dict, upload_link=None):
		"""
		fetch all steps from execution result and update pass/fail status
		"""
		result = self.connection.get(self.connection.resources_url + '/' + \
		 self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" + exeres_id, "xml")
		input_xml_text = result
		xml_text = set_xml_params.update_stepresults(input_xml_text, 
			result_dict ,  self.connection.baseurl, 
			self.connection.username, upload_link)
		final_res = self.connection.put(self.connection.resources_url + '/' +\
		 self.rqm_item + "/urn:com.ibm.rqm:"+ self.rqm_item +":" + exeres_id, 
									xml_text)			
		print("Inside executionresult::::")
		print(final_res)
	
	def set_testcaseresult(self, tcr_id, 
						state,Test_Result):
		"""
		sets state of test suite result. 		
		Supported values:
		com.ibm.rqm.execution.common.state.passed
		com.ibm.rqm.execution.common.state.failed
		com.ibm.rqm.execution.common.state.blocked
		com.ibm.rqm.execution.common.state.part_blocked
		com.ibm.rqm.execution.common.state.incomplete
		com.ibm.rqm.execution.common.state.perm_failed
		com.ibm.rqm.execution.common.state.deferred
		com.ibm.rqm.execution.common.state.inconclusive
		com.ibm.rqm.execution.common.state.error
		"""
		print("Setting result of TCR: {0} to -> {1}".format(tcr_id, state))
		#print("Command to get the iteration details are")
		#result=""
		result = self.connection.get(self.connection.resources_url + '/' +\
				self.rqm_item + "/urn:com.ibm.rqm:" + self.rqm_item + ":" +\
				tcr_id , "xml")
		#print result
		update_elements = {'state' : state}
		#print "Test execution result"
		
		
		xml_content = set_xml_params.update_xml_parameters(result, 
															update_elements)
		#print ("Command for pushing")
		#print self.connection.resources_url +\
		
		#print "XML Content before adding actual Result"
		#print xml_content
		#xml_content=re.sub('<ns16:comment/>',  '<ns16:comment>hello</ns16:comment>', xml_content)
		#xml_content=re.sub('<ns16:compare/>',  '<ns16:compare>hello</ns16:compare>', xml_content)
		#print "Received string for temp result is {0}".format(Test_Result)
		
		#Here attaching the string for actual result to print in the result 
		#temp_string=('</ns16:expectedResult><ns16:actualResult><div xmlns="http://www.w3.org/1999/xhtml">'+Test_Result+'</div></ns16:actualResult><ns16:description>')
		#print("Temp_String")
		#xml_content=re.sub('</ns16:expectedResult><ns16:description>',  temp_string, xml_content,1)
		
		#print "Command for pushing"
		#print xml_content
		result = self.connection.put(self.connection.resources_url +\
		'/' + self.rqm_item + "/urn:com.ibm.rqm:"+ self.rqm_item +":" + tcr_id ,
			xml_content)
		
		
if __name__ == "__main__":
	from . import connect
	config = "VID3-PF (qm)"
	rc = connect.RQMconnection(config)
	er = RqmER(rc)
	import glob
	from . import ESD_PP5_xml_parser
	file_path = r"C:\D_Drive\Support\ESD_PP5\latest"
	xml_files = glob.glob(file_path + "\\*_report.xml")
	for xmlfile in xml_files:
		tc_id, res_dcit = ESD_PP5_xml_parser.fetch_rqm_testcase_id_steps_results(xmlfile)
		er.find_description_and_update_stepresults_from_executionresult("280836", res_dcit)