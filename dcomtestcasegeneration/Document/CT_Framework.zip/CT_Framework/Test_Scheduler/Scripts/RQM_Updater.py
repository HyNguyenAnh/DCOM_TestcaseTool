
#=============================================================================
#  C O P Y R I G H T
#-----------------------------------------------------------------------------
#  Copyright (c) 2019 by Robert Bosch Engineering and Buisiness Limited. All rights reserved.
#
#  This file is property of Robert Bosch Engineering and Buisiness India Limited. Any unauthorised copy, use or 
#  distribution is an offensive act against international law and may be 
#  prosecuted under federal law. Its content is company confidential.
#=============================================================================
#  D E S C R I P T I O N
#-----------------------------------------------------------------------------
#       Projectname: 
#          Synopsis: Regression Test - Python Application Wraper for ATV 
#  Target system(s): win32
#       Compiler(s): python 2.7.16
#===============================================================================================
#  N O T E S
#-----------------------------------------------------------------------------------------------
#  Notes: 
#================================================================================================
#  I N I T I A L   A U T H O R   I D E N T I T Y
#------------------------------------------------------------------------------------------------
#  Name:Sudarshan (RBEI/ESD-PP52), Sunny Kumar (RBEI/ESD-PP52) and Govindaraju T (RBEI/ESD-PP)
#  Department: RBEI/ESD - PP
#================================================================================================
#  R E V I S I O N   I N F O R M A T I O N
#------------------------------------------------------------------------------------------------
## 
## - Reviewed version: 
## - Type (use 'X' to mark):
##     - [ ] Formal Review
##     - [ ] Walkthrough
##     - [ ] Inspection
## - State including date (DD.MM.YYYY)
##     - [--.--.----] Preparation
##     - [--.--.----] Review audit
##     - [--.--.----] Integration of findings
##     - [--.--.----] Test
##     - [--.--.----] Verification of integration of findings
##     - [--.--.----] Review release
## - Responsible:
## - Review-Document:
#=============================================================================
# -----------------------------------------------------------------------------
# Run from Windows command line :  >> python RQM_Updater.py 
#
# ----------------------------------------------------------------------------- 
import sys, time, os 
import subprocess
import Log
import shutil
import re
import pyrocopy as robocopy
import Parameter_List as param
import psutil
from RQM_Updater_Scripts.rqm_update import *
import pickle

#*************************************************************
#        OBJECT_INTIALIZATION
#
#*************************************************************
MyLog = Log.LOG(param.logpath+"\\"+'CT_Python_Wraper_RQM_Updater.txt')


#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_1: RQM_Updater_Set 
# Function name will Update the test results back to RQM
# INPUT PARAMETERS:
#           1) string: TestCaseInfo(Dictionary containing TCF file info), TestCase_ID
#
# OUTPUT PARAMETERS:
#           1) Dictionary : Test Case Info
#*********************************************************************************************************

def RQM_Updater_Set():
#    global TestCaseInfo
    CanoeTest = False
    ADTF_Test= False
    Test_Result_file_Path = []
    Test_Iteration_details = 'None'
    Test_Env_Details = 'None'
    Test_Plan_details = 'None'
    
    try:                
        MyLog.Append("[RQM_UPDATER][STATUS]::: Updation of test result to RQM :::START")        
        print("[RQM_UPDATER][STATUS]::: Updation of test result to RQM :::START")
        #Check if test case is Resbus , ADTF ..         
        CanoeTest = True
        try:                    
            file=open(param.RQM_XML_PATH,'r')
            Test_Result_file_Path = file.readlines()
            file.close()   
        except Exception as reason:
            MyLog.AppendException("[TSE_FileReader][STATUS]::: Opening TSE_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
            MyLog.AppendException(reason)
            print("STATUS::: Opening TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
            print(reason) 
            sys.exit(1)

        #Extracting test plan, test Iteration and Test Environment details
        for line in TestCaseInfo:
            if 'Test_Iteration' in line:
                Test_Iteration_details = line.split('=')[1]

        for line in TestCaseInfo:
            if 'Test_Environment' in line:
                Test_Env_Details = line.split('=')[1]

        for line in TestCaseInfo:
            if 'Test_Plan_ID' in line:
                Test_Plan_details = line.split('=')[1]
            
        RQM_Test_Init(Test_Result_file_Path[0],Test_Iteration_details,Test_Plan_details,Test_Env_Details,param.config)
        MyLog.Append("[RQM_UPDATER][INFO]::: Test Case is of type RESTBUS:::Hence RQM_Update from RQM_Utility tool is started ")
        print("[RQM_UPDATER][INFO]::: Test Case is of type RESTBUS:::Hence RQM_Update from RQM_Utility tool is started ")
        MyLog.Append("[RQM_UPDATER][INFO]:::Launching the RQM_Utility tool to update Canoe Result from the result path")        
        print(" [RQM_UPDATER][INFO]:::Launching the RQM_Utility tool to update Canoe Result from the result path")
            
        
             
    except Exception as reason:
        MyLog.AppendException("[RQM_UPDATER][STATUS]::: Updation of test result to RQM for TC :::EXCEPTION:::ERROR[5] /n")
        MyLog.AppendException("[RQM_UPDATER][HINT1]::: Make sure TCF file contains all the details like TestCase ID, TestPlan name and Test iteration etc.. \n")
        MyLog.AppendException("[RQM_UPDATER][HINT2]::: Make sure you placed correct RQM_Account.cfg file under C:\\Users\gta2kor folder and login credentatials are correct \n")
        MyLog.AppendException(reason)
        print("[RQM_UPDATER][STATUS]::: Updation of test result to RQM for TC :::EXCEPTION:::ERROR[5] /n")
        print(reason) 
        sys.exit(1)

#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_1: Read TCF file 
# Function name will read TCF file received from Jenkins 
# INPUT PARAMETERS:
#           1) string: TCF File
#
# OUTPUT PARAMETERS:
#           1) Dictionary : Test Case Info
#*********************************************************************************************************
       
def TCF_FileReader_Set(tseFile):
    try:
        global TestCaseInfo # +++
        global nowTime
        TestCaseInfo = [] # +++
        nowTime = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime())
        
        MyLog.Append("[TSE_FileReader][STATUS]:::Reading the TSE file:::START")
        print("STATUS:::Reading the TSE file:::START")
        #testCaseInfo_pattern = r'TestCase.*Info.([ A-Za-z0-9_]+)\s*=\s*\"(.+)\"'
        #testCaseInfo_re = re.compile(testCaseInfo_pattern)
        try:                    
            file=open(tseFile,'r')
            lines = file.readlines()
            file.close()   
        except Exception as reason:
            MyLog.AppendException("[TSE_FileReader][STATUS]::: Opening TSE_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
            MyLog.AppendException(reason)
            print("STATUS::: Opening TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
            print(reason) 
            sys.exit(1)
        
        for line in lines :
            TestCaseInfo.append(line.split('\n')[0])
        print("Received Test Case Info is :")
        print(TestCaseInfo);


            
            #match = testCaseInfo_re.match(line)
            #if match:
             #   TestCaseInfo[(match.group(1)).strip()] = (match.group(2)).strip()
              #  MyLog.Append("[TSE_FileReader][Info]:::{0} = {1}".format(match.group(1),match.group(2))) 
                #print("Info:::{0} = {1}".format(match.group(1),match.group(2))) 
    
        MyLog.Append("[TSE_FileReader][STATUS]:::Reading the TCF file:::SUCCESSFUL")
        print("STATUS:::Reading the TCF file:::SUCCESSFUL")
        
    except Exception as reason:
        MyLog.AppendException("[TCF_FileReader][STATUS]::: Reading TSE_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
        MyLog.AppendException(reason)
        print("STATUS::: Reading TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
        print(reason) 
        sys.exit(1)
        
        
    
if __name__ == "__main__":
    try:
        Test_Triger_Return = []
        #The below pickle code is only for ADTF
        '''
        Test_Triger_Return = []
        dbfile = open("Test_Triger_Pickle", 'rb')
        db = pickle.load(dbfile)
        for values in db:
            Test_Triger_Return.append(values)
        print(Test_Triger_Return)
        '''
        
        TCF_FileReader_Set(param.TSE_FileName_Path)   
        RQM_Updater_Set() 

        
    finally:
        if MyLog:
            del MyLog    
        print("################################################ RQM Updater Execution Completed ###############################################")
