'''
Created on Dec 19, 2018

@author: krm9kor

Description:
Script to control tollner (TOE8952) power supply.
'''
import serial
import os
import argparse
import exceptions
import time


class TOE895X:
    def __init__(self, port, baudrate, timeout, wtimeout, parity, stopbits,\
                 xonxoff) :
        """
        Class containes the functions to control the Tollner TOE8952 power
        supply.
        """
        self._ser = serial.Serial()
        self._ser.port = port
        self._ser.baudrate = baudrate
        self._ser.timeout = float(timeout)
        self._ser.write_timeout = float(wtimeout)
        self._ser.parity = parity
        self._ser.stopbits = stopbits
        self._ser.xonxoff = xonxoff
        self.minvolt = 0
        self.maxvolt = 0
        self._ser.open()
        
        #startup actions start
        try:
            self._ser.write('*CLS\r\n')
            print("erase system state")
        except BaseException as err:
            print("error erasing system state: {0}".format(err))
        
        try:
            self._ser.write('SYSTem:REMote\r\n')
            print("activate remote control")
        except BaseException as err:
            print("error activating remote control: {0}".format(err))
        
        #startup actions end

    def stop_voltage(self):
        """
        Reads the voltage from the device.
        """
        try:
            self._ser.write('V 0\r\n')
            print("Stopping Voltage: ")
        except BaseException as err:
            print("Error reading voltage: {0}".format(err))
            voltage = 9999
        return 0

    def start_voltage(self):
        """
        Reads the voltage from the device.
        """
        try:
            self._ser.write('V 12\r\n')
            print("Setting to 12v: ")
        except BaseException as err:
            print("Error reading voltage: {0}".format(err))
            voltage = 9999
        return 0

    def read_status(self):
        """
        Reads the voltage from the device.
        """
        try:
            self._ser.write('M?\r\n')
            pow_status = self._ser.readline()
            txt = "Status: {}"
            print (txt.format(pow_status))
        except BaseException as err:
            print("Error reading status: {0}".format(err))
            pow_status = 9999
        return 0

    def close_port(self):
        """
        Close port at the end.
        """
        self._ser.close()

if __name__ == '__main__':
    if os.name == "nt":
        default_port = "COM5"
        print("hi port4")
    elif os.name == "posix":
        default_port = "/dev/ttyS0"
        print("hello")
    parser = argparse.ArgumentParser(description="Control the Tollner power\
     supply")
    parser.add_argument('-p', metavar = "PORTNUMBER",\
                        default = str(default_port),
                help = 'serial port number to which the tolner is connected')
    parser.add_argument('-ap', nargs = '?', default = "N",\
                       metavar = "PARITY", choices = ['N', 'E', 'O', 'M', 'S'],\
                       help = 'parity that has to be set')
    parser.add_argument('-s', nargs='?', default = "1", type = int,\
            metavar = "STOPBITS", choices = (1, 1.5, 2), help='set Stop bits')
    parser.add_argument('-x', nargs = '?', default = "1", type = bool,\
                        choices = ("Xon/Xoff", "RTS/CTS"), metavar = "XONOFF",\
                        help = 'set XONOFF to True or False')
    parser.add_argument('-t', nargs = '?', default = "0.25",\
                        metavar = "TIMEOUT",\
                        help = 'timeout until the serial port has to be read.')
    parser.add_argument('-b', nargs = '?', default = 9600, type = int,\
            metavar = 'BAUDRATE', help = 'baudrate value, default : 9600')
    parser.add_argument('-w', nargs = '?', default = "1.0",\
            metavar = "WRITETIMEOUT", help = 'Write timeout.')
    parser.add_argument('-W', nargs = '?',default = "2", metavar = "WAITTIME",\
                        type = int, help = 'Wait time after setting')
    parser.add_argument('-c', nargs = '?', default = "1", type = int,\
            metavar = "Channel", help = 'Output Channel.')
    parser.add_argument('-v', nargs = '?',default = "12", metavar = "VALUE",\
                        help = 'Value to be set.')
    parser.add_argument('-a','-o', nargs = '?', default = "stop", required = True,\
            metavar = "OPTIONS", help = '')
    args = parser.parse_args()
    switch = TOE895X(args.p, args.b, args.t, args.w, args.ap, args.s, args.x)
    if args.a == "stop":
        switch.stop_voltage()
        time.sleep(2)
        switch.read_status()
    elif args.a == "start":
        switch.start_voltage()
        time.sleep(2)
        switch.read_status()
    elif args.a == "restart":
        switch.stop_voltage()
        time.sleep(2)
        switch.read_status()
        switch.start_voltage()
        time.sleep(2)
        switch.read_status()
    elif args.a == "status":
        switch.read_status()
    switch.close_port()
