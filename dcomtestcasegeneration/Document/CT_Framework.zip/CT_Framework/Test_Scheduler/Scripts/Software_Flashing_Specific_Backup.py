
#=============================================================================
#  C O P Y R I G H T
#-----------------------------------------------------------------------------
#  Copyright (c) 2019 by Robert Bosch Engineering and Buisiness Limited. All rights reserved.
#
#  This file is property of Robert Bosch Engineering and Buisiness India Limited. Any unauthorised copy, use or 
#  distribution is an offensive act against international law and may be 
#  prosecuted under federal law. Its content is company confidential.
#=============================================================================
#  D E S C R I P T I O N
#-----------------------------------------------------------------------------
#       Projectname: 
#          Synopsis: Regression Test - Python Application Wraper for ATV 
#  Target system(s): win32
#       Compiler(s): python 3.8.3
#===============================================================================================
#  N O T E S
#-----------------------------------------------------------------------------------------------
#  Notes: 
#================================================================================================
#  I N I T I A L   A U T H O R   I D E N T I T Y
#------------------------------------------------------------------------------------------------
#  Name:Sudarshan (RBEI/ESD-PP52), Sunny Kumar (RBEI/ESD-PP52) and Govindaraju T (RBEI/ESD-PP)
#  Department: RBEI/ESD - PP
#================================================================================================
#  R E V I S I O N   I N F O R M A T I O N
#------------------------------------------------------------------------------------------------
## 
## - Reviewed version: 
## - Type (use 'X' to mark):
##     - [ ] Formal Review
##     - [ ] Walkthrough
##     - [ ] Inspection
## - State including date (DD.MM.YYYY)
##     - [--.--.----] Preparation
##     - [--.--.----] Review audit
##     - [--.--.----] Integration of findings
##     - [--.--.----] Test
##     - [--.--.----] Verification of integration of findings
##     - [--.--.----] Review release
## - Responsible:
## - Review-Document:
#=============================================================================
# ---------------------------------------------------------------------------------
# Run from Windows command line :  >> python Software_Flashing.py -t "Path_TCF_file" 
#
# ----------------------------------------------------------------------------------- 

import sys, time, os 
import subprocess
import Log
import shutil
import re
import pyrocopy as robocopy
import Parameter_List as param
import psutil
import glob
from zipfile import ZipFile
#RQM_Updater_Scripts.rqm_update import *
#from RunCanoe import *
#import py7zr
from pyunpack import Archive

#*************************************************************
#        OBJECT_INTIALIZATION
#
#*************************************************************
#MyLog = Log.LOG(param.logpath+"\\"+'CT_Python_Wraper_Software_Flashing.txt')


# -----------------------------------------------------------------------------
    #            BELOW ARE SOFTWARE FLASHING FUNCTIONS
    # -----------------------------------------------------------------------------
    
def Copy_V3H_SW(Server_V3H_Path):
     #Copying the SW from server to Test PC
    try:
        print("::: Copying of SW has started ..... please wait for sometime.....")
        Test_PC_Path=param.Binary_Path
        Result=robocopy.copy(Server_V3H_Path, Test_PC_Path,forceOverwrite = True) 
        print(":::: COPYING of SW is successful below is the result"+"\n"  )     
        print (Result)
    except Exception  as reason:
        print ("Exception::: While copying file from server")
        print(reason)


def Flash_mode():
   #Enter to Flash Mode
   try:
       print("Start::: Entering to Flash mode:::::")
       print(param.RelayPath)
       #command='python {}\\Flashmode.py '.format(param.RelayPath)
       command='{}\\for_flash_mode.bat '.format(param.RelayPath)
       print(command)
       ret = subprocess.call(command, shell=True, cwd=param.RelayPath, stdout=sys.stdout, stderr=sys.stderr) 
       #os.system(command)
       time.sleep(5)               
       print(":::SUCCESS::: Enterted to Flash mode") 
   except Exception  as reason:
        print ("Exception::: While calling the Flash mode")
        print(reason)

def Normal_mode():
   #Enter to Normal Mode
   try:            
       print ("Start::: Entering to Normal mode")
       command= '{}\\for_normal_mode.bat '.format(param.RelayPath)
       ret = subprocess.call(command, shell=True, cwd=param.RelayPath, stdout=sys.stdout, stderr=sys.stderr) 
       #os.system(command)
       time.sleep(5)                    
       print( ":::SUCCESS::: Enterted to Normal mode"   ) 
   except Exception  as reason:
        print ("Exception::: While calling the Normal mode mode")
        print(reason)
  
def Flash_Binaries(bin_path):
    #Upload flashtool an flash the SW binaries
   '''
    This is the function to invoke shell process and provide the commands received from cmd prompt to control the relay box.
    '''
   try: 
       print ("[Flash_Binaries][INFO]::Flash tool is uploading please wait for sometime....")
       #MyLog.Append("[Flash_Binaries][INFO]::: Flash tool is uploading please wait for sometime....")
       print(bin_path)
       #FLASH_DIR = param.UARTFlashToolPath
       FLASH_DIR = r'D:\Jenkins\SW_Flash_Files\Binaries\fv_if\tools\FlashtoolTerminal'
       
       #Flash_commands="python devcom_easy_flash.py -p COM11 -r D:\\Automation\\Automated_Flashing\\V3H_SW\\build\\pirate_sc0sec_release\\bin -o complete_container -u y"
       #Flash_commands= "python devcom_easy_flash_C3.py -p COM11 -r D:\Jenkins\SW_Flash_Files\Binaries\build\pfmono_sc2pf_release\bin -o complete_container -u y"
       Flash_commands='C:\Python38\python.exe devcom_easy_flash_C3.py -p {1} -r {0} -o complete_container -u y'.format(param.FlashContainerPath,param.Flash_COM_Port)
       print("[Flash_Binaries][INFO] Flash command::{0}".format(Flash_commands))
       ret = subprocess.call(Flash_commands,shell=True,cwd=FLASH_DIR,stdout=sys.stdout, stderr=sys.stderr)
       #os.system(Flash_commands)

   except Exception  as reason:
        print("[Flash_Binaries][INFO]::: EXCEPTION::: While Uploading Flashtool or flashing the Binaries")
        print(reason)

def unzip_Files(bin_path,dest):
    try:
        #with ZipFile(bin_path, 'r') as zip_ref:
            #zip_ref.extractall(dest)
        #with py7zr.SevenZipFile(bin_path, mode='r') as z:
            #z.extractall(dest)
        Archive(bin_path).extractall(dest)
        MyLog.Append("[unzip_Files][STATUS]::: Unzipping the files to the destination path :::SUCCESSFUL")
        print("[unzip_Files][STATUS]::: Unzipping the files to the destination path :::SUCCESSFUL")
        
    except Exception as reason:
        MyLog.AppendException("[unzip_Files][STATUS]::: Unzipping the files to the destination path :::EXCEPTION:::ERROR[1]")
        MyLog.AppendException(reason)
        print("[unzip_Files][STATUS]::: Unzipping the files to the destination path :::EXCEPTION:::ERROR[1]")
        print(reason) 
        sys.exit(1)

def FlashSetupMain(SW_Version_TC,BIN_File_Path):
    try:
        files = os.listdir(param.Binary_Path)
        print(files)
        for f in files:
            try:
                print(os.path.join(param.Binary_Path,f))
                shutil.rmtree(os.path.join(param.Binary_Path,f))
            except:
                os.remove(os.path.join(param.Binary_Path,f))
        MyLog.Append("[COPYING SOFTWARE]::: :The SW binary is being copied from server path to local folders")
        print("[COPYING SOFTWARE]::The SW binary is being copied from :::: {}\\{}\\{}".format(param.Binary_Server_Path,SW_Version_TC,BIN_File_Path))
        Copy_V3H_SW('{}\\{}\\{}'.format(param.Binary_Server_Path,SW_Version_TC,BIN_File_Path))
        print('[SOFTWARE EXTRACTION]:::The SW binary is extracted and saved to :::: {}\\{}'.format(param.Binary_Path,BIN_File_Path))
        unzip_Files('{}\\{}'.format(param.Binary_Path,BIN_File_Path),param.Binary_Path)   
        Flash_mode()
        time.sleep(5)
        print("[CAMERA MODE]:::Camera is in FLASHING mode :::")        
        Flash_Binaries('{}\\bin'.format(param.Binary_Path))
        time.sleep(5) 
        Normal_mode()
        print("[CAMERA MODE]:::Camera is in BOOT mode :::") 
        #print("[FLASHING STATUS]:::Flashing Successful")

    except Exception as reason:
        print ("Exception::: Error in Flashing")
        print(reason)
        

# OUTPUT PARAMETERS:
#           1) SW_Version_Number
#**********************************************************************************************************
def Software_Flashing_Get():
    SW_Version_Number="None"        
    MyLog.Append("[SW_DOWNLOAD][STATUS]:::Reading the software version from DUT:::START")
    print("STATUS:::Reading the software version from DUT:::START")

    #Please insert Project specific code for reading the DUT software Version
    try:
        print("[Software_Flashing_Set][INFO]::: Reading from SW_Flashing_Status.txt file in the path ")
        MyLog.Append("[Software_Flashing_Set][INFO]::: Reading from SW_Flashing_Status.txt file in the path ")
        with open(param.SW_Flashing_Status,'r') as SW_Status:
            SW_Version_Number=SW_Status.read()
        
    except Exception as reason:
        MyLog.AppendException("[Software_Flashing_Set][STATUS]::: Reading from SW_Flashing_Status.txt file in the path:::EXCEPTION:::ERROR[2]")
        MyLog.AppendException(reason)
        print("[Software_Flashing_Set][STATUS]::: Reading from SW_Flashing_Status.txt file in the path :::EXCEPTION:::ERROR[2]")
        print(reason) 
        sys.exit(1)
        
    
        
    MyLog.Append("[SW_DOWNLOAD][STATUS]:::Recevied sofware version from DUT is :::{0} :::SUCCESS \n".format(SW_Version_Number))
    print("SUCCESS:::Recevied sofware version from DUT is :::{0} \n".format(SW_Version_Number))
    
    
    return SW_Version_Number
    #sys.exit(1)





#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_2: Software_Flashing_Set 
#Function Description:
#This function will flash the software version to DUT and this will be triggered only incase of version mismatch in Software_Flashing_Check()
#INPUT PARAMETERS:
#           1)Version_Number #Version number toflash
#
# OUTPUT PARAMETERS:
#           1) None
#**********************************************************************************************************


def Software_Flashing_Set(SW_Version_TC,BIN_File_Path):
    try:
        #MyLog.Append("Software_Flashing_Set:::START \n")
        MyLog.Append("[SW_DOWNLOAD][STATUS]::: Flashing the software version:::{0}:::START \n".format(SW_Version_TC))        
        print("[SW_DOWNLOAD][STATUS]:::Software version to be flashed::: {0} \n".format(SW_Version_TC))
        #Copy the Binaries from Server to PC for flashing 

        #Please insert project specific code for flashing the DUT
        FlashSetupMain(SW_Version_TC,BIN_File_Path)

        #Setting the SW flashing success flag
        try:
            print("[Software_Flashing_Set][INFO]::: Writing into SW_Flashing_Status.txt file in the path ")
            MyLog.Append("[Software_Flashing_Set][INFO]::: Writing into SW_Flashing_Status.txt file in the path ")
            file = open(param.SW_Flashing_Status, "w")
            file.write("SW_Flashed_Success")
            file.close


            
        except Exception as reason:
            MyLog.AppendException("[Software_Flashing_Set][STATUS]::: Writing into SW_Flashing_Status.txt file in the path:::EXCEPTION:::ERROR[2]")
            MyLog.AppendException(reason)
            print("[Software_Flashing_Set][STATUS]::: Writing into SW_Flashing_Status.txt file in the path :::EXCEPTION:::ERROR[2]")
            print(reason)
            sys.exit(1)
                        
        
        MyLog.Append("[SW_DOWNLOAD][STATUS]:::Flashing completed succesfully and UART loging also started:::SUCCESS")
        print("STATUS:::Flashing completed succesfully and UART loging also started:::SUCCESS")
        
    except Exception as reason:
        MyLog.AppendException("[SW_DOWNLOAD][STATUS]::: Software_Flashing_Set in the function :::EXCEPTION:::ERROR[2] /n")
        MyLog.AppendException(reason)
        print("STATUS::: Software_Flashing_Set in the function ::: EXCEPTION ")
        print(reason) 
        sys.exit(1)


if __name__ == "__main__":
    #Software_Flashing_Set('FV0200_v9.0','pfmono_sc2pf_release.7z')
    #unzip_Files(r'D:\Binaries\FV0200_v9.0\pfmono_sc2pf_release.7z',r'D:\Binaries\FV0200_v9.0\v9.0')
    #Enter to Flash Mode
    Flash_mode()
    time.sleep(5)
    #Start Flashing the software
    bin_path= r'D:\Jenkins\SW_Flash_Files\Binaries\build\pfmono_sc2pf_release\bin'    
    Flash_Binaries(bin_path)
    time.sleep(5)
    #Enter to normal Mode
    Normal_mode()
    time.sleep(5)
