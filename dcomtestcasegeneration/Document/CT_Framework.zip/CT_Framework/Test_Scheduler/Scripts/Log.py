# coding: latin-1

"""
#############################################################################################################
# FILE: Log.py
# AUTHOR: Sunny Kumar
# DATE: 24/10/2016
# DESCRIPTION: This file contain the class for the management of "Test Log File".
# REQUIREMENTS: File required ->
#                                                                                                                                                              #
#############################################################################################################
"""
import time
import traceback

class LOG:

    #Class constructor
    def __init__(self,NameFile):
        self.NameFile = NameFile
        MyFile = open (NameFile, 'w')
        MyFile.write('*********************************************************************************************\n\n')
        MyFile.write('                               JLR-Continous_Test_Automation \n')
        MyFile.write('                                Python_wraper log\n\n')
        MyFile.write('*********************************************************************************************\n')
        MyFile.write(time.strftime("                                    %d %b %Y - %X\n",time.localtime(time.time())))
        MyFile.write('*********************************************************************************************\n\n')
        MyFile.close()


    #Class destructor
    def __del__(self):
        """
        Destructor body
        """


#------------------------------------------------
#   LIST OF CLASS METHODS
#------------------------------------------------

############################################################################################################
# METHOD NAME: Append
# METHOD DESCRIPTION: This method append a string in Test Log File
#
# INPUT PARAMETERS:
#           1) string: string to append in Test Log File
#
# OUTPUT PARAMETERS:
#           1) Result: None if an exception is raised; TRUE if Append operation is executed
#
############################################################################################################
    def Append(self, stringa):
        Result = 1
        try:
            MyFile = open (self.NameFile, 'r+')
            NewStr = time.strftime("%X:  ",time.localtime(time.time())) + stringa + "\n"
            MyFile.seek (0,2)
            MyFile.write (NewStr)
            MyFile.close ()
        except:
            Result = None

        return Result

############################################################################################################
# METHOD NAME: AppendException
# METHOD DESCRIPTION: This method append in Test Log File the string passed as argument and the last
#                     exception raised
#
# INPUT PARAMETERS:
#           1) string: string to append in Test Log File
#
# OUTPUT PARAMETERS:
#           1) Result: None if an exception is raised; TRUE if Append operation is executed
#
############################################################################################################
    def AppendException(self, string):


        Result = 1
        try:
            MyFile = open (self.NameFile, 'r+')
            NewStr = time.strftime("%X:  ",time.localtime(time.time())) + string + "\n"
            MyFile.seek (0,2)
            MyFile.write (NewStr)
            #traceback.print_exc(None,MyFile)
            #MyFile.write ('\n')
            MyFile.close ()
        except:
            Result = None

        return Result



