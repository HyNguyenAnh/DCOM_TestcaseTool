print("=================inside run_tests================")
import canoe_client
import argparse
import os
import sys
import time
import json
from shutil import copyfile
import Log
import Parameter_List as param

print("------------inside run_tests----------------")


def CANoeRUN_Tests_Set(test_unit,variant,MyLog):
    #perform tests

    CanoeInitcheck = 10
    for retry in range(CanoeInitcheck): 
        try :
            MyLog.Append("[TEST_TRIGGER][STATUS]::: CANoe application initialisation ::: START")
            print("[TEST_TRIGGER][STATUS]::: CANoe application initialisation ::: START" )
            #Launch Canoe in Default Configuration
            canoeClient = canoe_client.CANoeClient()
            MyLog.Append("[TEST_TRIGGER][STATUS]::: CANoe application initialisation ::: SUCCESSFUL")
            print("[TEST_TRIGGER][STATUS]::: CANoe application initialisation ::: SUCCESSFUL" )
            break
        except Exception as reason: 
            retry = retry+1
            print('< Canoe application initialisation failed. Retrying initialisation...',str(CanoeInitcheck-retry),'trials left.>')
            print(reason)
            time.sleep(10)
            if retry == CanoeInitcheck:
                MyLog.Append("[TEST_TRIGGER][STATUS]::: CANoe application initialisation :::EXCEPTION:::ERROR[5]")
                print("[TEST_TRIGGER][STATUS]::: CANoe application initialisation :::EXCEPTION:::ERROR[5]" )
                print(" ######################## CANoe initialisation failed  ########################")
                sys.exit(1)

    
    #Get the variant specific details
    variant_specific=param.VARIANT_SPECIFIC[variant]
    #print(variant_specific)

    #Preparing all the parameters for running the tests.
    #Create a list to store the test units
    testUnits=[]
    configuration=variant_specific[0]+variant_specific[1]+".cfg"
    testUnits.append(variant_specific[0]+"\\Test_Scripts\\"+test_unit.split()[0]+".vtuexe")
    reportfolder=param.CANOE_REPORT_FOLDER
    testPlans=[]
    variant=variant_specific[2]
    xcpconfiguration=variant_specific[3]+variant_specific[4]+".xcpcfg"
    
    
                
    


            
    try:
        MyLog.Append("[TEST_TRIGGER][STATUS]::: Load CANoe Configuration and Run Test::: START")
        print("[TEST_TRIGGER][STATUS]::: Load CANoe Configuration and Run Test::: START" )
        #Open Specific configuration and run tests with selected variant
        testsSuccessful = canoeClient.performTests(
            configurationFilePath=configuration,
            testUnitPaths=testUnits,
            reportFolder=reportfolder,
            testPlans=testPlans,
            variantValue=variant,
            xcpConfigurationFilePath=xcpconfiguration)
        MyLog.Append("[TEST_TRIGGER][STATUS]::: Load CANoe Configuration and Run Test::: SUCCESSFUL")
        print("[TEST_TRIGGER][STATUS]::: Load CANoe Configuration and Run Test::: SUCCESSFUL")
        
        # deallocate CANoeClient class instance
        canoeClient = None
        
        
        #evaluate overall test result
        if not param.ignoreTestResult and not testsSuccessful:
            raise Exception("The overall test result is NOT PASSED. Please check the individual test case results in the test report!") 
    except Exception as reason:
        MyLog.Append("[TEST_TRIGGER][STATUS]::: Load CANoe Configuration and Run Test:::EXCEPTION:::ERROR[5]")
        MyLog.AppendException(reason)
        print("[TEST_TRIGGER][STATUS]::: Load CANoe Configuration :::EXCEPTION:::ERROR[5]")
        print(reason)
        sys.exit(1)
    
    
    
    
    
    
if __name__ == '__main__':
    print("------------inside run_tests-------__main__---------")
    #parse command line arguments
    commandLineParser = argparse.ArgumentParser(description= 'Executes the test units passed in CANoe. For automation the CANoe com interface is used.')      
    commandLineParser.add_argument('--testunits', action="store", nargs="+", dest= "testUnits")
    commandLineParser.add_argument('--configuration', action="store", dest= "configuration")
    commandLineParser.add_argument('--xcpconfiguration', action="store", dest="xcpconfiguration")
    commandLineParser.add_argument('--variant', action="store", dest= "variant")
    commandLineParser.add_argument('--reportfolder', action="store", dest="reportfolder")
    commandLineParser.add_argument('--testplanfolder', action="store", dest="testplanfolder")
    commandLineParser.add_argument('--ignoreTestResult', action="store_true", default = False, dest="ignoreTestResult")
    arguments = commandLineParser.parse_args()
    

                         
    
    
         
