import sys
import glob
import os
import shutil
import Log
import Parameter_List as param
from zipfile import ZipFile
import pyrocopy as robocopy

#*************************************************************
#        OBJECT_INTIALIZATION
#
#*************************************************************
MyLog = Log.LOG(param.logpath+"\\"+'CT_Python_Wraper_Software_Flashing.txt')


def unzip_binaries(bin_path,dest):
    try:
        with ZipFile(bin_path, 'r') as zip_ref:
            zip_ref.extractall(dest)
        MyLog.Append("[unzip_binaries][STATUS]::: Unzipping the binaries to the destination path :::SUCCESSFUL")
        print("[unzip_binaries][STATUS]::: Unzipping the binaries to the destination path :::SUCCESSFUL")
        
    except Exception as reason:
        MyLog.AppendException("[unzip_binaries][STATUS]::: Unzipping the binaries to the destination path :::EXCEPTION:::ERROR[1]")
        MyLog.AppendException(reason)
        print("STATUS::: Unzipping the binaries to the destination path :::EXCEPTION:::ERROR[1]")
        print(reason) 
        sys.exit(1)
        

def Copy_Binaries_Move_A2L(bin_path,variant):
    
    try:
        binaries_path=os.path.abspath(bin_path)
        print(binaries_path)
        #Unzipping the binaries
        #unzip_binaries(bin_path,param.Unzip_Binaries_Path)
    
    '''
    zip_name=binaries_path.split('\\')[-1]
    #Take only the zip folder name and exclude .zip
    zip_name=zip_name[:-4]
    print(zip_name)

    #Get the variant specific details
    variant_specific=param.VARIANT_SPECIFIC[variant]

    
    src_path = param.Unzip_Binaries_Path+'\\' + zip_name + '\\generatedFiles\\bin\\'
    dst_path =  variant_specific[3]+'\\A2L\\'

    if not os.path.exists(dst_path):
        print ("Creating A2L folder")
        os.makedirs(dst_path)
        MyLog.Append("[Copy_Binaries_Move_A2L][STATUS]::: Creating A2L folder in the RBS path :::SUCCESSFUL")
        print("[Copy_Binaries_Move_A2L][STATUS]::: Creating A2L folder in the RBS path :::SUCCESSFUL")

    try:
        MyLog.Append("[Copy_Binaries_Move_A2L][STATUS]::: Copying A2L files to the RBS folder path :::START")
        print("[Copy_Binaries_Move_A2L][STATUS]::: Copying A2L files to the RBS folder path :::START")
        a2l_files = glob.glob(src_path+ "*.a2l")
        print("A2L_Files", a2l_files)

        if len(a2l_files) != 0:
            for a2lf in a2l_files:
                
                robocopy.copy(a2lf, dst_path)
            print ('Successfully copied all .a2l files!')
            MyLog.Append("[Copy_Binaries_Move_A2L][STATUS]::: Copying A2L files to the RBS folder path :::SUCCESSFUL")
            print("[Copy_Binaries_Move_A2L][STATUS]::: Copying A2L files to the RBS folder path :::SUCCESSFUL")
        else:
            raise Exception ('No .a2l file exists in the current CTC')
    '''
    except Exception as reason:
        MyLog.AppendException("[Copy_Binaries_Move_A2L][STATUS]::: Copying A2L files to the RBS folder path :::EXCEPTION:::ERROR[1]")
        MyLog.AppendException(reason)
        print("[Copy_Binaries_Move_A2L][STATUS]::: Copying A2L files to the RBS folder path :::EXCEPTION:::ERROR[1]")
        print(reason) 
        sys.exit(1)

if __name__ == '__main__':

    path= r'D:/Test/Binaries/NRCS2_PP6_FCA_WL75MY21_CVPAM006.2.zip'

    Copy_Binaries_Move_A2L(path,'WLCVPAM_High')
