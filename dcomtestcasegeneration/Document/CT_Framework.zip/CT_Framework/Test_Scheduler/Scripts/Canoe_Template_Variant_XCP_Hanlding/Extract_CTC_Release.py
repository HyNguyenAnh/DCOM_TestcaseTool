import sys
import glob
import os
import shutil
import Log
import Parameter_List as param


'''
zipname = sys.argv[1]
#zipname = "NRCS2_PP6_FCA_WLL2PMY21_CVPAM002"
print("zipname:",zipname)
'''
def get_CTC_Release(zipname,MyLog):
    cwd = os.getcwd()
    print ("cwd:",cwd)
    rls=""

    try:
        zip_name = zipname.split('_')
        length = len(zip_name)
        print("zip_name:",zip_name)

        
    except Exception as reason:
        MyLog.AppendException("[get_CTC_Release][STATUS]::: Splitting the Test_Iteration from tcf file in the function :::EXCEPTION:::ERROR[1]")
        MyLog.AppendException(reason)
        print("STATUS::: Splitting the Test_Iteration from tcf file in the function :::EXCEPTION:::ERROR[1]")
        print(reason) 
        sys.exit(1)


    #Check if zip_name exists
    if any( zip_name): 
        if ("NRCS2" in zip_name) and ("PP6" in zip_name):
            if ("WL75MY21" in zip_name) or ("WLL2PMY21" in zip_name) or ("WSMY21" in zip_name):
                rls = zip_name[length-1].upper()
               

        print ("Release No:-",rls)
    
    try:
        #file = open(cwd + "\\03_ContinousTesting\\Jenkins\\src\\CTC_Release.txt", "w")
        file = open(param.Release_File_Path, "w")
        print("CTC_Release path:",file)    
    

        if "CVPAM" in rls:
            MyLog.Append("[EXTRACT_CTC_RELEASE][STATUS]::: Release Number extracted from Test_Iteration :::{0}::::::SUCCESSFUL".format(rls))
            print("[EXTRACT_CTC_RELEASE][STATUS]::: Release Number extracted from Test_Iteration :::{0}::::::SUCCESSFUL".format(rls))
            file.write(rls)
        else: 
            raise Exception ('No Release name found in CTC .zip name')
            sys.exit(1)
        file.close

    except Exception as reason:
        MyLog.AppendException("[get_CTC_Release][STATUS]::: Opening CTC_Release.txt in the function :::EXCEPTION:::ERROR[1]")
        MyLog.AppendException(reason)
        print("STATUS::: Opening CTC_Release.txt in the function :::EXCEPTION:::ERROR[1]")
        print(reason) 
        sys.exit(1)

#get_CTC_Release(zipname)
