#*************************************************************
#        GLOBAL_PARAMETER_INTIALIZATION
#**************************************************************
Software_Flash_Max_Timeout = 120
config = "VID_ FCA _NRCS2 (qm)"
TCF_File_Path = r'D:\Jenkins\TestAutomation\03_ContinousTesting\SFA_Automation\CT_Framework\Test_Scheduler\Scripts\Received.tcf'
Log_Serevr_Path ="None"
Software_Version ="4.7.1"
logpath=r"D:\Jenkins\TestAutomation\03_ContinousTesting\SFA_Automation\CT_Framework\Test_Scheduler\Scripts\Python_wrapper_logs"



#Software Flashing Regex
TCF_Iteration_regex=r'.*NRCS2_.*_FCA_(.*)'

#Software flashing Binaries unzipping path
Unzip_Binaries_Path=r"D:\Jenkins\TestAutomation\binaries"

#Run Canoe
CANOE_FOLDER_PATH_WL_CVPAM = 'D:\\Jenkins\\TestAutomation\\01_TestEnvironment\\CANoe\\FCA_WL_NRCS_CVPAM\\CVPAM_WL_R4_1936_CANFD_RBS\\'
CANOE_FOLDER_PATH_WS_CVPAM = 'D:\\Jenkins\\TestAutomation\\01_TestEnvironment\\CANoe\\FCA_WS_NRCS_CVPAM\\CVPAM_WS_R3_1937_CANFD_RBS\\'

XCP_CONFIGURATION_WL_CVPAM =  'D:\\Jenkins\\TestAutomation\\01_TestEnvironment\\CANoe\\FCA_WL_NRCS_CVPAM\\CVPAM_WL_R4_1936_CANFD_RBS\\'
XCP_CONFIGURATION_WS_CVPAM = 'D:\\Jenkins\\TestAutomation\\01_TestEnvironment\\CANoe\\FCA_WS_NRCS_CVPAM\\CVPAM_WS_R3_1937_CANFD_RBS\\'

#If ignoreTestResult is set to False, Exception is raised if the test fails 
ignoreTestResult=True

CANOE_REPORT_FOLDER = 'D:\\Jenkins\\TestAutomation\\04_TestResults\\TestReports'

VARIANT_SPECIFIC={
    "WLCVPAM_High":[CANOE_FOLDER_PATH_WL_CVPAM,'PWL21_E2A_R4_CANFD2_V11','High',XCP_CONFIGURATION_WL_CVPAM,'XCP_Configuration_WL'],
    "WLCVPAM_Low":[CANOE_FOLDER_PATH_WL_CVPAM,'PWL21_E2A_R4_CANFD2_V11','Low',XCP_CONFIGURATION_WL_CVPAM,'XCP_Configuration_WL'],
    
    "WLL2PCVPAM_High":[CANOE_FOLDER_PATH_WL_CVPAM,'PWL21_E2A_R4_CANFD2_V11','Low',XCP_CONFIGURATION_WL_CVPAM,'XCP_Configuration_WL'],
    
    "WSCVPAM_High":[CANOE_FOLDER_PATH_WS_CVPAM,'PWS_E2A_R3_CANFD2_V11','Low',XCP_CONFIGURATION_WS_CVPAM,'XCP_Configuration_WS'],
    
    }

#Report Upload parameters
Project='FCA'
UPLOAD_FOLDER = r'\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Exchange\delete_after_10days\system_test_temp\iyengar\JenkinTestReports'
Release_File_Path=r'D:\Jenkins\TestAutomation\03_ContinousTesting\SFA_Automation\CT_Framework\Test_Scheduler\Scripts\CTC_Release.txt'

#Handshake Result to main server
MAIN_Server_Report_Path= r'\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Exchange\delete_after_10days\system_test_temp\iyengar'
TCF_FileName_Path=r'D:\Jenkins\TestAutomation\03_ContinousTesting\SFA_Automation\CT_Framework\Test_Scheduler\Scripts\TCF_File_Name.txt'
Test_Result_Path=r'D:\Jenkins\TestAutomation\03_ContinousTesting\SFA_Automation\Scripts\CT_Framework\Test_Scheduler\Test_Result.txt'
Consice_Report_Path=r'\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Exchange\delete_after_10days\system_test_temp\iyengar\Full_Report.txt'
Aborted_build_Path=r'\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Exchange\delete_after_10days\system_test_temp\iyengar\Aborted_builds.txt'

