
#=============================================================================
#  C O P Y R I G H T
#-----------------------------------------------------------------------------
#  Copyright (c) 2019 by Robert Bosch Engineering and Buisiness Limited. All rights reserved.
#
#  This file is property of Robert Bosch Engineering and Buisiness India Limited. Any unauthorised copy, use or 
#  distribution is an offensive act against international law and may be 
#  prosecuted under federal law. Its content is company confidential.
#=============================================================================
#  D E S C R I P T I O N
#-----------------------------------------------------------------------------
#       Projectname: 
#          Synopsis: Regression Test - Python Application Wraper for ATV 
#  Target system(s): win32
#       Compiler(s): python 2.7.16
#===============================================================================================
#  N O T E S
#-----------------------------------------------------------------------------------------------
#  Notes: 
#================================================================================================
#  I N I T I A L   A U T H O R   I D E N T I T Y
#------------------------------------------------------------------------------------------------
#  Name:Sudarshan (RBEI/ESD-PP52), Sunny Kumar (RBEI/ESD-PP52) and Govindaraju T (RBEI/ESD-PP)
#  Department: RBEI/ESD - PP
#================================================================================================
#  R E V I S I O N   I N F O R M A T I O N
#------------------------------------------------------------------------------------------------
## 
## - Reviewed version: 
## - Type (use 'X' to mark):
##     - [ ] Formal Review
##     - [ ] Walkthrough
##     - [ ] Inspection
## - State including date (DD.MM.YYYY)
##     - [--.--.----] Preparation
##     - [--.--.----] Review audit
##     - [--.--.----] Integration of findings
##     - [--.--.----] Test
##     - [--.--.----] Verification of integration of findings
##     - [--.--.----] Review release
## - Responsible:
## - Review-Document:
#=============================================================================
# ---------------------------------------------------------------------------------
# Run from Windows command line :  >> python Software_Flashing.py -t D:\Jenkins\Received.tcf 

# python D:\Jenkins\TestAutomation\CT_Framework\Test_Scheduler\Scripts\Software_Flashing.py -p jizhimono_mc0_release.7z -s BL3.0RC01.1 -id 49445 -i BL3.0RC01.1_jizhimono_mc0_release -e TE3406
# python Software_Flashing.py -t D:\Jenkins\Received.tcf
# ----------------------------------------------------------------------------------- 

import sys, time, os 
import subprocess
import Log
import shutil
import re
import pyrocopy as robocopy
import Parameter_List as param
import psutil
import argparse
#RQM_Updater_Scripts.rqm_update import *
#from RunCanoe import *
from Software_Flashing_Specific import *
#from MoveA2L import *

#*************************************************************
#        OBJECT_INTIALIZATION
#
#*************************************************************
MyLog = Log.LOG(param.logpath+"\\"+'CT_Python_Wraper_Software_Flashing.txt')




#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_1: Read TCF file 
# Function name will read TCF file received from Jenkins 
# INPUT PARAMETERS:
#           1) string: TCF File
#
# OUTPUT PARAMETERS:
#           1) Dictionary : Test Case Info
#*********************************************************************************************************
       
def TCF_FileReader_Set(tcfFile):
    try:
        global TestCaseInfo # +++
        global nowTime
        TestCaseInfo = dict() # +++
        nowTime = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime())
        
        MyLog.Append("[TCF_FileReader][STATUS]:::Reading the TCF file:::START")
        print("STATUS:::Reading the TCF file:::START")
        MyLog.Append("[TCF_FileReader][INFO]:::Storing the tcf file in the current directory :::START")
        print("[TCF_FileReader][INFO]:::Storing the tcf file in the current directory :::START")
        with open(tcfFile) as f:
            with open(param.TCF_File_Path, "w") as f1:
                for line in f:
                    f1.write(line)
        
        #result=shutil.copyfile(param.ADTF_Log_Path, tcfFile)
        #print result
        testCaseInfo_pattern = r'TestCase.*Info.([ A-Za-z0-9_]+)\s*=\s*\"(.+)\"'
        testCaseInfo_re = re.compile(testCaseInfo_pattern)
        try:                    
            file=open(tcfFile,'r')
            lines = file.readlines()
            file.close()   
        except Exception as reason:
            MyLog.AppendException("[TCF_FileReader][STATUS]::: Opening TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
            MyLog.AppendException(reason)
            print("STATUS::: Opening TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
            print(reason) 
            sys.exit(1)
        
        for line in lines :
            match = testCaseInfo_re.match(line)
            if match:
                TestCaseInfo[(match.group(1)).strip()] = (match.group(2)).strip()
                MyLog.Append("[TCF_FileReader][Info]:::{0} = {1}".format(match.group(1),match.group(2))) 
                print("Info:::{0} = {1}".format(match.group(1),match.group(2))) 
    
        MyLog.Append("[TCF_FileReader][STATUS]:::Reading the TCF file:::SUCCESSFUL")
        print(TestCaseInfo)
        print("STATUS:::Reading the TCF file:::SUCCESSFUL")
        
    except Exception as reason:
        MyLog.AppendException("[TCF_FileReader][STATUS]::: Reading TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
        MyLog.AppendException(reason)
        print("STATUS::: Reading TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
        print(reason) 
        sys.exit(1)
        
        
#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_2: Extract_Software_Version_TCF_Get 
#Function Description:
#Get the softwate version from Test_Iteration received from TCF file and from global dictionary TestCaseInfo
#INPUT PARAMETERS:
#           1) None
#
# OUTPUT PARAMETERS:
#           1) Dictionary : TC_Software_Version
#**********************************************************************************************************

def Extract_Software_Version_TCF_Get():
    TC_Software_Version="None"
    #Fetch the software version from test iteration received from TCF file
    #print("TestCaseInfo['Test_Iteration']",TestCaseInfo['Test_Iteration'])
    #print("param.TCF_Iteration_regex",param.TCF_Iteration_regex)
    
    match=re.search(param.TCF_Iteration_regex, TestCaseInfo['Test_Iteration'])
    if match:
        #print("Matched",match.group(1))
        TC_Software_Version= match.group(1).strip()
    MyLog.Append("[Extract_Software_Version_TCF][STATUS]:::Extracted sofware version from TCF file is :::{0} :::SUCCESS \n".format(TC_Software_Version))
    print("[Extract_Software_Version_TCF][STATUS]:::Extracted sofware version from TCF file is :::{0} :::SUCCESS \n".format(TC_Software_Version))
    return TC_Software_Version



#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_2: checkIfProcessRunning 
#Function Description:
#Check if process is running in the task manger and return the status
#INPUT PARAMETERS:
#           1) processName
#
# OUTPUT PARAMETERS:
#           1) True or False based on the application status in task manager
#**********************************************************************************************************

def checkIfProcessRunning(processName):
    '''
    Check if there is any running process that contains the given name processName.
    '''
    #Iterate over the all the running process
    for proc in psutil.process_iter():
        try:
            # Check if process name contains the given name string.
            if processName.lower() in proc.name().lower():
                return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return False;




#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_2: Software_Flashing_Check 
#Function Description:
#Receive the Test Case software version
#Get the DUT software Version
#Compare the software version received from testcase versus DUT version 
#Continue flashing if mismatch
#If Match found continue Test_Triger function
#INPUT PARAMETERS:
#           1)Version_Number #Test_Case Version Number
#
# OUTPUT PARAMETERS:
#           1) None
#**********************************************************************************************************

def Software_Flashing_Check(SW_Version_TC,BIN_File_Path):
    try:
        #MyLog.Append("Software_Flashing_Check:::START \n")
        #Compare the DUT version and Received version from TC , 
        DUT_SW_version_Number=Software_Flashing_Get()
        #MyLog.Append("DUT Software Version is :::"+DUT_SW_version_Number+"\n")
        MyLog.Append("[SW_DOWNLOAD][INFO]Software Version received from TestCase is :::"+SW_Version_TC+"\n")
        print("Software Version received from TestCase is :::{0} \n".format(SW_Version_TC))
       
        #if version mismatch flash the software otherwise continue without flashing
        if DUT_SW_version_Number=="SW_Flashed_Success":
            MyLog.Append("[SW_DOWNLOAD][STATUS]:::Software Version in the DUT is Matched with TC:::SUCCESS\n")
            MyLog.Append("[SW_DOWNLOAD][INFO]:::Test will be continued without Flashing of the software")
            print("STATUS:::Software Version in the DUT is Matched with TC ::: SUCCESS \n")
            print("STATUS:::Skipping SW Flashing as the required SW is already Flashed......\n")
        else:
            MyLog.Append("[SW_DOWNLOAD][STATUS]:::Software Version in the DUT is not Matched with TC ::: MISMATCH \n")
            print("STATUS:::Software Version in the DUT is not Matched with TC ::: MISMATCH \n")
            MyLog.Append("[SW_DOWNLOAD][INFO]:::Flashing of the TC's software will start and version is :: {0}".format(SW_Version_TC))
            #Start Flashing the Software in case of mismatch
            Software_Flashing_Set(SW_Version_TC,BIN_File_Path)
            print("Passes 1----------------------")
            print("INFO:::Waiting for 15min to synchronise flashing and test trigger:::Please wait")
            time.sleep(param.download_sync_time)
            print("Passes 2----------------------")
        MyLog.Append("Software_Flashing_Check:::END \n")
        sys.exit(0)
    except Exception as reason:
        MyLog.AppendException("[SW_DOWNLOAD][STATUS]::: Software_Flashing_Check in the function ::: EXCEPTION:::ERROR[2] /n")
        MyLog.AppendException(reason)
        print("STATUS:::Software_Flashing_Check in the function::: EXCEPTION:::ERROR[2]")
        print(reason) 
        sys.exit(1)
    finally:
            return  "SUCCESS"


def Extract_TSE_File_Name(TSE_File_Path,SW_Version_TC,Test_Plan,Plan_ID,Test_Iteration,Test_Environment,BIN_File_Path):
    #cwd = os.getcwd()
    #print ("cwd:",cwd)
    try:
        print("[Extract_TSE_File_Name][INFO]::: Writing into received.tcf file in the path {}".format(param.TSE_FileName_Path))
        MyLog.Append("[Extract_TSE_File_Name][INFO]::: Writing into received.tcf file in the path {}".format(param.TSE_FileName_Path))
        ##TCF_File_Name = TCF_File_Path.split('\\')[-1]
        ##print("TCF_File_Name:",TCF_File_Name)
        file = open(param.TSE_FileName_Path, "w")
        file.write("TSE_File_Path="+TSE_File_Path)
        file.write("\n")
        file.write("Test_Plan="+Test_Plan)
        file.write("\n")
        file.write("Test_Plan_ID="+Plan_ID)
        file.write("\n")
        file.write("Test_Iteration="+Test_Iteration)
        file.write("\n")
        file.write("Test_Environment="+Test_Environment)
        file.write("\n")
        file.write("SW_Version="+SW_Version_TC)
        file.write("\n")
        file.write("Binary_File="+BIN_File_Path)
        file.close
 

        
    except Exception as reason:
        MyLog.AppendException("[Extract_TCF_File_Name][STATUS]::: Extract_TCF_File_Name from tcf file path:::EXCEPTION:::ERROR[1]")
        MyLog.AppendException(reason)
        print("[Extract_TCF_File_Name][STATUS]::: Extract_TCF_File_Name from tcf file path :::EXCEPTION:::ERROR[1]")
        print(reason) 
        sys.exit(1)

    
    
    
    



#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_1: Supporting function for reading the TCF file through Command line  
# This function is to get the TCF file path as command line arguement 
# INPUT PARAMETERS:
#           1) None
#
# OUTPUT PARAMETERS:
#           1) None
#*********************************************************************************************************        
def parse_commandline():
    parser = argparse.ArgumentParser(description='This script shall start receiving the TSE file.')
    print(parser)    
    parser.add_argument('-t', '--testinput'
        ,type=str
        ,help='Try typing te -t option for TSE file'
        ,default = ''
        ,dest='testinput'
    )
    parser.add_argument('-p', '--binpath'
        ,type=str
        ,help='Try typing te -p option for bin path'
        ,default = ''
        ,dest='binpath'
    )
    parser.add_argument('-s', '--SWVersion'
        ,type=str
        ,help='Try typing te -s option for SW Version'
        ,default = ''
        ,dest='SWVersion'
    )
    parser.add_argument('-id', '--TestPlanID'
        ,type=str
        ,help='Try typing te -id option for Test Plan ID'
        ,default = ''
        ,dest='TestPlanID'
    )
    parser.add_argument('-i', '--TestIter'
        ,type=str
        ,help='Try typing te -i option for Test Iteration'
        ,default = ''
        ,dest='TestIter'
    )
    parser.add_argument('-e', '--TestEnv'
        ,type=str
        ,help='Try typing te -e option for Test Environment'
        ,default = ''
        ,dest='TestEnv'
    )
    args = parser.parse_args()
    print(args)
    return args

        
if __name__ == "__main__":
    try:
        print("-------------------------------------")
        print(sys.argv)
        print("-------------------------------------")
        ## Get the TCF file from RQM through command line arguments.
        
        # ##---> This is used only for JENKINS.
        # BIN_File_Path = sys.argv[7]
        # SW_Version_TC = sys.argv[6]
        # TSE_File_Path = sys.argv[1]
        # Test_Plan = sys.argv[2]
        # Plan_ID = sys.argv[3]
        # Test_Iteration = sys.argv[4]
        # Test_Environment = sys.argv[5]
        # ##--->
        
        # [0'CT_Framework/Test_Scheduler/Scripts/Software_Flashing.py', 
        # 1'D:\\Jenkins\\TestCaseServer\\Test_Environment\\Full_Test_XMLs\\JIZHI_Project\\761193_DCOM_tse.tse', 
        # 2'Child_Test_Plan::BL3.0RC01.1::Temp_Common_Test', 
        # 3'49445', 
        # 4'BL3.0RC04', 
        # 5'Canoe_Windows', 
        # 'BL3.0RC01.1', 
        # 'jizhimono_mc0_release.7z']
        
        # BIN_File_Path = 'jizhimono_mc0_release.7z'
        # SW_Version_TC = 'BL3.0RC01.1'
        # TSE_File_Path = 'None'
        # Plan_ID = '49445'
        # Test_Iteration = 'BL3.0RC01.1_jizhimono_mc0_release'
        # Test_Environment = 'TE3406'
        
        o_commandlineArguments = parse_commandline()
        ## Pass command line arguments to local variables...    
        TSE_File_Path = o_commandlineArguments.testinput
        ## Pass command line arguments to local variables...    
        BIN_File_Path = o_commandlineArguments.binpath
        SW_Version_TC = o_commandlineArguments.SWVersion
        Plan_ID = o_commandlineArguments.TestPlanID
        Test_Iteration = o_commandlineArguments.TestIter
        Test_Environment = o_commandlineArguments.TestEnv
        print("Received BIN_File_Path",BIN_File_Path)
        print("Received SW Version Number",SW_Version_TC)
        print("Received TSE File",TSE_File_Path)
        print("Received Test Plan",Test_Plan)
        print("Received Test Plan ID",Plan_ID)
        print("Received Test Iteration",Test_Iteration)
        print("Received Test Environment",Test_Environment)
        
        
        
        Extract_TSE_File_Name(TSE_File_Path,SW_Version_TC,Test_Plan,Plan_ID,Test_Iteration,Test_Environment,BIN_File_Path)
        Software_Flashing_Check(SW_Version_TC,BIN_File_Path)
        
    finally:
        if MyLog:
            del MyLog
        print("################################################ Software Flashing Execution Completed ###############################################")
                
'''
python D:\FAST_Framework\sfa_test_automation_video_platform\CT_Framework\Test_Scheduler\Scripts\Software_Flashing.py -t D:\t\j\ws\COEM_LUCX_TARGET_TEST_for_SIT@1\repo_cas311_mc0_release\cpj_ca\tools\restbus\CA_Restbus_Gen3\vs_ca_s311\vs_ta\Test_Demo_xml_tse.tse -p cas311_mc0_release.7z -s CA_S311_BL01_RC03 -id 12345 -i CA_S311_BL01_RC03_cas311_mc0_release -e TE3406
'''