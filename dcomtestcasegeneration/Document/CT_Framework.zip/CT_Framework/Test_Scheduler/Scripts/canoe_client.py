print("=================inside canoe_client================")
import win32com.client
from win32com.client import gencache
import canoe_event_handler
import pythoncom
import time
import os
import subprocess
import Log
import Parameter_List as param




#*************************************************************
#        OBJECT_INTIALIZATION
#
#*************************************************************
MyLog = Log.LOG(param.logpath+"\\"+'CT_Python_Wraper_Test_Trigger.txt')



class CANoeClient:
    """
    A COM client used to remote control CANoe. 
    """
    
    #print("------------ inside canoe_client----------------")
    MyLog.Append("[CANOE_CLIENT][STATUS]::: Inside CANOE_CLIENT:::CLASS")
    print("[CANOE_CLIENT][STATUS]::: Inside CANOE_CLIENT:::CLASS")
    
    def __init__(self):
        MyLog.Append("[CANOE_CLIENT][STATUS]::: Inside CANOE_CLIENT:::INIT")
        print("[CANOE_CLIENT][STATUS]::: Inside CANOE_CLIENT:::INIT")
        #print("------------canoe_client------ __init__----------")
        self.canoeModul = gencache.EnsureModule('{7F31DEB0-5BCC-11D3-8562-00105A3E017B}', 0x0, 1, 54)
        MyLog.Append("[CANOE_CLIENT][STATUS]::: Opening the default CANoe application:::START")
        print("[CANOE_CLIENT][STATUS]::: Opening the default CANoe application:::START")
        #print("Trying to open default CANoe application")
        try:
        
            self.CANoe =  win32com.client.gencache.EnsureDispatch("CANoe.Application")
            time.sleep(10)#Sometimes CANoe needs some time after it is ready to execute other com commands
            if self.CANoe == 1:
                MyLog.Append("[CANOE_CLIENT][STATUS]::: Opening the default CANoe application:::SUCCESSFUL")
                print("[CANOE_CLIENT][STATUS]::: Opening the default CANoe application:::SUCCESSFUL")
                #print("Default CANoe application has opened sucessfully")
            else:
                MyLog.Append("[CANOE_CLIENT][STATUS]::: Opening the default CANoe application:::NOT SUCCESSFUL")
                print("[CANOE_CLIENT][STATUS]::: Opening the default CANoe application:::NOT SUCCESSFUL")
                #print("Default CANoe application has not opened sucessfully")
        except Exception as reason: 
            
            print('< Launching Canoe application failed with exception and reason below')
            print(reason)
                

    def performTests(self, configurationFilePath, testUnitPaths, reportFolder, testPlans, variantValue, xcpConfigurationFilePath=None):
        print("------------inside canoe_client------ performTests----------")
        """
        Executes tests defined in testUnits(vtuexe files) in a given CANoe configuration and outputs the results as
        reports to a reportFolder. In addition a test plan can be used to run only tests that are part of the test
        plan. Returns if overall test result is "Passed" or not.        
        Example Call: performTests("C:\CHASSIS_1.cfg", ["diagnosis.vtuexe"], "C:\reports", None)
        """
        print("..................configurationFilePath................",configurationFilePath)
        print("..................testUnitPaths................",testUnitPaths)
        print("..................reportFolder................",reportFolder)
        print("..................testPlans................",testPlans)
        print("..................variantValue................",variantValue)
        print("..................xcpConfigurationFilePath................",xcpConfigurationFilePath)
        
        
        configurationFilePath = os.path.abspath(configurationFilePath)
        #configurationFilePath = os.getcwd() + "\\..\\..\\" + configurationFilePath
        self.openConfiguration(configurationFilePath)
        self.removeAllXCPDevices()
        if xcpConfigurationFilePath and xcpConfigurationFilePath != "NO XCP CONFIGURATION FILE REQUIRED":
            self.addXCPConfiguration(xcpConfigurationFilePath)
        #print(self.CANoe.UI.Write.Text)
        self.CANoe.UI.Write.Clear()
        testConfiguration = self.createTestConfigurationWithTestUnits("AutomatedTests", testUnitPaths)
        testConfiguration = self.canoeModul.ITestConfiguration3(testConfiguration)
        self.setVariantValue("AutomatedTests",reportFolder, value=variantValue)
        self.enableTestsPartOfTestPlans(testConfiguration, testPlans) 
        time.sleep(5)
        nrOfTests = len(testUnitPaths[0].split(" "))
        # for items in testUnitPaths:
            # if str(items).find("TestUnit_PTS_Activation_Deactivation.vtuexe") or str(items).find("TestUnit_Sound_warning.vtuexe") \
                # or str(items).find("TestUnit_MSP_Activation.vtuexe") or str(items).find("TestUnit_DAA_Activation_Deactivation.vtuexe") \
                    # or str(items).find("TestUnit_FDD.vtuexe"):
                    # self.startObstacleSim(configurationFilePath)
                    # break
        #time.sleep(5)
        self.startMeasurement(nrOfTests)
        self.ensurePowerOnOff(1) # 1-ON, 0-OFF
        time.sleep(1)
        self.ensureIgnitionOn()
        time.sleep(5)#wait 5 sec to inter CVPAM into normal NM opertaion mode 
        self.executeTestsInTestConfiguration(testConfiguration)
        self.stopMeasurement()
        testsSuccessful = self.checkTestResultPassed(testConfiguration)
        #print(self.CANoe.UI.Write.Text)
        self.ensurePowerOnOff(0) # 1-ON, 0-OFF
        self.closeWithoutSaving()
        time.sleep(10)
        return testsSuccessful
    
    def startObstacleSim(self, rbs_path):
        print("------------inside canoe_client------ startObstacleSim----------")
        print("Trying to open ObstacleSim")
        path_split = rbs_path.split(os.path.sep)
        new_path = rbs_path.replace(path_split[-1], "ObstacleSim\\MERGE\\ObstacleSim.exe")
        subprocess.Popen(new_path)
   
    def openConfiguration(self, configurationFilePath):
        print("------------inside canoe_client------ configurationFilePath----------")
        """
        Switches the loaded configuration in CANoe.
        """
        print("=================configurationFilePath:",configurationFilePath)
        print("Trying to open Project specific CANoe")
        self.CANoe.Open(configurationFilePath)
        """
        Check if the configuration file was opened successfully
        """
        checkConfigResult = self.CANoe.Configuration.OpenConfigurationResult.result
        
        # result == 0 (success)
        
        if checkConfigResult != 0:
            raise Exception("The configuration could not be opened due to an error")
        else:
            print("Project specific CANoe has been opened sucessfully")


    def removeAllXCPDevices(self):
        print("------------inside canoe_client------ removeAllXCPDevices----------")
        """
        Remove all xcp devices(ecus) from the loaded CANoe configuration
        """
        ecus = self.CANoe.Configuration.GeneralSetup.XCPSetup.ECUs   
        while ecus.Count > 0:
            ecus.Remove(1)
    
    def activateNode(self, node_name, value):
        print("------------inside canoe_client------ activateNode----------")
        """
        Activate given Network Node
        """
        if value !=1:
            print("Trying to Deactivated",node_name,"node")
        else:
            print("Trying to Activated",node_name,"node")
            
        if self.CANoe.Configuration.SimulationSetup.Nodes(node_name):
            TestNode = self.CANoe.Configuration.SimulationSetup.Nodes(node_name)
            try:
                TestNode.active = value 
            except:
                TestNode.Active = value
                print("Node",node_name,"Activated/Deactivated sucessfully")
                
        else:
            print("The node " + node_name + "does not exist!")
            return
        
        return

           
    def addXCPConfiguration(self, xcpConfigurationFilePath):
        print("------------inside canoe_client------ addXCPConfiguration----------")
    
        """
        Adds xcp configuration files to CANoe
        """
        xcpConfigurationFilePath = os.path.abspath(xcpConfigurationFilePath)
        self.CANoe.Configuration.GeneralSetup.XCPSetup.ECUs.AddConfiguration(xcpConfigurationFilePath)
        time.sleep(2)

      
    def closeWithoutSaving(self):
        print("------------inside canoe_client------ closeWithoutSaving----------")
        """
        Closes CANoe without saving the configuration.
        """
        print("Trying to close the CANoe application")
        self.CANoe.Configuration.Modified = False
        self.CANoe.Quit()
        print("CANoe application has been closed sucessfylly without saving")
        
    
        
    def startMeasurement(self, nrOfTests = 1):
        print("------------inside canoe_client------ startMeasurement----------")
        """
        Starts a measurement in CANoe.
        """
        
        measurement = self.CANoe.Measurement
        print("======---------=====measurement=====-------======",measurement)
        eventHandler = win32com.client.WithEvents(measurement, canoe_event_handler.MeasurementEventHandler)
        print("Trying to run/start CANoe")
        CheckStartStatus=measurement.Start()
        
        waitCycles = 0    
        maxWaitCycles = 1000 * nrOfTests
        while not eventHandler.measurementStarted and waitCycles < maxWaitCycles:
            waitCycles = waitCycles + 1
            time.sleep(0.1)
            pythoncom.PumpWaitingMessages()

        if waitCycles >= maxWaitCycles:
            raise Exception("The measurement start operation timed out")
        print("CANoe runed/started sucessfully")
        
    
    def stopMeasurement(self):
        print("------------inside canoe_client------ stopMeasurement----------")
        """
        Stops a measurement in CANoe.
        """
        print("Trying to stop CANoe execution")
        measurement = self.CANoe.Measurement
        eventHandler = win32com.client.WithEvents(measurement, canoe_event_handler.MeasurementEventHandler) 
        measurement.Stop()
        waitCycles = 0  
        maxWaitCycles = 1000        
        while not eventHandler.measurementStopped and waitCycles < maxWaitCycles:
            waitCycles = waitCycles + 1
            time.sleep(0.1)
            pythoncom.PumpWaitingMessages()
        
        if waitCycles >= maxWaitCycles:
            raise Exception("The measurement stop operation timed out")
        print("CANoe execution has been stop sucessfully")
            
    def createTestConfigurationWithTestUnits(self, testConfigName, testUnitPaths):
        print("------------inside canoe_client------ createTestConfigurationWithTestUnits----------")
        """
        Creates a new test configuration that will include test units passed. In addition it is
        possible to set a folder where are reports are stored.
        E.g. call: createTestConfigurationWithTestUnits("C:\CHASSIS_1.cfg", ["dignosis.vtuexe"], "C:\reports").
        """
        print("Trying to add test case in CANoe")
        testConfigurations = self.CANoe.Configuration.TestConfigurations
        testConfiguration = testConfigurations.Add()
        testConfiguration.Name = testConfigName
                
        testUnits = self.canoeModul.ITestUnits2(testConfiguration.TestUnits)
        testUnitPathsList = testUnitPaths[0].split(" ")
        
        for testUnitPath in testUnitPathsList:
            #ensure right interface there are some interfaces that dont have the add method
            print("Adding TestUnit_1: ", testUnitPath)
            print("Current path: ", os.getcwd())
            testUnitPath = os.path.abspath(testUnitPath)
            #testUnitPath = os.getcwd() + "\\..\\..\\" + testUnitPath
            print("Adding TestUnit_2: ", testUnitPath)
            testUnits.Add(testUnitPath)

        print("createTestConfigurationWithTestUnits return value",testConfiguration)
        
        return testConfiguration
   
    def setVariantValue(self, testConfigName, reportFolder, value='Low'):
        print("------------ inside canoe_client------ setVariantValue----------")
        """
        Sets the Variant of the TestUnit to the specified value.
        """
        flag = 0
        TestConfig = self.canoeModul.ITestConfiguration2(self.CANoe.Configuration.TestConfigurations(testConfigName))
        for TestUnit in self.CANoe.Configuration.TestConfigurations(testConfigName).TestUnits:
            TestUnit = self.canoeModul.ITestUnit2(TestUnit)
            print("Variant:-",value)
            TestUnit.SetVariant("System_Variant", value)
            #Once, set the name of the generated report file
            if flag == 0:
                fileName = TestUnit.Name + '_' + '{MeasurementStart}' + '.xml'
                report = self.canoeModul.ITestConfigurationReport3(self.CANoe.Configuration.TestConfigurations(testConfigName).Report)
                report.FullPath = os.path.join(reportFolder, fileName)
                flag = 1
        TestConfig.ApplyVariants()
        
    
    def enableTestsPartOfTestPlans(self, testConfigurationOrChild, testPlans):    
        print("------------inside canoe_client------ enableTestsPartOfTestPlans----------")    
        """
        Enables  the tests of a test configuration that are part of the test plans
        passed. All other will be disabled.
        """
        
        for child in testConfigurationOrChild.Elements:
            self.enableTestsPartOfTestPlans(child, testPlans)
        
        #4 = cTestSequence, 5=cTestCase
        if testConfigurationOrChild.Type in range(4,6):       
            if self.isTestPartOfTestPlans(testConfigurationOrChild, testPlans):
                testConfigurationOrChild.Enabled = True
            else:
                testConfigurationOrChild.Enabled = False
    
    
    def ensureIgnitionOn(self):
        print("------------inside canoe_client------ ensureIgnitionOn----------")
        """
        Ensures that the variable that models the Klemme15 is set to True.
        """
        self.setVariableToValue("Ignition", "Sys_Ignition_Status", 4)
        print("CmdIgnSts is set to RUN")
        
    def ensurePowerOnOff(self, value):
        print("------------inside canoe_client------ ensureIgnitionOn----------")
        """
        Ensures that the variable that models the Klemme15 is set to True.
        """
        self.setEnvVariableToValue("voltage_EA_Toellner", "voltage_output_btn", value)
        time.sleep(1)
        self.setEnvVariableToValue("voltage_EA_Toellner", "voltage_input", 12.5)
        time.sleep(1)
        self.setEnvVariableToValue("voltage_EA_Toellner", "voltage_cutoff", value)
    
    # def ensurePSMDriveSlowly(self):
        # print("------------inside canoe_client------ ensurePSMDriveSlowly----------")
        # """
        # This is a temporary solution to test PMA...it shall be removed once the PSM Node drive (Ticket#23179) is updated
        # Ensures that the variable that models the drive slowly  is set to True after measurement start.
        # """
        # DriveSlowly = self.CANoe.Environment.GetVariable("xpg_DriveSlowly")
        # DriveSlowly.Value = 1
        
    
    def setVariableToValue(self, namespace, name, value):
        print("------------inside canoe_client------ setVariableToValue----------")
        """
        Sets the value of a system or environment variable
        Example Call: setVariableToValue("IL", "Klemme15", 1).
        """
        nameSpaces = self.CANoe.System.Namespaces
        for nameSpace in nameSpaces:
            if nameSpace.Name == namespace:
                variables = nameSpace.Variables
                for variable in variables:
                    if variable.Name == name:
                        variable.Value = value
                        return

    def setEnvVariableToValue(self, namespace, name, value):
        """
        Sets the value of a system or environment variable
        Example Call: setVariableToValue("IL", "Klemme15", 1).
        """
        print("Setting {} to {}".format(name,value))
        EnvVariable = self.CANoe.Environment.GetVariable(name)
        EnvVariable.Value = value

        return
                        
    def executeTestsInTestConfiguration(self, testConfiguration):
        print("------------inside canoe_client------ executeTestsInTestConfiguration----------")
        """
        Executes all enabled tests in a test configuration.
        """
        
        eventHandler = win32com.client.WithEvents(testConfiguration, canoe_event_handler.TestConfigurationEventHandler)
        
        testConfiguration.Start()
        
        waitCycles = 0
        maxWaitCycles = 1000  
        while not eventHandler.testConfigStarted and waitCycles < maxWaitCycles:
            waitCycles = waitCycles + 1
            time.sleep(0.1)
            pythoncom.PumpWaitingMessages() 

        if waitCycles >= maxWaitCycles:
            raise Exception("The test configuration start operation timed out")  
        print("Test configurations started running...")
        waitCycles = 0
        maxWaitCycles = 172800
        self.CANoe.UI.Write.Clear()
        while testConfiguration.Running and waitCycles < maxWaitCycles:
            if (len(self.CANoe.UI.Write.Text) > 3):
                #print(self.CANoe.UI.Write.Text)
                self.CANoe.UI.Write.Clear()
            waitCycles = waitCycles + 1
            time.sleep(1)
            pythoncom.PumpWaitingMessages() 
      
        if waitCycles >= maxWaitCycles:
            raise Exception("The test configuration run timed out") 
        print("Test configurations finished running.")
    def isTestPartOfTestPlans(self, test, testPlans):
        print("------------inside canoe_client------ isTestPartOfTestPlans----------")
        if len(testPlans) == 0:
            return True
        
        # enforce usage of new TestTreeElement interface where Id
        # is defined
        test = self.canoeModul.ITestTreeElement2(test)
            
        for testPlan in testPlans:
            for testCase in testPlan['testcases']:
                if ('RQM_' + testCase['id'] + '_') in test.Caption:
                    return True
                
                if ('vteststudioid' in testCase and testCase['vteststudioid'] == test.Id):
                    return True
                
        return False
    
    def checkTestResultPassed(self, testConfiguration):
        print("------------inside canoe_client------ checkTestResultPassed----------")
        """
        Gets the overall test result of given test configuration and checks if it is passed.
        """
        
        result = testConfiguration.Verdict
        
        # check if verdict == cVerdictPassed
        return result == 1
    
            
        
    
