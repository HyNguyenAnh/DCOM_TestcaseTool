# -----------------------------------------------------------------------------
# Example: Test Feature Set via Python
# 
# This sample demonstrates how to start the test modules and test 
# configurations via COM API using a Python script.
# The script uses the included PythonBasicEmpty.cfg configuration but is  
# working also with any other CANoe configuration containing test modules  
# and test configurations. 
# 
# Limitations:
#  - only the first test environment is supported. If the configuration 
#    contains more than one test environment, the other test environments 
#    are ignored
#  - the script does not wait for test reports to be finished. If the test
#    reports are enabled, they may run in the background after the test is 
#    finished
# -----------------------------------------------------------------------------
# Copyright (c) 2017 by Vector Informatik GmbH.  All rights reserved.
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# @hgs6kor : Adapted for PJIF Project. Runs from the Windows Command line.
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
# @hgs6kor : made as module to include in test file 
#
# -----------------------------------------------------------------------------

import time, os
from win32com.client import *
from win32com.client.connect import *
import sys
import subprocess
import argparse
import shutil
import pywin

SCRIPT_DIR = os.path.dirname(os.path.realpath(__file__))

def EndTask():
    # check if Canoe 32 bit is running
    command= 'tasklist /fi "imagename eq CANoe32.exe"|find "=" > nul'
    ret = subprocess.call(command, shell=True, cwd=SCRIPT_DIR, stdout=sys.stdout, stderr=sys.stderr)
    if ret == 0:
        pass
    # kill currently running 32 bit Canoe
    command= 'taskkill /f /im "CANoe64.exe"'
    ret = subprocess.call(command, shell=True, cwd=SCRIPT_DIR, stdout=sys.stdout, stderr=sys.stderr)
    if ret != 0:
        raise Exception("[E] Killng 64bit CANoe failed with exit code '{}'".format(ret))
	
    # check if Canoe 64 bit is running
    command= 'tasklist /fi "imagename eq CANoe64.exe"|find "=" > nul'
    ret = subprocess.call(command, shell=True, cwd=SCRIPT_DIR, stdout=sys.stdout, stderr=sys.stderr)
    if ret == 0:
        pass
    # kill currently running 64 bit Canoe
    command= 'taskkill /f /im "CANoe64.exe"'
    ret = subprocess.call(command, shell=True, cwd=SCRIPT_DIR, stdout=sys.stdout, stderr=sys.stderr)
    if ret != 0:
        raise Exception("[E] Killng 64bit CANoe failed with exit code '{}'".format(ret))

def DoEvents():
    pythoncom.PumpWaitingMessages()
    time.sleep(.1)
def DoEventsUntil(cond):
    while not cond():
        DoEvents()

class CanoeSync(object):
    """Wrapper class for CANoe Application object"""
    print("Entered Canoe")
    Started = False
    Stopped = False
    ConfigPath = ""
    def __init__(self):
        app = DispatchEx('CANoe.Application')
        app.Visible = 1
        app.Configuration.Modified = False
        self.App = app
        print("\n" + self.App.Name)
        print(self.App.Version , "\n")
        self.Measurement = app.Measurement   
        self.Running = lambda : self.Measurement.Running
        self.WaitForStart = lambda: DoEventsUntil(lambda: CanoeSync.Started)
        self.WaitForStop = lambda: DoEventsUntil(lambda: CanoeSync.Stopped)
        WithEvents(self.App.Measurement, CanoeMeasurementEvents)

    def Load(self, cfgPath):
        try:
            # current dir must point to the script file
            cfg = os.path.join(os.curdir, cfgPath)
            cfg = os.path.abspath(cfg)
            self.ConfigPath = os.path.dirname(cfg)
            self.Configuration = self.App.Configuration
            self.App.Open(cfg)
            print('< Opening: ', cfg ,' >')
        except :
            print("< Cannot Open " , cfg ,".Either Configuration does not exist in given path or CANoe instance could not be created >")
            #Kill CANoe instance after tests 
            EndTask()
            sys.exit(1)

    def LoadTestSetup(self, testsetup):
        self.TestSetup = self.App.Configuration.TestSetup
        path = os.path.join(self.ConfigPath, testsetup)
        testenv = self.TestSetup.TestEnvironments.Add(path)
        testenv = CastTo(testenv, "ITestEnvironment2")
        #TestModules property to access the test modules
        self.TestModules = []
        self.TraverseTestItem(testenv, lambda tm: self.TestModules.append(CanoeTestModule(tm)))

    
    def LoadTestConfiguration(self, testcfgname, testunits):
        """ Adds a test configuration and initialize it with a list of existing test units """
        tc = self.App.Configuration.TestConfigurations.Add()
        tc.Name = testcfgname
        tus = CastTo(tc.TestUnits, "ITestUnits2")
        for tu in testunits:
            tus.Add(tu)
        # TestConfigs property to access the test configuration
        self.TestConfigs = [CanoeTestConfiguration(tc)]

    def Start(self, timeout): 
        if not self.Running():
            try:
                self.Measurement.Start()
            except :
                print("< Error starting measurement! >")
                EndTask()
                sys.exit(1)
            print("< Waiting for measurement to start... >")
            
            # wait until measurement started but max [timeout]sec
            timeElapsed = 0.0
            while not self.Started:
                DoEvents()
                timeElapsed += 0.1
                if timeElapsed > timeout:
                    print("< Could not start measurement in ", timeout, "sec! >")
                    print("< Error starting measurement! Observe canoe Write window for liscences issues or compilation errors etc.. >")
                    time.sleep(5)
                    #Kill CANoe instance after tests 
                    EndTask()
                    sys.exit(1)

    def Stop(self):
        if self.Running():            
            self.Measurement.Stop()
            self.WaitForStop()
       

##    def RunTestModules(self):
##        """ starts all test modules and waits for all of them to finish"""
##        # start all test modules
##        for tm in self.TestModules:
##            tm.Start()
##    
##        # wait for test modules to stop
##        while not all([not tm.Enabled or tm.IsDone() for tm in app.TestModules]):
##            DoEvents()

    # Run all tests which is added
    def RunTestModules(self):
        if len(self.TestModules) == 0:
            print("[", sys.argv[0], "] RunTests(): There is no test added.")
            return
        
        for tm in self.TestModules:
            tm.Start()
            # wait for test modules to stop
            while (not tm.Events.started) and (not CanoeSync.Stopped):
                DoEvents();     
            while (not tm.Events.stopped) and (not CanoeSync.Stopped):
                DoEvents();
##            if tm.TestModules.Verdict == 0:
##                    #print "[", sys.argv[0], "] Test (", tm.Name, ") verdict: VerdictNotAvailable"
##                    print " Test [", tm.Name, "] verdict: VerdictNotAvailable"
##            if tm.TestModules.Verdict == 1:
##                    #print "[", sys.argv[0], "] Test (", tm.Name, ") verdict: PASSED"
##                    print " Test [", tm.Name, "] verdict: PASSED"
##            if tm.TestModules.Verdict == 2:
##                #print "[", sys.argv[0], "] Test (", tm.Name, ") verdict: FAILED"
##                print " Test [", tm.Name, "] verdict: FAILED"
   
# returns a list of the tetst verdicts.
# 0 -> VerdictNotAvailable
# 1 -> TestPassed
# 2 -> TestFailed


##    def RunTestConfigs(self):
##        """ starts all test configurations and waits for all of them to finish"""
##        # start all test configurations
##        for tc in self.TestConfigs:
##            tc.Start()
##    
##        # wait for test modules to stop
##        while not all([not tc.Enabled or tc.IsDone() for tc in app.TestConfigs]):
##            DoEvents()

    def RunTestConfigs(self):
        """ starts all test configurations and waits for all of them to finish"""
        # start all test configurations
        for tc in self.TestConfigs:
            tc.TestConfig.Start()
    
        # wait for test modules to stop
        while not all([not tc.Enabled or tc.IsDone() for tc in self.TestConfigs]):
            DoEvents()

        if tc.TestConfig.Verdict == 0:
            print("<",tc.Name," verdict: VerdictNotAvailable >")
        if tc.TestConfig.Verdict == 1:
            print("<",tc.Name," verdict: PASSED >")
        if tc.TestConfig.Verdict == 2:
            print("<",tc.Name," verdict: FAILED > ")
    
   
    # Test verdicts.
    # 0 -> VerdictNotAvailable
    # 1 -> TestPassed
    # 2 -> TestFailed
    def TestVerdicts(self):
        if len(self.TestConfigs) == 0:
            print("< There is no test added >")
            return
        else:
            return [tm.TestConfig.Verdict for tm in self.TestConfigs ]

    def TraverseTestItem(self, parent, testf):
        for test in parent.TestModules: 
            testf(test)
        for folder in parent.Folders: 
            found = self.TraverseTestItem(folder, testf)

class CanoeMeasurementEvents(object):
    """Handler for CANoe measurement events"""
    def OnStart(self): 
        CanoeSync.Started = True
        CanoeSync.Stopped = False
        print("< measurement started >")
    def OnStop(self) : 
        CanoeSync.Started = False
        CanoeSync.Stopped = True
        print("< measurement stopped >")

class CanoeTestModule:
    """Wrapper class for CANoe TestModule object"""
    def __init__(self, tm):
        self.tm = tm
        self.Events = DispatchWithEvents(tm, CanoeTestEvents)
        self.Name = tm.Name
        self.IsDone = lambda: self.Events.stopped
        self.Enabled = tm.Enabled
    def Start(self):
        if self.tm.Enabled:
            self.tm.Start()
            self.Events.WaitForStart()

class CanoeTestConfiguration:
    """Wrapper class for a CANoe Test Configuration object"""
    def __init__(self, tc):        
        self.tc = tc
        self.Name = tc.Name
        self.Events = DispatchWithEvents(tc, CanoeTestEvents)
        self.IsDone = lambda: self.Events.stopped
        self.Enabled = tc.Enabled
    def Start(self):
        if self.tc.Enabled:
            self.tc.Start()
            self.Events.WaitForStart()

class CanoeTestEvents:
    """Utility class to handle the test events"""
    def __init__(self):
        self.started = False
        self.stopped = False
        self.WaitForStart = lambda: DoEventsUntil(lambda: self.started)
        self.WaitForStop = lambda: DoEventsUntil(lambda: self.stopped)
    def OnStart(self):
        self.started = True
        self.stopped = False        
        print("\t<", self.Name, " started >") 
    def OnStop(self, reason):
        self.started = False
        self.stopped = True 
        print("\t<", self.Name, " stopped >") 


