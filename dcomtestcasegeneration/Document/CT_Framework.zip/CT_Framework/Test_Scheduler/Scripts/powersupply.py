# -*- coding: iso-8859-15 -*-
#=============================================================================
#  C O P Y R I G H T
#-----------------------------------------------------------------------------
#  Copyright (c) 2008 by Robert Bosch GmbH. All rights reserved.
#
#  This file is property of Robert Bosch GmbH. Any unauthorised copy, use or 
#  distribution is an offensive act against international law and may be 
#  prosecuted under federal law. Its content is company confidential.
#=============================================================================
#  D E S C R I P T I O N
#-----------------------------------------------------------------------------
#       Projectname: 
#          Synopsis: Using Agilent Powersupply
#  Target system(s): win32, win64,
#       Compiler(s): python 2.7.2
#=============================================================================
#  N O T E S
#-----------------------------------------------------------------------------
#  Notes: 
#=============================================================================
#  I N I T I A L   A U T H O R   I D E N T I T Y
#-----------------------------------------------------------------------------
#        Name: wih7lr
#  Department: CC-DA/EPV2
#=============================================================================
#  R E V I S I O N   I N F O R M A T I O N
#-----------------------------------------------------------------------------
## @file copyJenkins.py
## @par Revision History:
##     $Source: getvolt.py $
##     $Revision: 1.0 $
##     $Author: Hardy Windhager (CC-DA/EPV2) (WIH7LR) $
##     $Date: 2014/06/28 13:59:39MEZ $
##     $Locker:  $
##     $Name:  $
##     $State: in_work $
##
## @par Review Information:
## - Reviewed version: 
## - Type (use 'X' to mark):
##     - [ ] Formal Review
##     - [ ] Walkthrough
##     - [ ] Inspection
## - State including date (DD.MM.YYYY)
##     - [--.--.----] Preparation
##     - [--.--.----] Review audit
##     - [--.--.----] Integration of findings
##     - [--.--.----] Test
##     - [--.--.----] Verification of integration of findings
##     - [--.--.----] Review release
## - Responsible:
## - Review-Document:
#=============================================================================

import sys
import socket
import argparse
import time


# Default parameters
TCP_PORT = 5025
RECV_BUFFER_SIZE = 1024
DEBUG = False


# Control messages
MESSAGE_ON = "OUTP ON,(@%d) \n"
MESSAGE_OFF = "OUTP OFF,(@%d) \n"
MESSAGE_VOLT_ON = "VOLT 12.0,(@%d) \n"
MESSAGE_VOLT_ON_T32 = "VOLT 8.0,(@%d) \n"
MESSAGE_VOLT_OFF = "VOLT 0.0,(@%d) \n"
MESSAGE_CURR = "CURR 2.0,(@%d) \n"
MESSAGE_MEAS_VOLT = "MEAS:VOLT? (@%d) \n"
MESSAGE_MEAS_CURR = "MEAS:CURR? (@%d) \n"


## Parse the command line arguments...
def parse_commandline():
    parser = argparse.ArgumentParser(description='This script shall start the Agilent engine for every port.')

    parser.add_argument(
        '-i', '--ipaddress',
        type=str,
        help='Insert the ip adress.',
        default = '',
        dest='ipaddress'
    )
    
    parser.add_argument(
        '-p', '--port',
        type=str,
        help='Insert the portnumber to set current and voltage.',
        default = '',
        dest='portnumber'
    )
    
    parser.add_argument(
        '-a', '--action',
        type=str,
        help='Try between the following actions: start, stop or status',
        default = '',
        dest='action'
    )

    parser.add_argument(
        '-o', '--outputfile',
        type=str,
        help='Status is written to file',
        default = '',
        dest='outputfile'
    )

    args = parser.parse_args()
    return args

## This function opens socket port to agilent powersupply an will also close it.
#  This function will be used by other functions(status_powersupply, start_powersupply
#  stop_powersupply). Port opening --> sending message --> (waiting for answer)--> close
#  connection
def sendMessage(s_ipaddress, s_message, b_waitForResponse):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((s_ipaddress, TCP_PORT))
    try:
        s.send(s_message)
    except socket.error:
        print 'Can not send message'
        sys.exit(-1)
    if (DEBUG):
        print 'Message "' + s_message.strip() + '" sent successfully'

    s_response = ""
    
    if (b_waitForResponse):
        s_response = s.recv(RECV_BUFFER_SIZE)
        
    s.close()
    
    return s_response


##  Function measure voltage and current.
def status_powersupply(s_ipaddress, i_port,fileWrite=''):
    localtime = time.asctime( time.localtime(time.time()) )
    print "Local current time :", localtime
    print "Checking voltage and current on port %s" % i_port
    voltage = sendMessage(s_ipaddress, MESSAGE_MEAS_VOLT % i_port, True)
    print "received voltage: %.2f V" % float(voltage)  

    current = sendMessage(s_ipaddress, MESSAGE_MEAS_CURR % i_port, True)
    print "received current: %.2f A" % float(current)

    power = float(voltage) * float(current)
    print "Power consumed: %.2f W" % float(power)
    if (fileWrite):
        txtFile = open(fileWrite, 'w+')
        txtFile.write("Voltage measured: %.2f V\n" % float(voltage))
        txtFile.write("Current measured: %.2f A\n" % float(current))
        txtFile.write("Power consumed: %.2f W" % float(power))
        txtFile.close


 ## Turn chosen port on and switch voltage to 12 volts, also maximum current 
 #  will be set on 2 Ampere. 
 #  Calling function status_powersupply to measure voltage and current.
def start_powersupply(s_ipaddress, i_port,set_volt=MESSAGE_VOLT_ON):
    
    print "Setting voltage and current on port %s" % i_port
    sendMessage(s_ipaddress, MESSAGE_ON % i_port, False)
    sendMessage(s_ipaddress, set_volt % i_port, False)
    sendMessage(s_ipaddress, MESSAGE_CURR % i_port, False)
    time.sleep(1)
    status_powersupply(s_ipaddress, i_port)


## Function switch voltage to zero volts an turn chosen port off.
#  Calling function status_powersupply to measure voltage and current.
def stop_powersupply(s_ipaddress, i_port):
    print "Before switching off..."
    status_powersupply(s_ipaddress, i_port)
    print "Switching off port %s" % i_port
    sendMessage(s_ipaddress, MESSAGE_OFF % i_port, False)
    sendMessage(s_ipaddress, MESSAGE_VOLT_OFF % i_port, False)
    time.sleep(1)
    status_powersupply(s_ipaddress, i_port)


if '__main__' == __name__:

    ## Get command line arguments.
    o_commandlineArguments = parse_commandline()
    
    ## Pass command line arguments to local variables...
    i_port = int(o_commandlineArguments.portnumber)
    s_action = o_commandlineArguments.action
    s_ipaddress = o_commandlineArguments.ipaddress
    o_outputFile = o_commandlineArguments.outputfile
    
    ## check selected action and go to correct function
    if s_action == 'start':
        start_powersupply(s_ipaddress, i_port)
    if s_action == 'start_T32':
        start_powersupply(s_ipaddress, i_port, MESSAGE_VOLT_ON_T32)
    elif s_action == 'stop':
        stop_powersupply(s_ipaddress, i_port)
    elif s_action == 'restart':
        stop_powersupply(s_ipaddress, i_port)
        start_powersupply(s_ipaddress, i_port)
    elif s_action == 'restart_T32':
        stop_powersupply(s_ipaddress, i_port)
        start_powersupply(s_ipaddress, i_port,MESSAGE_VOLT_ON_T32)
    elif s_action == 'status':
        status_powersupply(s_ipaddress, i_port, o_outputFile)    
    else:
        print 'Please insert an action.'


#=============================================================================
#  R E V I S I O N   H I S T O R Y
#-----------------------------------------------------------------------------
#  $Log: getvolt.py  $
#=============================================================================
