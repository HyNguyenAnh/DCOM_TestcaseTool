
#=============================================================================
#  C O P Y R I G H T
#-----------------------------------------------------------------------------
#  Copyright (c) 2019 by Robert Bosch Engineering and Buisiness Limited. All rights reserved.
#
#  This file is property of Robert Bosch Engineering and Buisiness India Limited. Any unauthorised copy, use or 
#  distribution is an offensive act against international law and may be 
#  prosecuted under federal law. Its content is company confidential.
#=============================================================================
#  D E S C R I P T I O N
#-----------------------------------------------------------------------------
#       Projectname: 
#          Synopsis: Regression Test - Python Application Wraper for ATV 
#  Target system(s): win32
#       Compiler(s): python 2.7.16
#===============================================================================================
#  N O T E S
#-----------------------------------------------------------------------------------------------
#  Notes: 
#================================================================================================
#  I N I T I A L   A U T H O R   I D E N T I T Y
#------------------------------------------------------------------------------------------------
#  Name:Sudarshan (RBEI/ESD-PP52), Sunny Kumar (RBEI/ESD-PP52) and Govindaraju T (RBEI/ESD-PP)
#  Department: RBEI/ESD - PP
#================================================================================================
#  R E V I S I O N   I N F O R M A T I O N
#------------------------------------------------------------------------------------------------
## 
## - Reviewed version: 
## - Type (use 'X' to mark):
##     - [ ] Formal Review
##     - [ ] Walkthrough
##     - [ ] Inspection
## - State including date (DD.MM.YYYY)
##     - [--.--.----] Preparation
##     - [--.--.----] Review audit
##     - [--.--.----] Integration of findings
##     - [--.--.----] Test
##     - [--.--.----] Verification of integration of findings
##     - [--.--.----] Review release
## - Responsible:
## - Review-Document:
#=============================================================================
# -----------------------------------------------------------------------------
# Run from Windows command line :  >> python Test_Triger.py 
#
# ----------------------------------------------------------------------------- 

import sys, time, os 
import subprocess
import Log
import shutil
import re
import pyrocopy as robocopy
import Parameter_List as param
import psutil
import pywin
#from run_tests import *
from RunCanoeTestsViaTestModules import *
from Extract_CTC_Release import *
import pickle
from zipfile import ZipFile

#*************************************************************
#        OBJECT_INTIALIZATION
#
#*************************************************************
MyLog = Log.LOG(param.logpath+"\\"+'CT_Python_Wraper_Test_Trigger.txt')


#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_1: Read TCF file 
# Function name will read TCF file received from Jenkins 
# INPUT PARAMETERS:
#           1) string: TSE File
#
# OUTPUT PARAMETERS:
#           1) Dictionary : Test Case Info
#*********************************************************************************************************
       
def TCF_FileReader_Set(tseFile):
    try:
        global TestCaseInfo # +++
        global nowTime
        TestCaseInfo = [] # +++
        nowTime = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime())
        
        MyLog.Append("[TSE_FileReader][STATUS]:::Reading the TSE file:::START")
        print("STATUS:::Reading the TSE file:::START")
        #testCaseInfo_pattern = r'TestCase.*Info.([ A-Za-z0-9_]+)\s*=\s*\"(.+)\"'
        #testCaseInfo_re = re.compile(testCaseInfo_pattern)
        try:                    
            file=open(tseFile,'r')
            lines = file.readlines()
            file.close()   
        except Exception as reason:
            MyLog.AppendException("[TSE_FileReader][STATUS]::: Opening TSE_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
            MyLog.AppendException(reason)
            print("STATUS::: Opening TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
            print(reason) 
            sys.exit(1)
        
        for line in lines :
            TestCaseInfo.append(line.split('\n')[0])
        print("Received Test Case Info is :")
        print(TestCaseInfo);


            
            #match = testCaseInfo_re.match(line)
            #if match:
             #   TestCaseInfo[(match.group(1)).strip()] = (match.group(2)).strip()
              #  MyLog.Append("[TSE_FileReader][Info]:::{0} = {1}".format(match.group(1),match.group(2))) 
                #print("Info:::{0} = {1}".format(match.group(1),match.group(2))) 
    
        MyLog.Append("[TSE_FileReader][STATUS]:::Reading the TCF file:::SUCCESSFUL")
        print("STATUS:::Reading the TCF file:::SUCCESSFUL")
        
    except Exception as reason:
        MyLog.AppendException("[TCF_FileReader][STATUS]::: Reading TSE_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
        MyLog.AppendException(reason)
        print("STATUS::: Reading TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
        print(reason) 
        sys.exit(1)

def Flash_mode():
   #Enter to Flash Mode
   try:
       print("Start::: Entering to Flash mode")
       
       '''
       #command='python {}\\Flashmode.py '.format(param.RelayPath)
       command='python {}\\Flash_Mode.py'.format(param.RelayPath)
       ret = subprocess.call(command, shell=True, cwd=param.RelayPath, stdout=sys.stdout, stderr=sys.stderr) 
       time.sleep(5)  
       '''
       
       #SCRIPT_DIR = r'C:\Users\sz28kor'
       SCRIPT_DIR = r'C:\Users\skc1kor'
       command= r'curl http://192.168.0.101:5000/api/1.0/sec?mode=uartflash'
       ret = subprocess.call(command, shell=True, cwd=SCRIPT_DIR, stdout=sys.stdout, stderr=sys.stderr)    
       time.sleep(5)
       
       
       power = r'D:\Jenkins\TestAutomation\CT_Framework\Test_Scheduler\Scripts'
       command = 'py -2 powersupply.py -i 10.165.89.169 -p 2 -a restart'
       ret = subprocess.call(command, shell=True, cwd=power, stdout=sys.stdout, stderr=sys.stderr)
  
   except Exception  as reason:
        print ("Exception::: While calling the Flash mode")
        print(reason)
        
def Normal_mode():
   #Enter to Normal Mode
   try:            
       # print ("Start::: Entering to Normal mode")
       
       '''
       command= 'python {}\\Normal_Mode.py'.format(param.RelayPath)
       ret = subprocess.call(command, shell=True, cwd=param.RelayPath, stdout=sys.stdout, stderr=sys.stderr) 
       time.sleep(5)                    
       '''
       
       #SCRIPT_DIR = r'C:\Users\sz28kor'
       SCRIPT_DIR = r'C:\Users\skc1kor'
       command= r'curl http://192.168.0.101:5000/api/1.0/sec?mode=uartboot'
       ret = subprocess.call(command, shell=True, cwd=SCRIPT_DIR, stdout=sys.stdout, stderr=sys.stderr)    
       time.sleep(5)
       
       power = r'D:\Jenkins\TestAutomation\CT_Framework\Test_Scheduler\Scripts'
       command = 'py -2 powersupply.py -i 10.165.89.169 -p 2 -a restart'
       ret = subprocess.call(command, shell=True, cwd=power, stdout=sys.stdout, stderr=sys.stderr)
          
       # print( ":::SUCCESS::: Enterted to Normal mode"   ) 
   except Exception  as reason:
        print ("Exception::: While calling the Normal mode")
        print(reason)

 
#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_4.0: Test_Preparation_Set() 
#Function Description:
#Function name will be Test_Preparation_Set()#It will execute the Test_Preparation_Set()
#This will copy the RBS and vtuexe from GIT to working directory of test_trigger
#**********************************************************************************************************
def _checkIfProcessRunning(processName):
    '''
    Check if there is any running process that contains the given name processName.
    '''
    #Iterate over the all the running process
    for proc in psutil.process_iter():
        try:
            # Check if process name contains the given name string.
            if processName.lower() in proc.name().lower():
                return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return False;

def Test_Preparation_Set():
   
    #Copy the RBS from GIT to Working directory
    try:
        if _checkIfProcessRunning('CANoe64'):
            print ("[TEST_TRIGGER][INFO]::: Canoe Instance is running already this will be killed and re-started")
            try :
                command= 'taskkill /f /im "CANoe64.exe"'
                os.system(command)
            except Exception as reason:
                print ("Exception in killing the Canoe Instance")
                print(reason)
                
        #Create a log based on build name and move to report folder for test case logs
        ##get_CTC_Release(TestCaseInfo['Test_Iteration'],MyLog)
        CTC_Release_Path = 'None'
        for line in TestCaseInfo:
            if 'SW_Version' in line:
                CTC_Release_Path = line.split('=')[1]
        file = open(param.Release_File_Path, "w")
        file.write(CTC_Release_Path)
        print("The received SW Version is :{}".format(CTC_Release_Path))

        #Extracting the TSE File Name and writing into Filename.txt for reporting purpose
        TSE_Name_Path = 'None'
        for line in TestCaseInfo:
            if 'TSE_File_Path' in line:
                TSE_Name_Path = line.split('\\')[-1]
        file = open(param.TSE_Name_Path, "w")
        file.write(TSE_Name_Path)
        print("The received TSE Name is :{}".format(TSE_Name_Path))
                
    
    except Exception as reason:
        MyLog.AppendException("[TEST_PREPARATION][STATUS]::: Test Trigger Exception :::EXCEPTION:::ERROR[5] /n")
        MyLog.AppendException("[TEST_PREPARATION][HINT1]::: Make sure you have updaterd Param file with correct GIT link and also in GIT all the files are uploaded correctly\n")        
        MyLog.AppendException(reason)
        print("[TEST_PREPARATION][STATUS]::: Test Case trigger :::EXCEPTION:::ERROR[5] /n")
        print(reason) 
        sys.exit(1) 
 
def _Move_CANoe_reports_Files_Set(src, dest):
    #print(src)
    #print(dest)
    print ("< Moving generated HTML report to the report directory > ")
    print("Report folder is {}".format(dest))
    #@todo : check for valid destination folder exists
    if not os.path.exists(dest):
        os.makedirs(dest)
    for files in os.listdir(src):
        if ( files.endswith("_report.html") or files.endswith("_report.xml")):
            shutil.move(os.path.join(src, files), os.path.join(dest, files))

    #Writing XML file path to received.tcf for RQM Updater
    with open(param.RQM_XML_PATH, "w") as f1:
        f1.write(dest)
    print ("[Copy_Report][Info]:::Find HTML report in path:{0} ".format(os.path.abspath(dest)))
    MyLog.Append ("[Copy_Report][Info]:::Find HTML report in path:{0} ".format(os.path.abspath(dest)))
    

#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_4: Test_Triger 
#Function Description:
#Function name will be Test_Triger_Set()
#It will execute the Test_Triger_Set()
#If it is a Canoe based test , then it will call RQM_Utility tool and update the results
#If it is a ADTF based test , then it will call RQM_Updater.py and will update the test results into RQM
#INPUT PARAMETERS:
#           1) string: NowTime
#
# OUTPUT PARAMETERS:
#           1) None
#
#**********************************************************************************************************

def Test_Triger_Set(nowTime):
    #global TestCaseInfo
    #global TestCase_ID
    #global Test_Case_Folder    
    #config = param.config
    
    #Test_Case_Details=Main_Testcase(config,TestCaseInfo['TestCase'],"scriptStepCount")            
    #TestCase_ID=Test_Case_Details[1]            
    #Total_Steps=int(Test_Case_Details[0])
    
    try:        
        #print("Entered---1")
        MyLog.Append("[TEST_TRIGGER][STATUS]::: TestTrigger for the test Environment name :::{}:::START".format(TestCaseInfo[0]))        
        print("[TEST_TRIGGER][STATUS]::: TestTrigger for the test Environment name:::{}:::START".format(TestCaseInfo[0]))
        #Test_log_folder_name 
        
        #Check if test case is Resbus , ADTF ..         
        CanoeTest = True
        MyLog.Append("[TEST_TRIGGER][INFO]::: Test Case is of type CANoe:::Triggering the test execution ")
        print ("[TEST_TRIGGER][INFO]::: Test Case is of type CANoe:::Triggering the test execution ")
        #print("Entered---2")
        '''  
        #Create a log based on build name and move to report folder for test case logs 
        if not os.path.exists(param.Canoe_log_path+"\\"+Test_Case_Folder):
            print("Creating report folder")
                os.makedirs(param.Canoe_log_path+"\\"+Test_Case_Folder)
        '''
        #Launch Canoe
        
        
        #create a new canoe instance
        app = CanoeSync()
        #print("Entered---3")
    
        # loads the CANoe configuration
        app.Load(param.RBS_PATH)

        try :
            #add test modules to the configuration
            #print pathToTestEnv
            for line in TestCaseInfo:
                if 'TSE_File_Path' in line:
                    pathToTestEnv = line.split('=')[1]
            print("Loading the Test Environment {}".format(pathToTestEnv))
            app.LoadTestSetup(pathToTestEnv)
        
        except:
            print('Test Environment not found. Check path ', os.path.dirname(pathToTestEnv) )
            EndTask()
    

        # start the measurement and wait for 10 Sec , if Not connected after 10 Sec re-animation starts
        app.Start(10)    
        
        # runs the test modules
        app.RunTestModules()

           
        # -----------------------------------------------------------------------------
        #                 END-CONDITION
        # -----------------------------------------------------------------------------
        
        # stop the measurement
        #time.sleep(10)
        app.Stop()
        
        #assumed that report generation takes time.
        time.sleep(20)
        
        ##move_reports(app.Configuration.Path ,args.report_dir)                #use this method if you want to move reports from root folder to a specific folder , pass the arguments as per your needs
        
        #Kill CANoe instance after tests 
        #EndTask()
        try :
            command= 'taskkill /f /im "CANoe64.exe"'
            os.system(command)
        except Exception as reason:
            print ("Exception in killing the Canoe Instance after execution")
            print(reason)

        time.sleep(2)
        print("----------------------------------Canoe Execution completed-------------------------------------------")
        Test_Case_Folder=pathToTestEnv.split('\\')[-1]+"_"+nowTime
        print("Report folder is {}".format(Test_Case_Folder))
        _Move_CANoe_reports_Files_Set(param.TEST_REPORTS_AFTER_EXECUTION, os.path.join(param.CANOE_REPORT_FOLDER,Test_Case_Folder))
       
        #src= D:\Jenkins\TestCaseServer\Test_Environment\Full_Test_XMLs
        #dst= D:\Jenkins\Test_Report\761193_DCOM_tse.tse_2022-05-27-09-26-30
        
    except Exception as reason:
        # MyLog.AppendException("[RQM_UPDATER][STATUS]::: Updation of test result to RQM for TC :::EXCEPTION:::ERROR[5] /n")
        # MyLog.AppendException("[RQM_UPDATER][HINT1]::: Make sure TCF file contains all the details like TestCase ID, TestPlan name and Test iteration etc.. \n")
        # MyLog.AppendException("[RQM_UPDATER][HINT2]::: Make sure you placed correct RQM_Account.cfg file under C:\\Users\gta2kor folder and login credentatials are correct \n")
        # MyLog.AppendException(reason)
        # print("[RQM_UPDATER][STATUS]::: Updation of test result to RQM for TC :::EXCEPTION:::ERROR[5] /n")
        MyLog.AppendException("[CANoe_INSTANCE][STATUS]::: Failed to create Instance :::EXCEPTION:::ERROR[5] /n")
        print(reason) 
        sys.exit(1)


def unzip_Files(bin_path,dest):
    try:
        with ZipFile(bin_path, 'r') as zip_ref:
            zip_ref.extractall(dest)
        MyLog.Append("[unzip_Files][STATUS]::: Unzipping the files to the destination path :::SUCCESSFUL")
        print("[unzip_Files][STATUS]::: Unzipping the files to the destination path :::SUCCESSFUL")
        
    except Exception as reason:
        MyLog.AppendException("[unzip_Files][STATUS]::: Unzipping the files to the destination path :::EXCEPTION:::ERROR[1]")
        MyLog.AppendException(reason)
        print("STATUS::: Unzipping the files to the destination path :::EXCEPTION:::ERROR[1]")
        print(reason) 
        sys.exit(1)
        
        
if __name__ == "__main__":
    try:
        TCF_FileReader_Set(param.TSE_FileName_Path)
        Test_Preparation_Set()
        Test_Triger_Return = Test_Triger_Set(nowTime)
        unzip_Files(os.path.join(param.RQM_SCRIPTS_ZIP_PATH,"RQM_Updater_Scripts.zip"),param.RQM_SCRIPTS_ZIP_PATH)

    finally:
        if MyLog:
            del MyLog    
        print("################################################ Test Trigger Execution Completed ###############################################")
