# coding: utf-8



# Standard Python libraries
import warnings
import xml.etree.ElementTree as ET

# Local imports
import requests # library to perform HTTP requests
from requests.packages.urllib3.exceptions import SecurityWarning

class RestClientError(Exception):
    """Exception type to report errors for the connection to RQM (using the class RestClient).
        
        This is a simple child of Exception with no added attributes. Only an
        initial exception name is given.
    """
    def __init__(self, message):
        self.message = message
    
    def __str__(self):
        return repr(self.message)

        
class DeletedError(Exception):
    """ Exception used to identify if a test case has been deleted.
    """
    def __init__(self, message):
        self.message = message
    
    def __str__(self):
        return repr(self.message)


class RestClient:
    """ Class giving access RQM through its REST API. It does little by itself
        and should only be used through its daughter classes like ``Poster``
        and ``MetadataGetter``.
    
        These daughter class:
        - get the information necessary to add a new test execution record (``MetadataGetter``)
        - put such record to the server (``Poster``)
        - retrieve information from the server on several nodes (``Getter``)
    """
    
    def __init__(self, rqm_url, rqm_project_name, username, password, rqm_project_alias=None):
        """
        Log in RQM and find project alias if not given
        """
        self.rqm_url = rqm_url
        self.rqm_project_name = rqm_project_name
        self.integration_url = 'service/com.ibm.rqm.integration.service.IIntegrationService/'
        
        self.__username = username
        self.__password = password
        
        self.session = requests.Session()
        self.authenticated = False
        
        # FIXME: because of issues with TLS certificate verifications, we turned
        # off this feature. The application may become sensitive to attacks.
        # If this issue is fixed, 'verify=False' should be removed from all requests
        warnings.simplefilter("ignore", SecurityWarning)
        
        # Log in and find project alias if needed
        self.login()
        
        if rqm_project_alias:
            self.rqm_project_alias = rqm_project_alias
        else:
            self.rqm_project_alias = self.find_project_alias(rqm_project_name)
        
        # URL used to get data from testcases, TCERs, ...
        self.resource_url = self.rqm_url + self.integration_url + 'resources/' + self.rqm_project_alias + '/'
        
    
    def is_logged_in(self):
        return self.authenticated
    
    
    def post(self, url, **kwargs):
        """ Wrapper around requests' POST method checking for authentication
            and returning only the status code and the body of the response.
            
            :return: tuple (status_code, text) where status_code is the HTTP
                status code and text is the body of the response
        """
        if self.authenticated == False:
            raise RestClientError("Trying to send a request to RQM without having"
                " logged in beforehand.")
        
        response = self.session.post(url, **kwargs)
        
        # Detect that we are probably disconnected
        # This is based on the observation that whenever a request is sent to
        # RQM while we are note logged in, we get a response in HTML with an
        # javascript instruction to open a login window (hence the
        # 'net.jazz.web.app.authrequired')
        if ("text/html" in response.headers['content-type'] and
            "net.jazz.web.app.authrequired" in response.text):
            self.session = requests.Session()
            self.login()
            response = self.session.post(url, **kwargs)
            if ("text/html" in response.headers['content-type'] and
            "net.jazz.web.app.authrequired" in response.text):
                raise RestClientError("The REST API client seems to have been disconnected: "
                "content type is text/html or the string 'net.jazz.web.app.authrequired' "
                "was found in the response body.")
        
        status = response.status_code
        text = response.text
        
        return (status, text)
    
    
    def get(self, url, **kwargs):
        """ Wrapper around requests' GET method checking for authentication
            and returning only the status code and the  body of the response.
            
            :return: tuple (status_code, text) where status_code is the HTTP
                status code and text is the body of the response
        """
        if self.authenticated == False:
            raise RestClientError("Trying to send a request to RQM without having"
                " logged in beforehand.")
        
        if 'caching_dict' not in self.__dict__:
            self.caching_dict = {}
        if url in self.caching_dict:
            return self.caching_dict[url]
        
        response = self.session.get(url, **kwargs)
        
        # Raise a specific exception if the test case has been deleted (no url or url not valide)
        if ('content-type' not in response.headers):
            raise DeletedError("The tag 'content-type' is missing in the response headers.")
        
        # Detect that we are probably disconnected
        # This is based on the observation that whenever a request is sent to
        # RQM while we are note logged in, we get a response in HTML with an
        # javascript instruction to open a login window (hence the
        # 'net.jazz.web.app.authrequired')
        if ("text/html" in response.headers['content-type'] and
            "net.jazz.web.app.authrequired" in response.text):
            self.session = requests.Session()
            self.login()
            response = self.session.post(url, **kwargs)
            if ("text/html" in response.headers['content-type'] and
            "net.jazz.web.app.authrequired" in response.text):
                raise RestClientError("The REST API client seems to have been disconnected: "
                "content type is text/html or the string 'net.jazz.web.app.authrequired' "
                "was found in the response body.")
        
        status = response.status_code
        text = response.text
        
        self.caching_dict[url] = (status, text)
        
        return (status, text)
    
    
    def login(self):
        """ Authenticates into RQM with provided credentials
        
            The authentication doesn't use the HTTP Basic scheme (which is not
            supported by the instance of RQM we use) but emulates the filling
            of the authentication form.
            
            .. note:: We have to make assumptions to detect whether RQM server accepted
                or not the authentication request. We noticed that when the request is
                accepted, the response body contains an instruction to redirect to the
                desired page. We check if this string is in the response body to know
                whether RQM accepted the login request.
            
            :return: True if and only if we successfully logged into RQM
        """
        
        header_login = {"Content-Type": "application/x-www-form-urlencoded; charset=utf-8"}
        payload_login = {'j_username': self.__username, 'j_password': self.__password}

        # Authentication request
        r = self.session.post(self.rqm_url + 'j_security_check',
            headers=header_login, data=payload_login, verify=False)
        status_code = r.status_code
        
        self.authenticated = False
        
        # The status codes are defined by the HTTP standard
        if status_code != 200:
            raise RestClientError("Status code of the server's response to the login request is not 200."
                "Authentication failed.")
        
        # Check if we are indeed logged in. See the documentation of this function
        if "createAndRunWorkbench(\"com.ibm.rqm.planning.web.webRedirect\");" in r.text:
            self.authenticated = True
        
        return (status_code, self.authenticated)
        
    
    def find_project_alias(self, name):
        """
        Find the real name of the project by parsing the RQM projects
        """
        # Parameters for XML parsing
        ns = {'jp06': 'http://jazz.net/xmlns/prod/jazz/process/0.6/',
            'jp': 'http://jazz.net/xmlns/prod/jazz/process/1.0/',
            'ns2': 'http://jazz.net/xmlns/alm/qm/v0.1/',
            'ns3': 'http://purl.org/dc/elements/1.1/',
            'atom': 'http://www.w3.org/2005/Atom'}
        
        # Get all projects
        projects_url = self.rqm_url + self.integration_url + 'projects'
        status, response_text = self.get(projects_url, headers={'Accept': 'application/xml'}, verify=False)
        
        if status != 200:
            raise Exception("Status = {} to get all RQM projects".format(status))
        
        projects_tree =  ET.XML(response_text.encode('utf-8'))
        entries = projects_tree.findall('atom:entry', ns)
        
        # If entry title corresponds to the project name, return the alias
        project_alias = None
        for entry in entries:
            entry_title = entry.find('atom:content/ns2:project/ns3:title', ns).text
            entry_alias = entry.find('atom:content/ns2:project/ns2:alias', ns).text
            
            if name in entry_title:
                project_alias = entry_alias
                break
        
        if not project_alias:
            raise Exception('Project name [{}] not found in RQM URL: {}'.format(name, self.rqm_url))
        
        return project_alias
    
    
    def url_from_id(self, id, resource):
        """ Build the URL pointing to the test case with the given id
            
            :Example:
            
            self.url_from_id(206, "testcase")
            
            :param id: unique identifier of the resource, integer
            :param resource: string of the name of the resource in RQM
            :return: string of the URL pointing to the desired resource
        """
        try:
            int(id)
        except:
            message = ("The resource id should be an integer (is "+str(type(id))+") and 'resource'"
                " the string name of the desired resource (is "+str(type(resource))+").")
            raise TypeError(message)
        
        # To know how to build these URLs, see the documentation of Jazz
        # https://jazz.net/wiki/bin/view/Main/RqmApi#resourceUrl_for_interaction_with
        return (self.resource_url + resource + "/urn:com.ibm.rqm:" + resource
            + ":" + str(id))

    