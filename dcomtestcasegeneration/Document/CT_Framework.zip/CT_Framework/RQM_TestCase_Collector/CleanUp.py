import Parameter_RQM_Collector as param
import shutil
import os
import sys
from bs4 import BeautifulSoup


def clean_up_folders():
    try:
##        #shutil.rmtree(param.TCF_FILES_SAVE_PATH,ignore_errors=False)
        os.remove(param.Consice_Report_Path)
        os.remove(param.Aborted_build_Path)
   
    except:
        print("Folder or file does not exist")
    #clearing the SW flash status
    try:
        print("[clean_up_folders][INFO]::: Writing into SW_Flashing_Status.txt file in the path ")
        print(param.SW_Flashing_Status)
        file = open(param.SW_Flashing_Status, "w")
        file.write(" ")
        file.close
 

    except Exception as reason:
        print("[clean_up_folders][STATUS]::: Writing into SW_Flashing_Status.txt file in the path :::EXCEPTION:::ERROR[2]")
        print(reason) 
        sys.exit(1)
    print("Clean Up Completed")
    
    
def __create_row(row,col1, col2 ,jenkins_build):
    #Add green color for success
    if jenkins_build=='SUCCESS':
        result=soup.new_tag('td bgcolor="green"')
    else:
        result=soup.new_tag('td bgcolor="red"')
    result.string=jenkins_build
    row.insert(0,result)
    
    #Add red color for failed test cases
##    if not (col5=='0' or col5=='-'):
##        fail_col=soup.new_tag('td bgcolor="red"')
##    else:
##        fail_col=soup.new_tag('td')
##    fail_col.string=col5
##    row.insert(0,fail_col)
##
##    #Add green color for passed test cases
##    if not (col4=='0' or col4=='-'):
##        pass_col=soup.new_tag('td bgcolor="green"')
##    else:
##        pass_col=soup.new_tag('td')
##    pass_col.string=col4
##    row.insert(0,pass_col)           

    
    col = soup.new_tag('td')
    col.string = col2
    row.insert(0, col)

    
    col1_build_no=col1[5:]
    col1_url=param.Jenkins_Job_url+col1_build_no+"/console"
    
    buildno_col=soup.new_tag('td')
    
    #Add url link to tag
    buildno_url=soup.new_tag("a", href=col1_url)
    buildno_url.string=col1
    buildno_col.insert(0,buildno_url)

    row.insert(0,buildno_col)
    
    return (row)
    

def generate_concise_report(build_num):
    global soup
    soup = BeautifulSoup(features="html.parser")
    body = soup.new_tag('body')
    soup.insert(0, body)

    project_header=soup.new_tag('h2')
    project_header.string="Project:\t"+param.Project
    body.insert(0,project_header)
    
    table = soup.new_tag('table border="1px" solid black,border-collapse=collapse')
    body.insert(1, table)


    row = soup.new_tag('tr')
    header=["RESULT","EXE_NAME","Build_No"]
    for header_name in header:
        head=soup.new_tag('th')
        head.string=header_name
        row.insert(0,head)

    table.insert(0, row)
    try:
        with open(param.Aborted_build_Path) as abort_file:
            aborts=abort_file.read()
            print("Aborts {}".format(aborts))
            if not (len(aborts)==0):
                build_aborts=aborts.split('\n')
                for item in build_aborts[:-1]:
                    print(item)
                    aborted_build_no,aborted_exe=item.split()
                    row=soup.new_tag('tr')
                    print("Aborted build {} .... {}".format(aborted_build_no,aborted_exe))
                    col1=aborted_build_no
                    col2 = aborted_exe
                    
                    jenkins_build="ABORTED"
                    row=__create_row(row,col1, col2 ,jenkins_build)   
                    table.insert(len(table.contents), row)
    except:
        print("There are no aborts\n")

    try:
        
    
        with open(param.Consice_Report_Path) as infile:
            
            for line in infile:
                
                row = soup.new_tag('tr')
                
                col1, col2 = line.split()
                jenkins_build="SUCCESS"
                row=__create_row(row,col1, col2 ,jenkins_build)
                
                
                table.insert(len(table.contents), row)

    except:
        print("There are no tests executed\n")


    html_report_path=param.MAIN_Server_Report_Path+'\\concise_report'+build_num+'.html'
    with open(html_report_path, 'w') as outfile:
        outfile.write(soup.prettify())
    print("Report Generated")
    

if __name__ == "__main__":
    build_num=sys.argv[1]
    #build_num="test_url"
    print("The Build Number is {}".format(build_num))
    generate_concise_report(build_num)
    clean_up_folders()
    
