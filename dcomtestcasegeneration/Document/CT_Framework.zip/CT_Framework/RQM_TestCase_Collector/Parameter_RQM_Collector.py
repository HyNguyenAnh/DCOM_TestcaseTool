#*************************************************************
#        GLOBAL_PARAMETER_INTIALIZATION
#**************************************************************
Software_Flash_Max_Timeout = 120
Project='VID3-PF'
config = "VID3-PF (qm)"
TCF_File_Path = r'D:\Jenkins\Received.tcf'
Log_Serevr_Path ="None"
Software_Version ="SW028.30.02.RC2"
logpath=r"D:\Jenkins\TestAutomation\CT_Framework\Test_Scheduler\Scripts\Python_wrapper_logs"
#TSE related params
git_location = "D:\Jenkins\TestCaseServer\Test_Environment"
TEST_COLLECTOR_FILE_PATH=r'D:\CT_Automation\Testcase_collector\TestCase_Collector.txt'
SW_Flashing_Status = r'D:\Jenkins\SW_Flashing_Status.txt'

#Jenkins Scheduler
JENKINS_SERVER_URL = r"https://rb-jmaas.de.bosch.com/CCDA_PP_CT"
PYTHON_WRAPPER_PATH = r'D:\Jenkins\TestCaseServer\CT_Framework\Test_Scheduler\Scripts\Software_Flashing.py'
jobname= 'RQM_Collector'
userId='skc1kor'
userPassword='Sachinpatil@1912'
USER_DATA_PATH = r'D:\Jenkins\TestAutomation\CT_Framework\RQM_TestCase_Collector\user_data.txt'
ATTRIBUTE_FILE_PATH = r'D:\Jenkins\TestAutomation\CT_Framework\RQM_TestCase_Collector\attributes.txt'
TCF_FILES_SAVE_PATH = r'D:\Jenkins\Received_TCF_Files'

#Handshake Result to main server (Copied this parameter from Test_Scheduler\Scripts\Parameter_List.py
MAIN_Server_Report_Path= r'D:\Jenkins\Concise_Reports'
TSE_Name_Path=r'D:\Jenkins\Concise_Reports\TSE_Name.txt'
Test_Result_Path=r'D:\Jenkins\Concise_Reports\Test_Result.txt'
Consice_Report_Path=r'D:\Jenkins\Concise_Reports\Full_Report.txt'
Aborted_build_Path=r'D:\Jenkins\Concise_Reports\Aborted_builds.txt'

Jenkins_Job_url="https://rb-jmaas.de.bosch.com/FVTST/job/RQM_Collector/"
