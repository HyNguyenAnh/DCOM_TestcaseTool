#!/usr/bin/python
# coding: utf-8



import os
import sys
import datetime
import requests
import xml.etree.ElementTree as ET
import re
import Parameter_RQM_Collector as param
from rqm.client import RestClient
import random

# run from windows command:
# python Qmngr.py 19098,"ATV_PJ-AS (qm)",INO2BP


# global variables
ns = {'jp06': 'http://jazz.net/xmlns/prod/jazz/process/0.6/',
            'jp': 'http://jazz.net/xmlns/prod/jazz/process/1.0/',
            'ns2': 'http://jazz.net/xmlns/alm/qm/v0.1/',
            'ns3': 'http://purl.org/dc/elements/1.1/',
            'ns4': 'http://purl.org/dc/elements/1.1/',
            'ns6': 'http://jazz.net/xmlns/alm/v0.1/',
            'atom': 'http://www.w3.org/2005/Atom'}

TCF_FILES_SAVE_PATH = param.TCF_FILES_SAVE_PATH
#JENKINS_SERVER_URL = "https://rb-jmaas.de.bosch.com/Athena_Video"
#PYTHON_WRAPPER_PATH = r'F:\100_Automation\ATV_Python_Wraper\Scripts\ATV_Python_Wraper_Application.py'
USER_DATA_PATH = param.USER_DATA_PATH
ATTRIBUTE_FILE_PATH = param.ATTRIBUTE_FILE_PATH
TEST_COLLECTOR_FILE_PATH= param.TEST_COLLECTOR_FILE_PATH

#Create a directory for saving tcf files if it doesnt exist
##if not os.path.exists(TCF_FILES_SAVE_PATH):
##    os.makedirs(TCF_FILES_SAVE_PATH)

STARTED_BY = ''


def Validate_Params_And_Files():
    """
    Validate given command line parameters and check if necessary files exists.\n
    Parameters: 
        1 - Test Plan ID
        2 - RQM Project Name
        3 - User ID
    Necessary files:
        1 - user_data.txt
        2 - attributes.txt

    RETURN: Tuple if everything was ok, else returns the error message
        tuple structure: (testPlanID, projectName, scriptStarter_userID)
    """
    try:
        # check if enough parameters are given
        print ("sys.argv[1]",sys.argv[1])
        #print (len(sys.argv))
        # if len(sys.argv) < 2 or len(sys.argv[1].split(',')) < 3:
            # return (sys.argv[0] + ' needs at least 3 parameters!')

        # arguments = sys.argv[1].split(',')
        print("Arguments",arguments)
        # testPlanID = int(arguments[0])
        #projectName = arguments[1]
        # startedBy_userID = arguments[2]
        
        
        
        # check necessary files
        #TODO: make variable of txt files
        
        udFileExists = os.path.exists(USER_DATA_PATH)
        attrFileExists = os.path.exists(ATTRIBUTE_FILE_PATH)
        
        if (udFileExists or attrFileExists) is False:
            msg = 'File not found:'
            if udFileExists is False:
                msg += ' user_data.txt'
            if attrFileExists is False:
                msg += ' attributes.txt'
            return msg

        #return (testPlanID, projectName, startedBy_userID)
        return (testPlanID, projectName)
    except ValueError:
        return 'ValueError! First argument must be an integer! Given value was: [{}]'.format(arguments[0])
    #except Exception, reason:
    #    return str(reason)

def Get_User_Data():
    """
    Gets user data from user_data.txt file.

    RETURN: Tuple with structure like: (userId, userPassword)
    """
    # get user_data.txt file path
    script_dir = os.path.dirname(__file__)
    abs_file_path_ud = os.path.join(script_dir, 'user_data.txt')

    # open file and read the first two lines for userid and password
    with open(abs_file_path_ud, 'r') as ud_reader:
        for idx, line in enumerate(ud_reader):
            if idx == 0:
                userId = line.split('=')[1].rstrip()
            elif idx == 1:
                userPassword = line.split('=')[1].rstrip()
    return (userId, userPassword)

def Get_TestCaseLinks_From_TestPlanXML(testPlanXML):
    """
    Gets the testcase links from the given testplan XML.

    Parameters: 
        1 - XML of testplan

    RETURN: list of testcase links
    """
    xmlTree =  ET.XML(testPlanXML.encode('utf-8'))
    testCaseTags = xmlTree.findall('ns2:testcase', ns)

    testCaseLinks = []
    for testCaseTag in testCaseTags:
        testCaseLinks.append(testCaseTag.get('href'))
    return testCaseLinks

def Get_TestCaseIds_From_TestCaseLinks(testCaseLinks):
    """
    Gets the testcase ids from testcase links.

    Parameters:
        1 - List of testcase links

    RETURN: list of testcase ids
    """
    testCaseIds = []
    for testCaseLink in testCaseLinks:
        testCaseIds.append(testCaseLink[(testCaseLink.rfind(':') + 1):])
    return testCaseIds

def Get_Wanted_Attributes():
    """
    Gets which attributes we want to read out from RQM testplan/testcase/testscript from attributes.txt file.

    RETURN: dictionary with the wanted attributes.
    """
    script_dir = os.path.dirname(__file__)
    abs_file_path_attr = os.path.join(script_dir, 'attributes.txt')

    wantedAttributes = {}
    with open(abs_file_path_attr, 'r') as reader:
        for line in reader:
            # if not an empty line
            if not len(line.strip()) == 0:
                line = line.split('=')
                attrName = line[0].rstrip()
                attrValue = line[1].rstrip()
                wantedAttributes[attrName] = attrValue
    return wantedAttributes

def Generate_Tcf_Files(path, wantedAttributes, testCaseLinks, testPlanXML):
    """
    Collect all the data necessary then generate tcf files.

    Parameters:
        1 - Path // save path
        2 - WantedAttributes // attributes we want to show in tcf file
        3 - TestCaselinks // list of testcases to loop thorugh and get more data from them
        4 - TestPlanXML // since every testcase shares the same testplan xml it's unecessary to request it again for all of them

    RETURN: List of generated tcf file names
    """
    
    finishedTcfFilePaths = []
    # collect testplan, testcase and testscript attribute dictionary values, merge them and then make tcf file

    # get testplan attributes
    tp_attributes = Get_Attributes_From_Tp_XML(wantedAttributes, testPlanXML)

    # loop though every testcase link to get testcase attribute and testscript attribute
    for testCaseLink in testCaseLinks:
        testCaseLink_ID = testCaseLink[(testCaseLink.rfind(':') + 1):]
        testCaseResponse = rqmClient.get(testCaseLink)
        # check if response was ok [200], if not raise exception
        if testCaseResponse[0] != 200:
            raise Exception('Error: Request to RQM Test Case[{}] returned with status code {}'.format(testCaseLink_ID, testCaseResponse[0]))
        

        # get testcase attributes
        tc_attributes = Get_Attributes_From_Tc_XML(wantedAttributes, testCaseResponse[1])

        
        # find FIRST testscript in testcase
        testCaseTree =  ET.XML(testCaseResponse[1].encode('utf-8'))
        testScriptTag = testCaseTree.find('ns2:testscript', ns)

        ts_attributes = {}
        # if tc has testscript
        if type(testScriptTag) is not type(None):
            testScriptLink = testScriptTag.get('href')

            testScriptResponse = rqmClient.get(testScriptLink)

            if testScriptResponse[0] != 200:
                raise Exception('Error: RQM request to testscript returned with HTTP code [{}]'.format(testScriptResponse[0]))

            # get testscript attributes
            ts_attributes = Get_Attributes_From_Ts_XML(wantedAttributes, testScriptResponse[1])

        mergedAttributes = mergeThreeDictionary(tp_attributes, tc_attributes, ts_attributes)

        finishedTcfFilePath = WriteTcfFile(mergedAttributes, testCaseLink_ID)
        print (finishedTcfFilePath)
        finishedTcfFilePaths.append(finishedTcfFilePath)
    return finishedTcfFilePaths


def Get_Attributes_From_Tp_XML(wantedAttributes, xml):
    """
    Gets the wanted attribute values from testplan xml.

    RETURN: dictionary containing the wanted value pairs.
    """
    tp_attributes = {}
    xmlTree = ET.XML(xml.encode('utf-8'))

    # TODO: this code seems redundant...
    # NOTE: which attributes do we need?
##    if (wantedAttributes["tp_description"] == "1"):
##        desc = xmlTree.find('ns4:description', ns).text
##        tp_attributes["tp_description"] = desc
##    if (wantedAttributes["tp_attr_sw_commit_id"] == "1"):
##        custom_attributes = xmlTree.find('ns2:customAttributes', ns)
##        for attribute in custom_attributes.findall('ns2:customAttribute', ns):
##            attr_tag_name = attribute.find('ns2:name', ns).text
##            if (attr_tag_name == "SW-Commit-ID"):
##                sw_commit_id = attribute.find('ns2:value', ns).text
##                tp_attributes["tp_attr_sw_commit_id"] = sw_commit_id
##    if (wantedAttributes["tp_attr_sw_release_note"] == "1"):
##        custom_attributes = xmlTree.find('ns2:customAttributes', ns)
##        for attribute in custom_attributes.findall('ns2:customAttribute', ns):
##            attr_tag_name = attribute.find('ns2:name', ns).text
##            if (attr_tag_name == "SW-Releasenote"):
##                sw_release_note = attribute.find('ns2:value', ns).text
##                tp_attributes["tp_attr_sw_release_note"] = sw_release_note
##    if (wantedAttributes["tp_attr_git_tag"] == "1"):
##        custom_attributes = xmlTree.find('ns2:customAttributes', ns)
##        for attribute in custom_attributes.findall('ns2:customAttribute', ns):
##            attr_tag_name = attribute.find('ns2:name', ns).text
##            if (attr_tag_name == "GIT-Tag"):
##                git_tag = attribute.find('ns2:name', ns).text
##                tp_attributes["tp_attr_git_tag"] = git_tag
    # TODO: do only these attributes
    
    if (wantedAttributes["TestCase.RQM.Info.TestPlan"] == "1"):
        title = xmlTree.find('ns4:title', ns).text.replace('\xa0', ' ')
        tp_attributes["TestCase.RQM.Info.TestPlan"] = title
        
    if (wantedAttributes["TestCase.RQM.Info.Test_Iteration"] == "1"):
        iterationLink = xmlTree.find('{http://jazz.net/xmlns/alm/qm/v0.1/}parentIteration').attrib['{http://www.w3.org/1999/02/22-rdf-syntax-ns#}resource']
        
        if iterationLink is not None:
            iterationResponse = rqmClient.get(iterationLink)
            if iterationResponse[0] != 200:
                raise Exception('Error: RQM request to testscript returned with HTTP code [{}]'.format(testScriptResponse[0]))
            
            
            iterationXMLTree = ET.XML(iterationResponse[1].encode('utf-8'))
            iterationNs = {'jp' : 'http://jazz.net/xmlns/prod/jazz/process/1.0/'}
            iterationLabel = iterationXMLTree.find('jp:label', iterationNs).text
            tp_attributes["TestCase.RQM.Info.Test_Iteration"] = iterationLabel
            
    if (wantedAttributes["TestCase.RQM.Info.TestEnvironment"] == "1"):
        configTag = xmlTree.find('ns2:configuration', ns)
        if configTag is not None:
            configLink = configTag.get('href')
            if configLink is not None:
                configResponse = rqmClient.get(configLink)
                if configResponse[0] != 200:
                    raise Exception('Error: RQM request returned with HTTP code [{}]'.format(testScriptResponse[0]))
                configTree = ET.XML(configResponse[1].encode('utf-8'))
                environmentName = configTree.find('ns2:name', ns).text
                tp_attributes["TestCase.RQM.Info.TestEnvironment"] = environmentName

    return tp_attributes   

def Get_Attributes_From_Tc_XML(wantedAttributes, xml):
    """
    Gets the wanted attribute values from testcase xml.

    RETURN: dictionary containing the wanted value pairs.
    """
    tc_attributes = {}
    xmlTree = ET.XML(xml.encode('utf-8'))
    # TODO: this code seems redundant...
    # NOTE: which attributes do we need?
    if (wantedAttributes["TestCase.RQM.Info.TestCase"] == "1"):
        title = xmlTree.find('ns4:title', ns).text
        tc_attributes["TestCase.RQM.Info.TestCase"] = title
##    if (wantedAttributes["tc_owner"] == "1"):
##        owner = xmlTree.find('ns6:owner', ns).text
##        tc_attributes["tc_owner"] = owner
##    if (wantedAttributes["tc_creation_date"] == "1"):
##        creation_date = xmlTree.find('ns2:creationDate', ns).text
##        tc_attributes["tc_creation_date"] = creation_date
    if (wantedAttributes["TestCase.RQM.Info.test platform"] == "1"):
        categories = xmlTree.findall('ns2:category', ns)
        for category in categories:
            if category.get('term') == "test platform":
                testPlatform = category.get('value')
                tc_attributes["TestCase.RQM.Info.test platform"] = testPlatform
    if (wantedAttributes["TestCase.RQM.Info.vTESTstudio Test Case ID"] == "1"):
        custom_attributes = xmlTree.find('ns2:customAttributes', ns)
        if custom_attributes is not None:
            for attribute in custom_attributes.findall('ns2:customAttribute', ns):
                attr_tag_name = attribute.find('ns2:name', ns).text
                if (attr_tag_name == "vTESTstudio Test Case ID"):
                    vTStudioTcID = attribute.find('ns2:value', ns).text
                    tc_attributes["TestCase.RQM.Info.vTESTstudio Test Case ID"] = vTStudioTcID
    if (wantedAttributes["TestCase.RQM.Info.vTESTstudio Test Unit"] == "1"):
        custom_attributes = xmlTree.find('ns2:customAttributes', ns)
        if custom_attributes is not None:
            for attribute in custom_attributes.findall('ns2:customAttribute', ns):
                attr_tag_name = attribute.find('ns2:name', ns).text
                if (attr_tag_name == "vTESTstudio Test Unit"):
                    vTStudioTcUnit = attribute.find('ns2:value', ns).text
                    tc_attributes["TestCase.RQM.Info.vTESTstudio Test Unit"] = vTStudioTcUnit
    if (wantedAttributes["TestCase.RQM.Info.variant"] == "1"):
        categories = xmlTree.findall('ns2:category', ns)
        for category in categories:
            if category.get('term') == "variant":
                testVariant = category.get('value')
                tc_attributes["TestCase.RQM.Info.variant"] = testVariant
    return tc_attributes

def Get_Attributes_From_Ts_XML(wantedAttributes, xml):
    """
    Gets the wanted attribute values from testscript xml.

    RETURN: dictionary containing the wanted value pairs.
    """
    ts_attributes = {}
    xmlTree = ET.XML(xml.encode('utf-8'))

    # TODO: this code seems redundant...
    # NOTE: which attributes do we need?
##    if (wantedAttributes["ts_title"] == "1"):
##        testscriptTitle = xmlTree.find('ns4:title', ns).text
##        ts_attributes["ts_title"] = testscriptTitle

    return ts_attributes

def mergeTwoDictionary(x, y):
    """
    Merges two dictionaries without modifying the original ones.

    Parameters:
        1 - first dictionary
        2 - second dictionary

    RETURN: New dictionary merged from the given two.
    """
    z = x.copy()
    z.update(y)
    return z

def mergeThreeDictionary(a, b, c):
    """
    Merges three dictionaries without modifying the original ones.

    Parameters:
        1 - first dictionary
        2 - second dictionary
        3 - third dictionary

    RETURN: New dictionary merged from the given two.
    """
    d = a.copy()
    d.update(b)
    d.update(c)
    return d

def WriteTcfFile(wantedAttributes, testCaseLink_ID):
    """
    Writes tcf file.

    Parameters:
        1 - merged attributes from tp, tc and ts

    RETURN: path of the generated tcf file
    """
    # preparing tcf file creation::
    # make tcf filename
    now = datetime.datetime.now()
    tcfFileName = 'testTCFFile_{}{}{}{}{}{}{}'.format(now.year, now.month, now.day, now.hour, now.minute, now.second, now.microsecond)

    #print(wantedAttributes)
    content = 'TestCase.RQM.Info.User = "{}"\n'.format(STARTED_BY)
    for attribute in wantedAttributes:
        content += attribute + ' = "' + wantedAttributes[attribute] + '"\n'

    hash = random.getrandbits(128)

    content += 'TestCase.RQM.Info.SessionID = '
    content += ("%032x" % hash) + '\n'
    content += 'GenerateZipReport("PATH_TO_REPORTS")' + '\n'
    content += 'Canoe.EmailFeedback("Luke.Skywalker@hu.bosch.com")' + '\n'


    completeName = os.path.join(TCF_FILES_SAVE_PATH, tcfFileName + ".tcf")

    tcfFile = open(completeName, "w")
    tcfFile.write(content)
    tcfFile.close()

    return str(completeName)



def extract_exename_tcf(path):
    #Create empty list to store exe names
    restbus_exenames=[]
    functional_exenames=[]
    tcf_files=[]

    #Get the files in the directory
    files=os.listdir(path)
    #print (files)
    for file in files:
        file_path=os.path.join(path,file)
        print(file_path)
        #Open each file and read the exe name
        with open(file_path,"r")as obj:

            file_Data=obj.read()
            # Read the test unit exe name
            exe_name=re.search("Test Unit = \"(.*)\"",file_Data)
            print("exe_name",exe_name.group(1))

            #Check if it is a functional exe or Restbus exe
            if (re.search("test platform = \"(.*)\"",file_Data).group(1).__contains__('CANoeHIL')):
                if (exe_name.group(1) not in restbus_exenames):
                    restbus_exenames.append(exe_name.group(1))
                    tcf_files.append(file_path)

            else:
                #Functional exe are kept as it is
                functional_exenames.append(exe_name.group(1))
                tcf_files.append(file_path)
    #Get the unique exe names and convert into list
    #restbus_exenames=list(set(restbus_exenames))
    
    print("functional_exenames",functional_exenames)
    print("restbus_exenames",restbus_exenames)
    print("tcf_files",tcf_files)

    with open(TEST_COLLECTOR_FILE_PATH,'w') as f:
        for tcf_file in tcf_files:
            f.write(tcf_file)
            f.write('\n')
            
    

    #Write the tcf_file names into text file
    return (tcf_files)



if __name__ == "__main__":

    # ## JLR Specific Implmentation below , this implementation is for reading the .tse files from the server , this is valid only for xml validation::::START"
    # print(('Starting {}...'.format(sys.argv[0])))
    # #COnstruct the  Path which we received with theGIT location in the PC
    # Config_filepath = sys.argv[1]
    # print('Received parameter is {}'.format(Config_filepath))

    # #TSE_file_Path = os.path.join(param.git_location, Config_filepath)
    # TSE_file_Path = os.path.join(param.git_location, Config_filepath)
    # print('TSE file path is {}'.format(TSE_file_Path))
    
    # #Search for all the .tse files and create a  list of .tse files with full path
    # TSE_Files_List = []
    # for (root, dirnames, fileNames ) in os.walk(TSE_file_Path):      
        # for file in fileNames:
            # if file.endswith(".tse"):                 
                # TSE_Files_List.append(os.path.join(root, file))

    # print('TSE files found are ...')
    # print(TSE_Files_List)
    # #Trigger the Jenkins execution build with number of .tse
    # with open(TEST_COLLECTOR_FILE_PATH,'w') as f:
        # for tse_file in TSE_Files_List:
            # f.write(tse_file)
            # f.write('\n')
    # print('Writing into testcollector.txt is completed')
    # ## JLR Specific Implmentation above , this implementation is for reading the .tse files from the server , this is valid only for xml validation::::END"
    
    print(('Starting {}...'.format(sys.argv[0])))
    
    user_data = Get_User_Data()
    userId = user_data[0]
    userPassword = user_data[1]
    
    print("Logging into RQM....")

    testPlanID = 49445
    projectName = "VID3_JIZHI_SE1A_SD1A (qm)"
    try:
        rqmClient = RestClient("https://rb-alm-13-p.de.bosch.com/qm/", projectName, userId, userPassword)
        print("Logging RQM success")
       
    except Exception as reason:
        print("Logging RQm Failed")
        print(reason)
        sys.exit(1)

    
    projectAlias = rqmClient.find_project_alias(projectName)
    testPlanResponse = rqmClient.get("https://rb-alm-13-p.de.bosch.com/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/"+ projectAlias +"/testplan/urn:com.ibm.rqm:testplan:" + str(testPlanID))
    if testPlanResponse[0] != 200:
        raise Exception("Error")
    
    testCaseLinks = Get_TestCaseLinks_From_TestPlanXML(testPlanResponse[1])
    testCaseIds = Get_TestCaseIds_From_TestCaseLinks(testCaseLinks)
    
    wantedAttributes = Get_Wanted_Attributes()
    #print(wantedAttributes)
    
    print("Making TCF Files to [{}]....".format(TCF_FILES_SAVE_PATH))
    
    generated_files = Generate_Tcf_Files(TCF_FILES_SAVE_PATH, wantedAttributes, testCaseLinks, testPlanResponse[1])
    print("TCF file generation success")
    
    
    
    
    
    
    
    
    
    
    
    
    
