import os
import sys
import datetime
import requests
import time
from xml.etree import ElementTree
import Parameter_RQM_Collector as param
import re


JENKINS_SERVER_URL = param.JENKINS_SERVER_URL
PYTHON_WRAPPER_PATH = param.PYTHON_WRAPPER_PATH

#*********************************************************************************************************
#        FUNCTION BLOCK: FUNCTION_1: Read TCF file 
# Function name will read TCF file received from Jenkins 
# INPUT PARAMETERS:
#           1) string: TCF File
#
# OUTPUT PARAMETERS:
#           1) Dictionary : Test Case Info
#*********************************************************************************************************
       
def TCF_FileReader_Set(tcfFile):
    try:
        global TestCaseInfo # +++
        global nowTime
        TestCaseInfo = dict() # +++
        nowTime = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime())
        
        print("STATUS:::Reading the TCF file:::START")
        
        #result=shutil.copyfile(param.ADTF_Log_Path, tcfFile)
        #print result
        testCaseInfo_pattern = r'TestCase.*Info.([ A-Za-z0-9_]+)\s*=\s*\"(.+)\"'
        testCaseInfo_re = re.compile(testCaseInfo_pattern)
        try:                    
            file=open(tcfFile,'r')
            lines = file.readlines()
            file.close()   
        except Exception as reason:
            print("STATUS::: Opening TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
            print(reason) 
            sys.exit(1)
        
        for line in lines :
            match = testCaseInfo_re.match(line)
            if match:
                TestCaseInfo[(match.group(1)).strip()] = (match.group(2)).strip()
                print("Info:::{0} = {1}".format(match.group(1),match.group(2))) 
    
        print(TestCaseInfo)
        print("STATUS:::Reading the TCF file:::SUCCESSFUL")
        
    except Exception as reason:
        print("STATUS::: Reading TCF_FileLog_Set in the function :::EXCEPTION:::ERROR[1]")
        print(reason) 
        sys.exit(1)

        

def Wait_for_Builds_Completion(userId, userPassword, jobname,triggered_builds):
    jenkins_job_name = jobname             
    Jenkins_url = JENKINS_SERVER_URL
    jenkins_user = userId
    jenkins_pwd = userPassword

    try:
        auth= (jenkins_user, jenkins_pwd)
        crumb_data= requests.get("{0}/crumbIssuer/api/json".format(Jenkins_url),auth = auth,headers={'content-type': 'application/json'}, verify=False)
        print((crumb_data.status_code))
        if str(crumb_data.status_code) == "200":

            for build in triggered_builds:

                if not (build=='0'):

                    #build_info_url="https://rb-jmaas.de.bosch.com/FCA_CVPAM/job/TestAutomation/job/TestExecution/"+data.text+"/api/xml?depth=0"
                    #build_info_url="https://rb-jmaas.de.bosch.com/FCA_CVPAM/job/TestAutomation/job/TestExecution/1913/api/xml?depth=0"
                    build_info_url="{0}/job/{1}/{2}//api/xml?depth=0".format(Jenkins_url + '/view/Platform_FV3_Test',jenkins_job_name,build)

                    build_info=requests.get(build_info_url,auth=auth,headers={'content-type': 'application/json','Jenkins-Crumb':crumb_data.json()['crumb']}, verify=False)
                    
                    tree = ElementTree.fromstring(build_info.content)
                    #print(tree.find('building').text)

                    #Wait until the last build is completed
                    while(tree.find('building').text=='true'):
                        print ("Waiting for build {} to complete".format(build))
                        sys.stdout.flush()
                        time.sleep(60)
                        build_info=requests.get(build_info_url,auth=auth,headers={'content-type': 'application/json','Jenkins-Crumb':crumb_data.json()['crumb']}, verify=False)
                    
                        tree = ElementTree.fromstring(build_info.content)
                    print("Completed the build {}".format(build))
                    
                    result=tree.find('result').text

                    
                    
                    #TCF_FileReader_Set(filePaths)
                    if (result=='FAILURE' or result=='ABORTED'):
                        print("Build {} is Aborted".format(build))
                        #Get the tcf file for which jenkins build aborted
                        failed_action=tree.find('action')
                        failed_parameters=failed_action.findall('parameter')

                        #Create a list to store the parameters of the aborted build
                        parameters=[]
                        for parameter in failed_parameters:
                            parameters.append(parameter.find('value').text)

                        #Get the tcf file path of the aborted build
                        #The second parameter in the jenkins build is the tcf file.
                        #We have the tcf path in second position "-t <tcf_file_path>"
                        #tcf_file=parameters[1].split()[1]
                        
                        #Call the TCF file reader to read the tcf file
                        #TCF_FileReader_Set(tcf_file)

                        #Extracting the TSE File Name and writing into Filename.txt for reporting purpose
                        TSE_Name_Path = 'None'
                        TSE_Name_Path = TCF_File.split('\\')[-1]
                        
                            
                        try:
                            file = open(param.Aborted_build_Path, "a+")
                            file.write('build')
                            file.write(build)
                            file.write(' ')
                            file.write(TSE_Name_Path)
                            file.write('\n')
                            file.close
                            print("Failed/Aborted Build details uploaded")
                            time.sleep(2)
                            

                        except Exception as reason:
                            print("[Wait_for_Builds_Completion][STATUS]::: Writing Aborted build details:::EXCEPTION:::ERROR[1]")
                            print(reason) 
                            sys.exit(1)
                        
                    

        else:
            print("Couldn't fetch Jenkins-Crumb")

    except Exception as e:
        print ("Failed triggering the Jenkins job")
        print(("Error: " + str(e)))

def Trigger_Jenkins_Job(userId, userPassword, jobname, CONFIG, TCF_File, BinPath,SWVersion,TestPlanID,TestIter,TestEnv,token):
    """
    Triggers Jenkins job with given command and parameters.

    Parameters:
        1 - userId
        2 - userPassword
        3 - jobname
        4 - command
        5 - parameters

    RETURN: Void
    """
    print ('Received TSE file is {}'.format(TCF_File))
    #Use a variable to get the build number that is triggered
    build_triggered_no='0'
    jenkins_job_name = jobname             
    Jenkins_url = JENKINS_SERVER_URL
    jenkins_user = userId
    jenkins_pwd = userPassword
    buildWithParameters = True
    jenkins_params = {'token': token,
                    'CONFIG': CONFIG,
                    'TSE_File': TCF_File,
                    'BinPath': BinPath,
                    'SW_Version':SWVersion,
                      'Test_Plan_ID':TestPlanID,
                      'Test_Iteration':TestIter,
                      'Test_Environment':TestEnv                      
                    }

    try:
        auth= (jenkins_user, jenkins_pwd)
        crumb_data= requests.get("{0}/crumbIssuer/api/json".format(Jenkins_url),auth = auth,headers={'content-type': 'application/json'}, verify=False)
        print((crumb_data.status_code))
        if str(crumb_data.status_code) == "200":
            if buildWithParameters:
                url = "{0}/job/{1}/buildWithParameters".format(Jenkins_url + '/view/Platform_FV3_Test',jenkins_job_name)
                print (url)
                data = requests.get("{0}/job/{1}/buildWithParameters".format(Jenkins_url + '/view/Platform_FV3_Test',jenkins_job_name),auth=auth,params=jenkins_params,headers={'content-type': 'application/json','Jenkins-Crumb':crumb_data.json()['crumb']}, verify=False)
            else:
                data = requests.get("{0}/job/{1}/build".format(Jenkins_url,jenkins_job_name),auth=auth,params=jenkins_params,headers={'content-type': 'application/json','Jenkins-Crumb':crumb_data.json()['crumb']})

            print (data)
            if str(data.status_code) == "201":
                print ("Jenkins job is triggered")
                #Wait for 10 seconds.This wait is important as it take time to trigger job in jenkins
                time.sleep(10)
                build_no_url="{0}/job/{1}/lastBuild/buildNumber".format(Jenkins_url + '/view/Platform_FV3_Test',jenkins_job_name)
                build_number = requests.get(build_no_url,auth=auth,headers={'content-type': 'application/json','Jenkins-Crumb':crumb_data.json()['crumb']}, verify=False)
                build_triggered_no=build_number.text
                print(build_triggered_no)

                
            else:
                print ("Failed to trigger the Jenkins job")

        else:
            print("Couldn't fetch Jenkins-Crumb")

    except Exception as e:
        print ("Failed triggering the Jenkins job")
        print(("Error: " + str(e)))

    return (build_triggered_no)

if __name__ == "__main__":
    # BinPath="-p " +sys.argv[1]
    # SWVersion = "-s "+sys.argv[2]
    TestPlanID = "-id "+sys.argv[0]
    # TestIter = "-i "+sys.argv[4]
    # TestEnv = "-e "+sys.argv[5]
    #print ('Received bin path and SW version is {}, {}'.format(BinPath,SWVersion))
    #print ('Received Test Plan, Iteration and Environment are {} {}, {}'.format(TestPlanID,TestIter,TestEnv))
    print ('Received Test Plan {}'.format(TestPlanID))
    #BinPath="-p "
    #print(BinPath)
    triggered_builds=[]
    global TCF_File

    # calll PythonWrapper.py with tcf file path for very geenerated file
    # NOTE: for testing only the first tcf file will be given to the jenkins job
    jobname = param.jobname
    CONFIG =  PYTHON_WRAPPER_PATH
    # parameter = r'C:\Users\INO2BP\Desktop\tcf_saves\testTCFFile_49861_202042219330527000.tcf' # generatedFiles[0]
    # parameter ="-t "+os.path.abspath(generatedFiles[0])
    userId=param.userId
    userPassword=param.userPassword
    
    with open(param.TEST_COLLECTOR_FILE_PATH,'r') as tcf:
        data=tcf.read()
        tcf_files=data.split('\n')[:-1]
        print(tcf_files)
        for filePaths in tcf_files:                
            TCF_File = "-t " + os.path.abspath(filePaths)
            print ('TSE file running is {}'.format(TCF_File))
            #BinPath= r"-p \\abtvdfs2.de.bosch.com\ismdfs\ism\Archive\CC\Video\NRCS2_FCA\Jenkins_Artifacts\01_NRCS2_FCA_RELEASE\02_Customer_Releases\NRCS2_PP6_FCA_WL75MY21_CVPAM006.6\NRCS2_PP6_FCA_WL75MY21_CVPAM006.6.zip"
            token = 'SFA_Test_Automation'
            print ('Triggering SytemTest_Automation_driver job...)')
            build_triggered_no=Trigger_Jenkins_Job(userId, userPassword, jobname, CONFIG, TCF_File, BinPath,SWVersion,TestPlanID,TestIter,TestEnv,token)
            time.sleep(2)
            triggered_builds.append(build_triggered_no)
            sys.stdout.flush()
        print(triggered_builds)
        Wait_for_Builds_Completion(userId, userPassword, jobname,triggered_builds)
    
        
